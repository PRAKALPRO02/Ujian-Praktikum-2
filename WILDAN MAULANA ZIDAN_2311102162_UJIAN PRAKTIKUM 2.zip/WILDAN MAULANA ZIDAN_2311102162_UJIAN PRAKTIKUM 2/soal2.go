// 2311102162
// wildan maulana zidan
package main

import "fmt"

// Definisi struct untuk mahasiswa
type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

// Fungsi untuk mencari nilai pertama berdasarkan NIM
func cariNilaiPertama(mahasiswa []Mahasiswa, nim string) int {
	for _, mhs := range mahasiswa {
		if mhs.NIM == nim {
			return mhs.Nilai
		}
	}
	return -1 // Jika tidak ditemukan
}

// Fungsi untuk mencari nilai terakhir berdasarkan NIM
func cariNilaiTerakhir(mahasiswa []Mahasiswa, nim string) int {
	nilai := -1
	for _, mhs := range mahasiswa {
		if mhs.NIM == nim {
			nilai = mhs.Nilai
		}
	}
	return nilai
}

func main() {
	// Input jumlah data mahasiswa
	fmt.Print("Masukkan jumlah data mahasiswa (N): ")
	var N int
	fmt.Scan(&N)

	// Deklarasi array untuk menyimpan data mahasiswa
	var mahasiswa []Mahasiswa

	// Input data mahasiswa
	for i := 0; i < N; i++ {
		var nim, nama string
		var nilai int
		fmt.Printf("Masukkan NIM, Nama, dan Nilai untuk mahasiswa ke-%d: ", i+1)
		fmt.Scan(&nim, &nama, &nilai)
		mahasiswa = append(mahasiswa, Mahasiswa{NIM: nim, Nama: nama, Nilai: nilai})
	}

	// Input NIM yang ingin dicari
	fmt.Print("Masukkan NIM untuk pencarian: ")
	var cariNIM string
	fmt.Scan(&cariNIM)

	// Mencari nilai pertama
	nilaiPertama := cariNilaiPertama(mahasiswa, cariNIM)
	if nilaiPertama != -1 {
		fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah: %d\n", cariNIM, nilaiPertama)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", cariNIM)
	}

	// Mencari nilai terakhir
	nilaiTerakhir := cariNilaiTerakhir(mahasiswa, cariNIM)
	if nilaiTerakhir != -1 {
		fmt.Printf("Nilai terakhir mahasiswa dengan NIM %s adalah: %d\n", cariNIM, nilaiTerakhir)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", cariNIM)
	}
}
