// 2311102162
// wildan maulana zidan
package main

import "fmt"

func main() {
	// Membaca input untuk himpunan pertama
	fmt.Println("Masukkan jumlah elemen himpunan pertama:")
	var n1 int
	fmt.Scan(&n1)

	fmt.Println("Masukkan elemen himpunan pertama:")
	set1 := make(map[int]bool)
	for i := 0; i < n1; i++ {
		var num int
		fmt.Scan(&num)
		set1[num] = true
	}

	// Membaca input untuk himpunan kedua
	fmt.Println("Masukkan jumlah elemen himpunan kedua:")
	var n2 int
	fmt.Scan(&n2)

	fmt.Println("Masukkan elemen himpunan kedua:")
	set2 := make(map[int]bool)
	for i := 0; i < n2; i++ {
		var num int
		fmt.Scan(&num)
		set2[num] = true
	}

	// Mencari irisan himpunan
	fmt.Println("Irisan himpunan:")
	for num := range set1 {
		if set2[num] {
			fmt.Print(num, " ")
		}
	}
	fmt.Println()
}
