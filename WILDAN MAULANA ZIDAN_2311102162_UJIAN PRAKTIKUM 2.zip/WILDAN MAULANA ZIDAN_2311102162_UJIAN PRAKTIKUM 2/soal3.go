// 2311102162
// wildan maulana zidan
package main

import (
	"fmt"
	"strings"
)

// Konstanta jumlah provinsi
const nProv = 11

// Tipe data
type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

// Prosedur InputData
func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data untuk provinsi ke-%d (Nama Populasi Pertumbuhan): ", i+1)
		fmt.Scan(&prov[i], &pop[i], &tumbuh[i])
	}
}

// Fungsi ProvinsiTercepat
func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIndex] {
			maxIndex = i
		}
	}
	return maxIndex
}

// Fungsi IndeksProvinsi
func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) { // Perbandingan case-insensitive
			return i
		}
	}
	return -1
}

// Prosedur Prediksi
func Prediksi(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Prediksi jumlah penduduk tahun depan untuk provinsi dengan pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			prediksiPop := float64(pop[i]) * (1 + tumbuh[i])
			fmt.Printf("Provinsi: %s, Prediksi Populasi: %.2f\n", prov[i], prediksiPop)
		}
	}
}

func main() {
	// Deklarasi array
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv

	// Input data
	InputData(&prov, &pop, &tumbuh)

	// Menentukan provinsi dengan pertumbuhan tercepat
	tercepatIndex := ProvinsiTercepat(tumbuh)
	fmt.Printf("Provinsi dengan pertumbuhan tercepat adalah: %s\n", prov[tercepatIndex])

	// Input nama provinsi untuk pencarian
	fmt.Print("Masukkan nama provinsi untuk pencarian: ")
	var namaProv string
	fmt.Scanln(&namaProv)

	// Mencari indeks provinsi
	indeks := IndeksProvinsi(prov, namaProv)
	if indeks != -1 {
		fmt.Printf("Indeks provinsi %s adalah: %d\n", namaProv, indeks+1)
	} else {
		fmt.Printf("Provinsi dengan nama %s tidak ditemukan.\n", namaProv)
	}

	// Prediksi populasi
	Prediksi(prov, pop, tumbuh)
}
