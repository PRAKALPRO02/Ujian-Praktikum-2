// 2311102162
// wildan maulana zidan
package main

import (
	"fmt"
)

const NMAX = 1000000

type Partai struct {
	Nama  int
	Suara int
}

type TabPartai struct {
	Data [NMAX]Partai // Array partai
	N    int          // Jumlah partai yang aktif
}

func main() {
	var t TabPartai
	var input int

	fmt.Println("Masukkan suara partai (-1 untuk selesai):")

	// Proses input suara partai
	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}

		pos := posisi(t, t.N, input)
		if pos != -1 {
			// Jika partai ditemukan, tambahkan suaranya
			t.Data[pos].Suara++
		} else {
			// Jika partai belum ada, tambahkan sebagai partai baru
			t.Data[t.N].Nama = input
			t.Data[t.N].Suara = 1
			t.N++
		}
	}

	insertionSort(&t)

	// Tampilkan hasil
	fmt.Println("\nKeluaran:")
	for i := 0; i < t.N; i++ {
		fmt.Printf("%d(%d) ", t.Data[i].Nama, t.Data[i].Suara)
	}
	fmt.Println()
}

// Fungsi untuk mencari posisi partai berdasarkan nama
func posisi(t TabPartai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if t.Data[i].Nama == nama {
			return i // Indeks partai ditemukan
		}
	}
	return -1 // Tidak ditemukan
}

func insertionSort(t *TabPartai) {
	for i := 1; i < t.N; i++ {
		key := t.Data[i]
		j := i - 1
		for j >= 0 && t.Data[j].Suara < key.Suara {
			t.Data[j+1] = t.Data[j]
			j--
		}
		t.Data[j+1] = key
	}
}
