package main

import "fmt"

const maksN int = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

type arrayMahasiswa [maksN]mahasiswa

func inputMhs(T *arrayMahasiswa, N *int) { // Faisal Khoiruddin_2311102046
	fmt.Scan(N)
	var i int = 0
	for i < *N {
		fmt.Scan(&T[i].NIM, &T[i].nama, &T[i].nilai)
		i++
	}
}

func cariNilaiPertama(T arrayMahasiswa, N int, nim string) int { // Faisal Khoiruddin_2311102046
	var i, ketemu int
	ketemu = -1
	i = 0
	for i < N && ketemu == -1 {
		if T[i].NIM == nim {
			ketemu = i
		}
		i++
	}
	return ketemu
}

func cariNilaiMaks(T arrayMahasiswa, N int, nim string) int { // Faisal Khoiruddin_2311102046
	var ketemu int = cariNilaiPertama(T, N, nim)
	var i, idxMaks int
	if ketemu != -1 {
		idxMaks = ketemu
		for i = ketemu; i < N; i++ {
			if T[idxMaks].nilai < T[i].nilai && T[i].NIM == nim {
				idxMaks = i
			}
		}
		return idxMaks
	} else {
		return ketemu
	}
}

func main() {
	var A arrayMahasiswa
	var jumlah, indeks1, indeks2 int
	var nim string
	inputMhs(&A, &jumlah)
	nim = "113"
	indeks1 = cariNilaiPertama(A, jumlah, nim)
	indeks2 = cariNilaiMaks(A, jumlah, nim)
	fmt.Println("Nilai pertama dari NIM", nim, "adalah", A[indeks1].nilai)
	fmt.Println("Nilai terbesar dari NIM", nim, "adalah", A[indeks2].nilai)
}
