package main

import "fmt"

const nProv int = 10

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) { // Faisal Khoiruddin_2311102046
	var i int
	for i = 0; i < nProv; i++ {
		fmt.Scan(&prov[i], &pop[i], &tumbuh[i])
	}
}

func ProvinsiTercepat(tumbuh TumbuhProv) int { // Faisal Khoiruddin_2311102046
	var idx int = 0
	var i int
	for i = 1; i < nProv; i++ {
		if tumbuh[idx] < tumbuh[i] {
			idx = i
		}
	}
	return idx
}

func Prediksi(prov NamaProv, pop PopProv, tumbuh TumbuhProv) { // Faisal Khoiruddin_2311102046
	var i int
	var hasil float64
	for i = 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			hasil = (tumbuh[i] + 1) * float64(pop[i])
			fmt.Printf("%s %.0f\n", prov[i], hasil)
		}
	}
}

func IndeksProvinsi(prov NamaProv, nama string) int { // Faisal Khoiruddin_2311102046
	var ketemu int = -1
	var i int = 0
	for i < nProv && ketemu == -1 {
		if prov[i] == nama {
			ketemu = i
		}
		i++
	}
	return ketemu
}

func main() {
	var TProvinsi NamaProv
	var TPopulasi PopProv
	var TPertumbuhan TumbuhProv
	var cari string
	var idxTercepat, idxProvinsi int
	InputData(&TProvinsi, &TPopulasi, &TPertumbuhan)
	fmt.Scan(&cari)
	idxTercepat = ProvinsiTercepat(TPertumbuhan)
	fmt.Println(TProvinsi[idxTercepat])
	idxProvinsi = IndeksProvinsi(TProvinsi, cari)
	fmt.Println(TProvinsi[idxProvinsi])
	Prediksi(TProvinsi, TPopulasi, TPertumbuhan)
}
