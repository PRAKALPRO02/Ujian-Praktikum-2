package main

import "fmt"

type pemain struct {
	nama                   string
	gol_2311102046, assist int
}

const NMAX = 1000

type arrPemain [NMAX]pemain

func main() { // Faisal Khoiruddin_2311102046
	var T arrPemain
	var i, n int
	var fnama, lnama string

	fmt.Scan(&n)
	for i = 0; i < n && i < NMAX; i++ {
		fmt.Scan(&fnama, &lnama, &T[i].gol_2311102046, &T[i].assist)
		T[i].nama = fnama + " " + lnama
	}

	var pass, idx_max int
	var temp pemain
	for pass = 1; pass <= n-1; pass++ {
		idx_max = pass - 1
		for i = pass; i < n; i++ {
			if T[idx_max].gol_2311102046 < T[i].gol_2311102046 || (T[idx_max].gol_2311102046 == T[i].gol_2311102046 && T[idx_max].assist <= T[i].assist) {
				idx_max = i
			}
		}
		temp = T[idx_max]
		T[idx_max] = T[pass-1]
		T[pass-1] = temp
	}

	for i = 0; i < n; i++ {
		fmt.Println(T[i].nama, T[i].gol_2311102046, T[i].assist)
	}
}
