package main

import "fmt"

type set [2022]int

func exist(T set, n int, nilai int) bool { // Faisal Khoiruddin_2311102046
	var i int = 0
	var status bool = false
	for i < n && !status {
		status = T[i] == nilai
		i++
	}
	return status
}

func inputset(T *set, n *int) { // Faisal Khoiruddin_2311102046
	*n = 0
	var bilangan int
	fmt.Scan(&bilangan)
	for *n < 2022 && !exist(*T, *n, bilangan) {
		T[*n] = bilangan
		*n++
		fmt.Scan(&bilangan)
	}
}

func findIntersection(T1, T2 set, n, m int, T3 *set, h *int) { // Faisal Khoiruddin_2311102046
	var j int = 0
	*h = 0
	for j < n {
		if exist(T2, m, T1[j]) {
			T3[*h] = T1[j]
			*h++
		}
		j++
	}
}

func printset(T set, n int) { // Faisal Khoiruddin_2311102046
	var i int = 0
	for i < n {
		fmt.Print(T[i], " ")
		i++
	}
}

func main() {
	var set1, set2, set3 set
	var n1, n2, n3 int
	inputset(&set1, &n1)
	inputset(&set2, &n2)
	findIntersection(set1, set2, n1, n2, &set3, &n3)
	printset(set3, n3)
}
