package main

import "fmt"

type Player struct {
	Name    string
	Goals   int
	Assists int
}

func printPlayers(players []Player) {
	fmt.Println("Peringkat Pencetak Gol:")
	for i, player := range players {
		fmt.Printf("%d. %s - Gol: %d, Assist: %d\n", i+1, player.Name, player.Goals, player.Assists)
	}
}

func insertionSort(players []Player) {
	n := len(players)
	for i := 1; i < n; i++ {
		key := players[i]
		j := i - 1

		for j >= 0 && (players[j].Goals < key.Goals || (players[j].Goals == key.Goals && players[j].Assists < key.Assists)) {
			players[j+1] = players[j]
			j--
		}
		players[j+1] = key
	}
}

func main() {
	var n int

	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	players := make([]Player, n)
	for i := 0; i < n; i++ {
		var firstName, lastName string
		var goals, assists int

		fmt.Printf("Masukkan data pemain ke-%d (Nama Depan Nama Belakang Gol Assist): ", i+1)
		fmt.Scan(&firstName, &lastName, &goals, &assists)

		players[i] = Player{
			Name:    firstName + " " + lastName,
			Goals:   goals,
			Assists: assists,
		}
	}

	insertionSort(players)

	printPlayers(players)
}
