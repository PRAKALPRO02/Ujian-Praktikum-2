package main

import (
	"fmt"
)

const maxMahasiswa = 51

// Struct untuk menyimpan data mahasiswa
type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

func main() {
	var dataMhs230 [maxMahasiswa]Mahasiswa
	var jumlahData int

	fmt.Print("Masukkan jumlah mahasiswa: ")
	fmt.Scan(&jumlahData)

	if jumlahData > maxMahasiswa {
		fmt.Printf("Jumlah maksimum mahasiswa adalah %d\n", maxMahasiswa)
		return
	}

	for i := 0; i < jumlahData; i++ {
		fmt.Printf("\nMasukkan data mahasiswa ke-%d:\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&dataMhs230[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&dataMhs230[i].Nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&dataMhs230[i].Nilai)
	}

	var nimCari string
	fmt.Print("\nMasukkan NIM untuk mencari nilai pertama: ")
	fmt.Scan(&nimCari)

	nilaiPertama := cariNilaiPertama(dataMhs230[:jumlahData], nimCari)
	if nilaiPertama == -1 {
		fmt.Println("Mahasiswa dengan NIM tersebut tidak ditemukan.")
	} else {
		fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah %d\n", nimCari, nilaiPertama)
	}

	fmt.Print("\nMasukkan NIM untuk mencari nilai terbesar: ")
	fmt.Scan(&nimCari)

	nilaiTerbesar := cariNilaiTerbesar(dataMhs230[:jumlahData], nimCari)
	if nilaiTerbesar == -1 {
		fmt.Println("Mahasiswa dengan NIM tersebut tidak ditemukan.")
	} else {
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d\n", nimCari, nilaiTerbesar)
	}
}

func cariNilaiPertama(data []Mahasiswa, nim string) int {
	for _, mahasiswa := range data {
		if mahasiswa.NIM == nim {
			return mahasiswa.Nilai
		}
	}
	return -1
}

func cariNilaiTerbesar(data []Mahasiswa, nim string) int {
	nilaiTerbesar := -1
	found := false

	for _, mahasiswa := range data {
		if mahasiswa.NIM == nim {
			found = true
			if mahasiswa.Nilai > nilaiTerbesar {
				nilaiTerbesar = mahasiswa.Nilai
			}
		}
	}

	if !found {
		return -1
	}
	return nilaiTerbesar
}
