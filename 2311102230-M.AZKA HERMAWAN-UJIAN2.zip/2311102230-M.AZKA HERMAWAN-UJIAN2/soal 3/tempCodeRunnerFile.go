//Muhammad Azka Hermawan
//2311102230

package main

import "fmt"

const nProv int = 11

type Provinsi struct {
	Nama        string
	Populasi    int
	Pertumbuhan float64
}

func main() {
	var provinsi [nProv]Provinsi

	inputData(&provinsi)

	provinsi[0] = Provinsi{
		Nama:        "2311102230",
		Populasi:    1000000,
		Pertumbuhan: 3.5,
	}

	indexTercepat := provinsiTercepat(provinsi)
	fmt.Printf("Provinsi dengan angka pertumbuhan tercepat: %s\n",
		provinsi[indexTercepat].Nama)

	var namaDicari string
	fmt.Print("Masukkan nama provinsi yang dicari: ")
	fmt.Scanln(&namaDicari)
	indexDicari := indeksProvinsi(provinsi, namaDicari)
	if indexDicari != -1 {
		fmt.Printf("Indeks provinsi %s: %d\n", namaDicari, indexDicari)
	} else {
		fmt.Printf("Provinsi dengan nama '%s' tidak ditemukan.\n", namaDicari)
	}

	fmt.Println("Prediksi populasi tahun depan untuk provinsi dengan pertumbuhan > 2%:")
	prediksi(provinsi)
}

func inputData(provinsi *[nProv]Provinsi) {
	for i := 1; i < nProv; i++ {
		fmt.Printf("Data provinsi ke-%d:\n", i+1)
		fmt.Print("Nama Provinsi: ")
		fmt.Scan(&provinsi[i].Nama)
		fmt.Print("Jumlah Populasi: ")
		fmt.Scan(&provinsi[i].Populasi)
		fmt.Print("Angka Pertumbuhan (%): ")
		fmt.Scan(&provinsi[i].Pertumbuhan)
	}
}

func provinsiTercepat(provinsi [nProv]Provinsi) int {
	index := 0
	for i := 1; i < nProv; i++ {
		if provinsi[i].Pertumbuhan > provinsi[index].Pertumbuhan {
			index = i
		}
	}
	return index
}

func indeksProvinsi(provinsi [nProv]Provinsi, nama string) int {
	for i := 0; i < nProv; i++ {
		if toLower(provinsi[i].Nama) == toLower(nama) {
			return i
		}
	}
	return -1
}

func toLower(s string) string {
	lower := ""
	for _, c := range s {
		if c >= 'A' && c <= 'Z' {
			lower += string(c + ('a' - 'A'))
		} else {
			lower += string(c)
		}
	}
	return lower
}

func prediksi(provinsi [nProv]Provinsi) {
	for i := 0; i < nProv; i++ {
		if provinsi[i].Pertumbuhan > 2.0 {
			prediksiPopulasi := float64(provinsi[i].Populasi) * (1 +
				provinsi[i].Pertumbuhan/100)
			fmt.Printf("Provinsi: %s, Prediksi Populasi: %.2f\n",
				provinsi[i].Nama, prediksiPopulasi)
		}
	}
}
