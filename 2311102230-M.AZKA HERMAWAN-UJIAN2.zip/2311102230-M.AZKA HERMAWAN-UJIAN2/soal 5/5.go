//Muhammad Azka Hermawan
//2311102230

package main

import "fmt"

type Partai struct {
	nama  int
	suara int
}

const NMAX = 1000000

type tabPartai []Partai

func main() {
	var suara2311102165 int
	var daftarPartai tabPartai

	fmt.Println("Masukkan suara (akhiri dengan -1):")
	for {
		fmt.Scan(&suara2311102165)
		if suara2311102165 == -1 {
			break
		}

		idx := posisi(daftarPartai, suara2311102165)
		if idx == -1 {

			daftarPartai = append(daftarPartai, Partai{nama: suara2311102165, suara: 1})
		} else {

			daftarPartai[idx].suara++
		}
	}

	bubbleSort(daftarPartai)

	fmt.Println("Hasil perolehan suara:")
	for _, partai := range daftarPartai {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}

func posisi(daftar tabPartai, nama int) int {
	for i, partai := range daftar {
		if partai.nama == nama {
			return i
		}
	}
	return -1
}

func bubbleSort(daftar tabPartai) {
	n := len(daftar)
	for i := 0; i < n-1; i++ {
		for j := 0; j < n-i-1; j++ {
			if daftar[j].suara < daftar[j+1].suara ||
				(daftar[j].suara == daftar[j+1].suara && daftar[j].nama > daftar[j+1].nama) {
				daftar[j], daftar[j+1] = daftar[j+1], daftar[j]
			}
		}
	}
}
