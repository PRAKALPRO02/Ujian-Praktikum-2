package main

import "fmt"

const NMAX = 1000000

// struct partai
type partai struct {
	nama string
	suara int
}

// tipe tabPartai: array of partai dengan kapasitas NMAX
type tabPartai [NMAX]partai

func InputData(p *tabPartai, n *int) {
	fmt.Print("Masukkan nama partai (-1 untuk berhenti): ")
	var x string
	for {
		_, err := fmt.Scanln(&x)
		if err != nil || x == "-1" {
			break
		}
		idx := posisi(*p, *n, x)
		if idx == -1 {
			(*p)[*n].nama = x
			(*p)[*n].suara = 1
			*n++
		} else {
			(*p)[idx].suara++
		}
		fmt.Print("Masukkan nama partai (-1 untuk berhenti): ")
	}
}

func SortData(p tabPartai, n int) {
	var pass, k int
	var temp partai
	for pass = 1; pass <= n-1; pass++ {
		k = pass
		temp = p[k]
		for k > 0 && temp.suara > p[k-1].suara {
			p[k] = p[k-1]
			k--
		}
		p[k] = temp
	}
}

func TampilkanData(p tabPartai, n int) {
	fmt.Println("\nHasil perolehan suara:")
	for k := 0; k < n; k++ {
		fmt.Printf("%s (%d) ", p[k].nama, p[k].suara)
	}
	fmt.Println()
}

func posisi(t tabPartai, n int, nama string) int {
	var i, ketemu int
	i = 0
	ketemu = -1
	for i < n && ketemu == -1 {
		if t[i].nama == nama {
			ketemu = i
		}
		i++
	}
	return ketemu
}

func main() {
	var p tabPartai
	var n int

	InputData(&p, &n)
	SortData(p, n)
	TampilkanData(p, n)
}