package main

import "fmt"

const nMax = 51

type mhs struct {
    NIM  string
    Nama string
    Nilai []int
}

type arrayMahas [nMax]mhs

func main() {
    var N int
    var data arrayMahas

    // Menerima sejumlah N data mahasiswa
    fmt.Print("Masukkan jumlah mahasiswa: ")
    fmt.Scanln(&N)
    for i := 0; i < N; i++ {
        fmt.Printf("data mahasiswa ke %d:\n", i+1)
        fmt.Print("NIM: ")
        fmt.Scanln(&data[i].NIM)
        fmt.Print("Nama: ")
        fmt.Scanln(&data[i].Nama)
        fmt.Println("masukkan nilai (-1 untuk berhenti):")
        for j := 0; ; j++ {
            var nilai int
            fmt.Print("Nilai ", j+1, ": ")
            fmt.Scanln(&nilai)
            if nilai == -1 {
                if j < 2 {
                    fmt.Println("harus memiliki minimal 3 nilai.")
                    j--
                    continue
                }
                break
            }
            data[i].Nilai = append(data[i].Nilai, nilai)
        }
    }
    
    fmt.Println("\nNIM mahasiswa pertama:", data[0].NIM)
    
    var cariNIM string
    fmt.Print("\nmasukkan NIM mahasiswa yang ingin dicari nilainya: ")
    fmt.Scanln(&cariNIM)
    max := 0
    for i := 0; i < N; i++ {
        if data[i].NIM == cariNIM {
            for _, nilai := range data[i].Nilai {
                if nilai > max {
                    max = nilai
                }
            }
            fmt.Printf("nilai terbesar mahasiswa NIM %s : %d\n", cariNIM, max)
            return
        }
    }
    fmt.Printf("NIM %s tidak di temukan\n", cariNIM)
}