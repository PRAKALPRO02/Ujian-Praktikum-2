//Fadhel Yussie Ramadhan 2311102322
package main

import "fmt"

const nProv = 34

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
    for i := 0; i < nProv; i++ {
        fmt.Printf("Masukkan nama provinsi ke-%d: ", i+1)
        fmt.Scanln(&(*prov)[i])
        fmt.Printf("Masukkan jumlah populasi provinsi %s: ", (*prov)[i])
        fmt.Scanln(&(*pop)[i])
        fmt.Printf("Masukkan angka pertumbuhan provinsi %s: ", (*prov)[i])
        fmt.Scanln(&(*tumbuh)[i])
    }
}

func ProvinsiTercepat(tumbuh TumbuhProv) int {
    maxIdx := 0
    maxTumbuh := tumbuh[0]
    for i := 1; i < nProv; i++ {
        if tumbuh[i] > maxTumbuh {
            maxIdx = i
            maxTumbuh = tumbuh[i]
        }
    }
    return maxIdx
}

func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
    fmt.Println("Provinsi dengan angka pertumbuhan di atas 2%:")
    for i := 0; i < nProv; i++ {
        if tumbuh[i] > 2 {
            fmt.Printf("%s - Populasi: %d, Pertumbuhan: %.2f%%\n", prov[i], pop[i], tumbuh[i])
        }
    }
}

func IndeksProvinsi(prov NamaProv, nama string) int {
    for i := 0; i < nProv; i++ {
        if prov[i] == nama {
            return i
        }
    }
    return -1
}

func main() {
    var prov NamaProv
    var pop PopProv
    var tumbuh TumbuhProv

    fmt.Println("Masukkan data provinsi:")
    InputData(&prov, &pop, &tumbuh)

    fmt.Println("\nProvinsi dengan pertumbuhan tercepat:")
    idx := ProvinsiTercepat(tumbuh)
    fmt.Printf("%s - Pertumbuhan: %.2f%%\n", prov[idx], tumbuh[idx])

    TampilkanData(prov, pop, tumbuh)
}