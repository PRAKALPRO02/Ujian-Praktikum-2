//Damara Galuh Pembayun
//2311102110

package main

import "fmt"

// Struktur data untuk merepresentasikan seorang mahasiswa
type Mahasiswa struct {
        NIM_110   int
        Nama_110  string
        Nilai_110 int
}

// Fungsi untuk membaca input N dan data mahasiswa
func bacaData(N int) []Mahasiswa {
        var data []Mahasiswa
        for i := 0; i < N; i++ {
                var m Mahasiswa
                fmt.Print("Masukkan NIM: ")
                fmt.Scan(&m.NIM_110)
                fmt.Print("Masukkan Nama: ")
                fmt.Scan(&m.Nama_110)
                fmt.Print("Masukkan Nilai: ")
                fmt.Scan(&m.Nilai_110)
                data = append(data, m)
        }
        return data
}

// Fungsi untuk mencari nilai pertama mahasiswa dengan NIM tertentu
func cariNilaiPertama(data []Mahasiswa, NIM_110 int) int {
        for _, m := range data {
                if m.NIM_110 == NIM_110 {
                        return m.Nilai_110
                }
        }
        return -1 // Nilai -1 jika NIM tidak ditemukan
}

// Fungsi untuk mencari nilai terbesar mahasiswa dengan NIM tertentu
func cariNilaiTerbesar(data []Mahasiswa, NIM_110 int) int {
        nilaiTerbesar := -1
        for _, m := range data {
                if m.NIM_110 == NIM_110 && m.Nilai_110 > nilaiTerbesar {
                        nilaiTerbesar = m.Nilai_110
                }
        }
        return nilaiTerbesar
}

func main() {
        var N int
        fmt.Print("Masukkan jumlah data mahasiswa: ")
        fmt.Scan(&N)

        dataMahasiswa := bacaData(N)

        // Contoh penggunaan fungsi
        NIMYangDicari := 113
        nilaiPertama := cariNilaiPertama(dataMahasiswa, NIMYangDicari)
        nilaiTerbesar := cariNilaiTerbesar(dataMahasiswa, NIMYangDicari)

        fmt.Printf("Nilai pertama mahasiswa dengan NIM %d adalah %d\n", NIMYangDicari, nilaiPertama)
        fmt.Printf("Nilai terbesar mahasiswa dengan NIM %d adalah %d\n", NIMYangDicari, nilaiTerbesar)
}