//Damara Galuh Pembayun
//2311102110

package main

import (
        "fmt"
        "sort"
)

func findIntersection(set1_110, set2_110 []int) []int {
        // Urutkan kedua slice untuk efisiensi pencarian
        sort.Ints(set1_110)
        sort.Ints(set2_110)

        // Inisialisasi slice untuk menyimpan hasil irisan
        intersection := []int{}

        i, j := 0, 0
        for i < len(set1_110) && j < len(set2_110) {
                if set1_110[i] == set2_110[j] {
                        intersection = append(intersection, set1_110[i])
                        i++
                        j++
                } else if set1_110[i] < set2_110[j] {
                        i++
                } else {
                        j++
                }
        }

        return intersection
}

func main() {
        var set1, set2 []int
        var num int

        fmt.Println("Masukkan bilangan untuk himpunan pertama (akhiri dengan 0):")
        for {
                fmt.Scan(&num)
                if num == 0 {
                        break
                }
                set1 = append(set1, num)
        }

        fmt.Println("Masukkan bilangan untuk himpunan kedua (akhiri dengan 0):")
        for {
                fmt.Scan(&num)
                if num == 0 {
                        break
                }
                set2 = append(set2, num)
        }

        result := findIntersection(set1, set2)
        fmt.Println("Irisan dari kedua himpunan adalah:", result)
}