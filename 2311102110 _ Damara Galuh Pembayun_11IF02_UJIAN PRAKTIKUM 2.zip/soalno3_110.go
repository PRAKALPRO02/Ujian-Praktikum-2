//Damara Galuh Pembayun
//2311102110

package main

import (
        "fmt"
)

type Provinsi struct {
        nama_110       string
        populasi_110    int
        pertumbuhan_110 float64
}

func main() {
        const jumlahProvinsi = 10
        var provinsi_110 [jumlahProvinsi]Provinsi

        // Membaca data provinsi
        fmt.Println("Masukkan data provinsi:")
        for i := 0; i < jumlahProvinsi; i++ {
                fmt.Printf("Provinsi ke-%d:\n", i+1)
                fmt.Print("Nama: ")
                fmt.Scanln(&provinsi_110[i].nama_110)
                fmt.Print("Populasi: ")
                fmt.Scanln(&provinsi_110[i].populasi_110)
                fmt.Print("Pertumbuhan: ")
                fmt.Scanln(&provinsi_110[i].pertumbuhan_110)
        }

        // Mencari provinsi dengan pertumbuhan tercepat
        tercepat := 0
        for i := 1; i < jumlahProvinsi; i++ {
                if provinsi_110[i].pertumbuhan_110 > provinsi_110[tercepat].pertumbuhan_110 {
                        tercepat = i
                }
        }
        fmt.Printf("\nProvinsi dengan pertumbuhan tercepat: %s\n", provinsi_110[tercepat].nama_110)

        // Mencari indeks provinsi yang dicari
        var namaDicari string
        fmt.Print("Masukkan nama provinsi yang dicari: ")
        fmt.Scanln(&namaDicari)
        found := false
        for i, prov := range provinsi_110 {
                if prov.nama_110 == namaDicari {
                        fmt.Printf("Indeks provinsi %s adalah %d\n", namaDicari, i+1)
                        found = true
                        break
                }
        }
        if !found {
                fmt.Printf("Provinsi %s tidak ditemukan\n", namaDicari)
        }

        // Menampilkan prediksi populasi untuk provinsi dengan pertumbuhan di atas 2%
        fmt.Println("\nPrediksi populasi tahun depan untuk provinsi dengan pertumbuhan di atas 2%:")
        for _, prov := range provinsi_110 {
                if prov.pertumbuhan_110 > 0.02 {
                        prediksi := int(float64(prov.populasi_110) * (1 + prov.pertumbuhan_110))
                        fmt.Printf("%s: %d\n", prov.nama_110, prediksi)
                }
        }
}