//Damara Galuh Pembayun
//2311102110

package main

import "fmt"

// Struktur data pemain
type Pemain struct {
        nama    string
        gol     int
        assist int
}

// Fungsi untuk membandingkan dua pemain (untuk pengurutan)
func (p1 Pemain) Less(p2 Pemain) bool {
        if p1.gol == p2.gol {
                return p1.assist > p2.assist
        }
        return p1.gol > p2.gol
}

// Fungsi untuk mengurutkan pemain menggunakan insertion sort
func insertionSort(pemain []Pemain) {
        for i := 1; i < len(pemain); i++ {
                key := pemain[i]
                j := i - 1
                for j >= 0 && pemain[j].Less(key) {
                        pemain[j+1] = pemain[j]
                        j--
                }
                pemain[j+1] = key
        }
}

func main() {
        var n int
        fmt.Print("Masukkan jumlah pemain: ")
        fmt.Scanln(&n)

        pemain := make([]Pemain, n)

        fmt.Println("Masukkan data pemain (nama gol assist):")
        for i := 0; i < n; i++ {
                fmt.Scan(&pemain[i].nama, &pemain[i].gol, &pemain[i].assist)
        }

        insertionSort(pemain)

        fmt.Println("\nPeringkat Pemain:")
        for _, p := range pemain {
                fmt.Printf("%s (%d gol, %d assist)\n", p.nama, p.gol, p.assist)
        }
}