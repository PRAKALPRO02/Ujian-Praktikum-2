package main

//2311102220
import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const nMax = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

var arrayMahasiswa [nMax]mahasiswa

func main() {
	var n int
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Masukkan jumlah data mahasiswa (maksimum 51): ")
	fmt.Scanln(&n)

	if n > nMax {
		fmt.Println("Jumlah mahasiswa melebihi batas maksimum!")
		return
	}

	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d (NIM Nama Nilai): ", i+1)
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)
		parts := strings.Split(input, " ")

		if len(parts) != 3 {
			fmt.Println("Input tidak valid. Masukkan data dalam format: NIM Nama Nilai")
			i--
			continue
		}

		nilai, err := strconv.Atoi(parts[2])
		if err != nil {
			fmt.Println("Nilai harus berupa angka!")
			i--
			continue
		}

		arrayMahasiswa[i] = mahasiswa{
			NIM:   parts[0],
			nama:  parts[1],
			nilai: nilai,
		}
	}

	for {
		fmt.Println("\nPilih operasi:")
		fmt.Println("1. Cari nilai pertama seorang mahasiswa berdasarkan NIM")
		fmt.Println("2. Cari nilai terbesar seorang mahasiswa berdasarkan NIM")
		fmt.Println("3. Tampilkan seluruh data mahasiswa")
		fmt.Println("4. Keluar")

		fmt.Print("Pilihan Anda: ")
		var pilihan int
		fmt.Scanln(&pilihan)

		switch pilihan {
		case 1:
			fmt.Print("Masukkan NIM: ")
			nim, _ := reader.ReadString('\n')
			nim = strings.TrimSpace(nim)
			cariNilaiPertama(nim, n)
		case 2:
			fmt.Print("Masukkan NIM: ")
			nim, _ := reader.ReadString('\n')
			nim = strings.TrimSpace(nim)
			cariNilaiTerbesar(nim, n)
		case 3:
			tampilkanDataMahasiswa(n)
		case 4:
			fmt.Println("Keluar dari program.")
			return
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func cariNilaiPertama(nim string, n int) {
	for i := 0; i < n; i++ {
		if arrayMahasiswa[i].NIM == nim {
			fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah %d\n", nim, arrayMahasiswa[i].nilai)
			return
		}
	}
	fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", nim)
}

func cariNilaiTerbesar(nim string, n int) {
	maxNilai := -1
	found := false
	for i := 0; i < n; i++ {
		if arrayMahasiswa[i].NIM == nim {
			found = true
			if arrayMahasiswa[i].nilai > maxNilai {
				maxNilai = arrayMahasiswa[i].nilai
			}
		}
	}
	if found {
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d\n", nim, maxNilai)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", nim)
	}
}

func tampilkanDataMahasiswa(n int) {
	fmt.Println("\nData Mahasiswa:")
	for i := 0; i < n; i++ {
		fmt.Printf("NIM: %s, Nama: %s, Nilai: %d\n", arrayMahasiswa[i].NIM, arrayMahasiswa[i].nama, arrayMahasiswa[i].nilai)
	}
}
