package main

//2311102220
import "fmt"

type set [2022]int

func exist(T set, n int, val int) bool {
	for i := 0; i < n; i++ {
		if T[i] == val {
			return true
		}
	}
	return false
}

func inputSet(T *set, n *int) {
	var val int
	*n = 0

	for {
		fmt.Scan(&val)
		if exist(*T, *n, val) {
			break
		}
		if *n >= 2022 {
			break
		}
		(*T)[*n] = val
		*n++
	}
}

func findIntersection(T1, T2 set, n1, n2 int, T3 *set, n3 *int) {
	*n3 = 0

	for i := 0; i < n1; i++ {
		if exist(T2, n2, T1[i]) {
			(*T3)[*n3] = T1[i]
			*n3++
		}
	}
}

func printSet(T set, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("%d ", T[i])
	}
	fmt.Println()
}

func main() {
	var S1, S2, S3 set
	var n1, n2, n3 int

	fmt.Println("Masukkan elemen untuk himpunan pertama (akhiri dengan elemen duplikat):")
	inputSet(&S1, &n1)

	fmt.Println("Masukkan elemen untuk himpunan kedua (akhiri dengan elemen duplikat):")
	inputSet(&S2, &n2)

	findIntersection(S1, S2, n1, n2, &S3, &n3)

	fmt.Println("Irisan dari kedua himpunan:")
	printSet(S3, n3)
}
