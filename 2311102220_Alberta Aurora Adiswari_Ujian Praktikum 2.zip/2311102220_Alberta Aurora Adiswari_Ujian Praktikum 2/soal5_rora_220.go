package main

//2311102220
import "fmt"

const MAX = 1000000

type Partai struct {
	nama  int
	suara int
}

func main() {
	var p []Partai
	var suara, n int

	for {
		fmt.Scan(&suara)
		if suara == -1 {
			break
		}

		pos := posisi(p, suara)
		if pos != -1 {
			p[pos].suara++
		} else {
			p = append(p, Partai{nama: suara, suara: 1})
		}
	}

	n = len(p)
	for i := 1; i < n; i++ {
		key := p[i]
		j := i - 1
		for j >= 0 && p[j].suara < key.suara {
			p[j+1] = p[j]
			j--
		}
		p[j+1] = key
	}

	for _, partai := range p {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}

func posisi(tabelPartai []Partai, nama int) int {
	for i, partai := range tabelPartai {
		if partai.nama == nama {
			return i
		}
	}
	return -1
}
