package main

import (
	"fmt"
	"sort"
)

// Muhammad Agha Zulfadhli 2311102015

const NMAX = 1000000

type Partai struct {
	nama  int
	suara int
}

func posisi(tabPartai []Partai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if tabPartai[i].nama == nama {
			return i
		}
	}
	return -1
}
func main() {
	var tabPartai []Partai
	var suara, n int
	n = 0

	for {
		fmt.Scan(&suara)
		if suara == -1 {
			break
		}
		idx := posisi(tabPartai, n, suara)
		if idx == -1 {
			tabPartai = append(tabPartai, Partai{nama: suara, suara: 1})
			n++
		} else {
			tabPartai[idx].suara++
		}
	}
	sort.Slice(tabPartai, func(i, j int) bool {
		if tabPartai[i].suara == tabPartai[j].suara {
		}
		return tabPartai[i].suara > tabPartai[j].suara
	})
	for _, partai := range tabPartai {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}
