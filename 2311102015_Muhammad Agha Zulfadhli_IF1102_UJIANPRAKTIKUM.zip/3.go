package main

import (
	"fmt"
)

const nProv = 11

// Muhammad Agha Zulfadhli 2311102015

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func InputData(NamaProv *NamaProv, PopProv *PopProv, TumbuhProv *TumbuhProv) {
	(*NamaProv)[0], (*PopProv)[0], (*TumbuhProv)[0] = "Aceh", 5000000, 1.1
	(*NamaProv)[1], (*PopProv)[1], (*TumbuhProv)[1] = "Bali", 4200000, 2.3
	(*NamaProv)[2], (*PopProv)[2], (*TumbuhProv)[2] = "Jakarta", 10000000, 1.5
	(*NamaProv)[3], (*PopProv)[3], (*TumbuhProv)[3] = "Jawa Barat", 46000000, 1.9
	(*NamaProv)[4], (*PopProv)[4], (*TumbuhProv)[4] = "Jawa Tengah", 35000000, 2.2
	(*NamaProv)[5], (*PopProv)[5], (*TumbuhProv)[5] = "Jawa Timur", 38000000, 1.8
	(*NamaProv)[6], (*PopProv)[6], (*TumbuhProv)[6] = "Sumatera Utara", 14000000, 1.3
	(*NamaProv)[7], (*PopProv)[7], (*TumbuhProv)[7] = "Kalimantan Timur", 3500000, 2.5
	(*NamaProv)[8], (*PopProv)[8], (*TumbuhProv)[8] = "Sulawesi Selatan", 9000000, 2.0
	(*NamaProv)[9], (*PopProv)[9], (*TumbuhProv)[9] = "Banten", 12000000, 2.6
	(*NamaProv)[10], (*PopProv)[10], (*TumbuhProv)[10] = "Lampung", 8000000, 1.7
}

func ProvinsiTerkecil(TumbuhProv TumbuhProv) int {
	idxMin := 0
	for i := 1; i < nProv; i++ {
		if TumbuhProv[i] < TumbuhProv[idxMin] {
			idxMin = i + 1
		}
	}
	return idxMin
}

func Prediksi(NamaProv NamaProv, PopProv PopProv, TumbuhProv TumbuhProv) {
	fmt.Println("Prediksi populasi dengan pertumbuhan lebih dari 2%:")
	for i := 0; i < nProv; i++ {
		if TumbuhProv[i] > 2.0 {
			prediksi := float64(PopProv[i]) + (float64(PopProv[i]) * TumbuhProv[i] / 100.0)
			fmt.Printf("Provinsi: %s, Populasi tahun depan: %.2f\n", NamaProv[i], prediksi)
		}
	}
}

func cariProvinsi(NamaProv NamaProv, nama string) int {
	var idx int
	for i := 0; i < nProv; i++ {
		if NamaProv[i] == nama {
			idx = i
		}
	}
	return idx
}

func printProvinsi(NamaProv NamaProv, PopProv PopProv, TumbuhProv TumbuhProv) {
	fmt.Println("Daftar provinsi:")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi: %s\tPopulasi: %d\tPertumbuhan: %.2f\n", NamaProv[i], PopProv[i], TumbuhProv[i])
	}
}

func main() {
	var NamaProv NamaProv
	var PopProv PopProv
	var TumbuhProv TumbuhProv

	InputData(&NamaProv, &PopProv, &TumbuhProv)
	printProvinsi(NamaProv, PopProv, TumbuhProv)

	nama := ""
	fmt.Print("Nama provinsi yang ingin dicari: ")
	fmt.Scan(&nama)
	fmt.Printf("Provinsi %s Berada di indeks %d\n", nama, cariProvinsi(NamaProv, nama))

	idxMin := ProvinsiTerkecil(TumbuhProv)
	fmt.Printf("Provinsi dengan pertumbuhan terkecil: %s\n", NamaProv[idxMin])

	Prediksi(NamaProv, PopProv, TumbuhProv)
}
