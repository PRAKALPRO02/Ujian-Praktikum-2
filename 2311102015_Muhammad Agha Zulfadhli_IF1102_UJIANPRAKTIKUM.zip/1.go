package main

import "fmt"

// Muhammad Agha Zulfadhli 2311102015

func exist(T []int, val int) bool {
	for _, v := range T {
		if v == val {
			return true
		}
	}
	return false
}

func inputSet(T *[]int, val int) {
	if !exist(*T, val) {
		*T = append(*T, val)
	}
}

func findIntersection(T1, T2 []int) []int {
	var T3 []int
	for _, v := range T1 {
		if exist(T2, v) {
			inputSet(&T3, v)
		}
	}
	return T3
}

func printSet(T []int) {
	for _, v := range T {
		fmt.Printf("%d ", v)
	}
	fmt.Println()
}

func main() {
	var n1, n2 int
	var s1, s2 []int

	fmt.Print("Banyak elemen di set 1: ")
	fmt.Scan(&n1)
	fmt.Println("Masukkan elemen set 1:")
	for i := 0; i < n1; i++ {
		var val int
		fmt.Scan(&val)
		inputSet(&s1, val)
	}

	fmt.Print("Banyak elemen di set 2: ")
	fmt.Scan(&n2)
	fmt.Println("Masukkan elemen set 2:")
	for i := 0; i < n2; i++ {
		var val int
		fmt.Scan(&val)
		inputSet(&s2, val)
	}
	s3 := findIntersection(s1, s2)
	printSet(s3)
}
