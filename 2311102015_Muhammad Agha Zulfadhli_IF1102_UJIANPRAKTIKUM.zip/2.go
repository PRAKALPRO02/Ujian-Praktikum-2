package main

import (
	"fmt"
)

const nMax = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

// Muhammad Agha Zulfadhli 2311102015
type arrayMahasiswa [nMax]mahasiswa

func tampilkanData(mhs arrayMahasiswa) {
	for i := 0; i < len(mhs); i++ {
		if !(mhs[i].NIM == "" && mhs[i].nama == "" && mhs[i].nilai == 0) {
			fmt.Printf("NIM: %s\tNama: %s\tNilai: %d\n", mhs[i].NIM, mhs[i].nama, mhs[i].nilai)
		}
	}
}

func cariNilaiPertama(mhs arrayMahasiswa, nim string) mahasiswa {
	for i := 0; i < len(mhs); i++ {
		if mhs[i].NIM == nim {
			return mhs[i]
		}
	}
	return mahasiswa{"", "", 0}
}

func cariNilaiTertinggi(mhs arrayMahasiswa, nim string) mahasiswa {
	var max mahasiswa
	for i := 1; i < len(mhs); i++ {
		if mhs[i].NIM == nim && mhs[i].nilai > max.nilai {
			max = mhs[i]
		}
	}
	return max
}

func main() {
	var mhs arrayMahasiswa

	// mhs[0] = mahasiswa{"114", "Nana", 100}
	// mhs[1] = mahasiswa{"113", "Jojo", 95}
	// mhs[2] = mahasiswa{"118", "Rere", 88}
	// mhs[3] = mahasiswa{"116", "Koko", 95}
	// mhs[4] = mahasiswa{"117", "Keke", 90}
	// mhs[5] = mahasiswa{"116", "Koko", 60}
	// mhs[6] = mahasiswa{"113", "Jojo", 80}
	// mhs[7] = mahasiswa{"113", "Jojo", 75}
	// mhs[8] = mahasiswa{"118", "Rere", 86}
	// mhs[9] = mahasiswa{"119", "Roro", 100}

	count := 0
	fmt.Print("Banyak Mahasiswa: ")
	fmt.Scan(&count)
	for i := 0; i < count; i++ {
		var nim, nama string
		var nilai int
		fmt.Print("NIM, Nama, Nilai: ")
		fmt.Scan(&nim, &nama, &nilai)
		mhs[i] = mahasiswa{nim, nama, nilai}
	}

	fmt.Println("Data Mahasiswa:")
	tampilkanData(mhs)

	cari := ""
	fmt.Print("\nNim yang dicari : ")
	fmt.Scan(&cari)
	pertama := cariNilaiPertama(mhs, cari)
	tertinggi := cariNilaiTertinggi(mhs, cari)
	fmt.Printf("\nNilai Pertama Mahasiswa dengan NIM : %s\nNama: %s \nNilai: %d\n", cari, pertama.nama, pertama.nilai)
	fmt.Printf("\nNilai Terbesar Mahasiswa dengan NIM : %s\nNama: %s \nNilai: %d\n", cari, tertinggi.nama, tertinggi.nilai)
}
