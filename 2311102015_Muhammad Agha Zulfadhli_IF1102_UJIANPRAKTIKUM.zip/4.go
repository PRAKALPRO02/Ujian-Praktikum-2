package main

import (
	"fmt"
)

type Pemain struct {
	Nama   string
	Gol    int
	Assist int
}

// Muhammad Agha Zulfadhli 2311102015

func selectionSort(pemain []Pemain) {
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if pemain[j].Gol > pemain[maxIdx].Gol ||
				(pemain[j].Gol == pemain[maxIdx].Gol && pemain[j].Assist > pemain[maxIdx].Assist) {
				maxIdx = j
			}
		}
		pemain[i], pemain[maxIdx] = pemain[maxIdx], pemain[i]
	}
}

func main() {
	var n int
	fmt.Scan(&n)

	var pemain []Pemain

	for i := 0; i < n; i++ {
		var nama string
		var gol, assist int
		fmt.Scan(&nama, &gol, &assist)
		pemain = append(pemain, Pemain{Nama: nama, Gol: gol, Assist: assist})
	}
	fmt.Println()

	selectionSort(pemain)

	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", p.Nama, p.Gol, p.Assist)
	}
}
