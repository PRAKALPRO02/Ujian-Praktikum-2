package main

import (
	"fmt"
	"strings"
)

const nProv = 10

type NamaProv_2311102002 [nProv]string
type PopulasiProv_2311102002 [nProv]int
type TumbuhProv_2311102002 [nProv]float64

func InputData(prov *NamaProv_2311102002, Populasi *PopulasiProv_2311102002, tumbuh *TumbuhProv_2311102002) {
	fmt.Println("Masukkan data provinsi (Nama Populasi Pertumbuhan):")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi ke-%d: ", i+1)
		fmt.Scan(&(*prov)[i], &(*Populasi)[i], &(*tumbuh)[i])
	}
}

func ProvinsiPalingCepat(tumbuh TumbuhProv_2311102002) int {
	maxIdx := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIdx] {
			maxIdx = i
		}
	}
	return maxIdx
}

func Prediksi(prov NamaProv_2311102002, Populasi PopulasiProv_2311102002, tumbuh TumbuhProv_2311102002) {
	fmt.Println("Prediksi populasi untuk provinsi dengan pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			prediksi := int(float64(Populasi[i]) * (1 + tumbuh[i]))
			fmt.Printf("%s %d\n", prov[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov NamaProv_2311102002, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) {
			return i
		}
	}
	return -1
}

func main() {
	var prov NamaProv_2311102002
	var Populasi PopulasiProv_2311102002
	var tumbuh TumbuhProv_2311102002

	// Input data untuk 10 baris pertama
	InputData(&prov, &Populasi, &tumbuh)

	// Cari provinsi dengan pertumbuhan tercepat
	tercepatIdx := ProvinsiPalingCepat(tumbuh)
	fmt.Println("Provinsi dengan pertumbuhan tercepat:", prov[tercepatIdx])

	// Input nama provinsi pada baris ke-11
	fmt.Println("Masukkan nama provinsi yang dicari:")
	var namaCari string
	fmt.Scan(&namaCari)

	cariIdx := IndeksProvinsi(prov, namaCari)
	fmt.Println("Indeks provinsi yang dicari:", cariIdx)

	Prediksi(prov, Populasi, tumbuh)
}
