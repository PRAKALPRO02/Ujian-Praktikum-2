package main

import (
	"fmt"
	"strings"
)

type Player struct {
	Nama   string
	Gol  int
	Assists int
}

func Dimas2311102002(players []Player) {
	n := len(players)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			
			if players[j].Gol > players[maxIdx].Gol || 
				(players[j].Gol == players[maxIdx].Gol && players[j].Assists > players[maxIdx].Assists) {
				maxIdx = j
			}
		}

		players[i], players[maxIdx] = players[maxIdx], players[i]
	}
}

func main() {
	var n int
	fmt.Println("Jumlah pemain:")
	fmt.Scan(&n)

	players := make([]Player, n)
	fmt.Println("Masukkan data pemain (Nama, Jumlah Gol, Jumlah Assist):")
	for i := 0; i < n; i++ {
		var firstNama, lastNama string
		var Gol, assists int
		fmt.Scan(&firstNama, &lastNama, &Gol, &assists)
		players[i] = Player{
			Nama:    firstNama + " " + lastNama,
			Gol:   Gol,
			Assists: assists,
		}
	}

	Dimas2311102002(players)

	fmt.Println("Peringkat Teratas:")
	for _, player := range players {
		fmt.Printf("%s %d %d\n", strings.ReplaceAll(player.Nama, " ", ""), player.Gol, player.Assists)
	}
}