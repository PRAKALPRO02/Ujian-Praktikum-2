package main

import "fmt"

const nMax = 51

type mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type arrayMahasiswaDIMAS2311102002 [nMax]mahasiswa

func inputMahasiswa(arr *arrayMahasiswaDIMAS2311102002, n *int) {
	fmt.Println("Masukkan jumlah data mahasiswa:")
	fmt.Scan(n)
	for i := 0; i < *n; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d (NIM, Nama, Nilai):\n", i+1)
		fmt.Scan(&arr[i].NIM, &arr[i].Nama, &arr[i].Nilai)
	}
}

func mencariNilaiPertama(arr arrayMahasiswaDIMAS2311102002, n int, NIM string) int {
	for i := 0; i < n; i++ {
		if arr[i].NIM == NIM {
			return arr[i].Nilai
		}
	}
	return -1
}

func mencariNilaiTerbesar(arr arrayMahasiswaDIMAS2311102002, n int, NIM string) int {
	maxNilai := -1
	for i := 0; i < n; i++ {
		if arr[i].NIM == NIM && arr[i].Nilai > maxNilai {
			maxNilai = arr[i].Nilai
		}
	}
	return maxNilai
}

func tampilkanHasil(Nilai int, pesan string) {
	if Nilai == -1 {
		fmt.Println("Data tidak ditemukan.")
	} else {
		fmt.Printf("%s: %d\n", pesan, Nilai)
	}
}

func main() {
	var data arrayMahasiswaDIMAS2311102002
	var n int
	var NIM string

	inputMahasiswa(&data, &n)

	fmt.Println("NIM mahasiswa yang dicari:")
	fmt.Scan(&NIM)

	NilaiPertama := mencariNilaiPertama(data, n, NIM)
	tampilkanHasil(NilaiPertama, "Nilai pertama mahasiswa")

	NilaiTerbesar := mencariNilaiTerbesar(data, n, NIM)
	tampilkanHasil(NilaiTerbesar, "Nilai terbesar mahasiswa")
}
