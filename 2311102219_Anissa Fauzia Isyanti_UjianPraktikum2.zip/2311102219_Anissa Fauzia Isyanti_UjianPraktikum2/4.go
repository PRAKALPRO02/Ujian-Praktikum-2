// Nama	: Anissa Fauzia Isyanti
// NIM		: 2311102219
// Kelas	: S1IF-11-02

package main

import "fmt"

// Struct untuk menyimpan data pemain
type Player struct {
	Name    string
	Goals   int
	Assists int
}

// Fungsi untuk membaca input data pemain
func inputPlayers(n int) []Player {
	players := make([]Player, n)
	i := 0
	for i < n {
		var firstName, lastName string
		var goals, assists int
		// Membaca nama pemain, gol, dan assist
		fmt.Scan(&firstName, &lastName, &goals, &assists)
		players[i] = Player{
			Name:    firstName + " " + lastName,
			Goals:   goals,
			Assists: assists,
		}
		i++
	}
	return players
}

// Fungsi untuk mengurutkan pemain menggunakan Selection Sort
func selectionSort(players []Player) {
	n := len(players)
	i := 0
	for i < n-1 {
		maxIdx := i
		// Mencari pemain dengan gol terbanyak atau jika gol sama, berdasarkan assist
		j := i + 1
		for j < n {
			if players[j].Goals > players[maxIdx].Goals ||
				(players[j].Goals == players[maxIdx].Goals && players[j].Assists > players[maxIdx].Assists) {
				maxIdx = j
			}
			j++
		}
		// Tukar posisi pemain
		players[i], players[maxIdx] = players[maxIdx], players[i]
		i++
	}
}

// Fungsi untuk mencetak hasil peringkat pemain
func printPlayers(players []Player) {
	i := 0
	for i < len(players) {
		fmt.Printf("%s %d %d\n", players[i].Name, players[i].Goals, players[i].Assists)
		i++
	}
}

// Fungsi utama
func main() {
	var n int
	// Membaca jumlah pemain
	fmt.Print("Masukkan Jumlah Pencetak Gol: ")
	fmt.Scan(&n)
	// Membaca data pemain
	fmt.Println("Masukkan Nama Pemain, Jumlah Gol, Jumlah Assist: ")
	players := inputPlayers(n)
	// Mengurutkan pemain berdasarkan gol dan assist
	selectionSort(players)
	// Menampilkan hasil peringkat
	fmt.Println("\nUrutan Peringkat dari Tertinggi: ")
	printPlayers(players)
}
