package main

import (
	"fmt"
)

const nMax = 51

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type ArrayMahasiswa [nMax]Mahasiswa

func inputData(data *ArrayMahasiswa, N *int) {
	fmt.Print("Masukkan jumlah data mahasiswa (N): ")
	fmt.Scanln(N)

	for i := 0; i < *N; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scanln(&data[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scanln(&data[i].Nama)
		fmt.Print("Nilai: ")
		fmt.Scanln(&data[i].Nilai)
	}
}
func cariNilaiPertama(data ArrayMahasiswa, N int, NIM string) int {
	for i := 0; i < N; i++ {
		if data[i].NIM == NIM {
			return data[i].Nilai
		}
	}
	return -1
}

func cariNilaiTerbesar(data ArrayMahasiswa, N int, NIM string) int {
	maxNilai := -1
	found := false
	for i := 0; i < N; i++ {
		if data[i].NIM == NIM {
			if !found || data[i].Nilai > maxNilai {
				maxNilai = data[i].Nilai
				found = true
			}
		}
	}
	if found {
		return maxNilai
	}
	return -1
}

func tampilkanHasil(data ArrayMahasiswa, N int, NIM string) {
	nilaiPertama := cariNilaiPertama(data, N, NIM)
	nilaiTerbesar := cariNilaiTerbesar(data, N, NIM)

	fmt.Printf("Hasil pencarian untuk NIM %s:\n", NIM)
	if nilaiPertama != -1 {
		fmt.Printf("Nilai pertama: %d\n", nilaiPertama)
	} else {
		fmt.Println("NIM tidak ditemukan.")
	}

	if nilaiTerbesar != -1 {
		fmt.Printf("Nilai terbesar: %d\n", nilaiTerbesar)
	} else {
		fmt.Println("NIM tidak ditemukan.")
	}
}

func main() {
	var data ArrayMahasiswa
	var N int
	var cariNIM string

	inputData(&data, &N)

	fmt.Print("Masukkan NIM yang akan dicari: ")
	fmt.Scanln(&cariNIM)

	tampilkanHasil(data, N, cariNIM)
}
