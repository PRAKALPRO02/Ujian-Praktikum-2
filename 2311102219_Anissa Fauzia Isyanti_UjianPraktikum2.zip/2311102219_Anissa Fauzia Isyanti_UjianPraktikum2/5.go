package main

import (
	"fmt"
	"sort"
)

const NMAX = 1000000

type Partai struct {
	Nama  int
	Suara int
}

type TabPartai []Partai

func posisi(t TabPartai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if t[i].Nama == nama {
			return i
		}
	}
	return -1
}

func main() {
	var p TabPartai
	partaiCount := 0
	var input int

	fmt.Println("Masukkan suara partai (akhiri dengan -1):")

	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}

		idx := posisi(p, partaiCount, input)
		if idx != -1 {
			p[idx].Suara++
		} else {
			if partaiCount < NMAX {
				p = append(p, Partai{Nama: input, Suara: 1})
				partaiCount++
			}
		}
	}

	sort.Slice(p, func(i, j int) bool {
		if p[i].Suara == p[j].Suara {
			return p[i].Nama < p[j].Nama
		}
		return p[i].Suara > p[j].Suara
	})

	for _, partai := range p {
		fmt.Printf("%d(%d) ", partai.Nama, partai.Suara)
	}
	fmt.Println()
}
