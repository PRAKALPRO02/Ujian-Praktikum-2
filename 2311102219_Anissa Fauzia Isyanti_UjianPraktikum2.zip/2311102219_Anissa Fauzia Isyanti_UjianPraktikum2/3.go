// Nama    : Anissa Fauzia Isyanti
// NIM     : 2311102219
// Kelas   : S1IF-11-02
package main

import (
	"fmt"
	"strings"
)

const nProv = 10

type (
	NamaProv   [nProv]string
	PopProv    [nProv]int
	TumbuhProv [nProv]float64
)

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data untuk provinsi ke-%d:\n", i+1)
		fmt.Print("Nama provinsi: ")
		fmt.Scanln(&prov[i])
		fmt.Print("Jumlah populasi: ")
		fmt.Scanln(&pop[i])
		fmt.Print("Angka pertumbuhan (%): ")
		fmt.Scanln(&tumbuh[i])
	}
}

func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIdx := 0
	maxTumbuh := tumbuh[0]
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > maxTumbuh {
			maxTumbuh = tumbuh[i]
			maxIdx = i
		}
	}
	return maxIdx
}

func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) {
			return i
		}
	}
	return -1
}

func Prediksi(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Prediksi populasi tahun depan untuk provinsi dengan pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2.0 {
			prediksi := float64(pop[i]) * (1 + tumbuh[i]/100)
			fmt.Printf("Provinsi: %s, Prediksi Populasi: %.0f\n", prov[i], prediksi)
		}
	}
}

func main() {
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv
	var targetProv string

	InputData(&prov, &pop, &tumbuh)

	tercepatIdx := ProvinsiTercepat(tumbuh)
	fmt.Printf("Provinsi dengan angka pertumbuhan tercepat: %s\n", prov[tercepatIdx])

	fmt.Print("Masukkan nama provinsi yang akan dicari: ")
	fmt.Scanln(&targetProv)

	targetIdx := IndeksProvinsi(prov, targetProv)
	if targetIdx != -1 {
		fmt.Printf("Indeks provinsi %s adalah: %d\n", targetProv, targetIdx)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan.\n", targetProv)
	}

	Prediksi(prov, pop, tumbuh)
}
