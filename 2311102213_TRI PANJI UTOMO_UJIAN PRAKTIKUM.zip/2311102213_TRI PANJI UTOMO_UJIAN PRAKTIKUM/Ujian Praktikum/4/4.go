//Nama	: Tri Panji Utomo
//NIM	: 2311102213
package main

import (
        "fmt"
        "sort"
)

func median(arr []int) float64 {
        n := len(arr)
        if n == 0 {
                return 0
        }
        sort.Ints(arr)
        if n%2 == 0 {
                return float64(arr[n/2-1]+arr[n/2]) / 2.0
        }
        return float64(arr[n/2])
}

func main() {
        const Maxcuyy = 100000 
        var data213 [Maxcuyy]int 
        var input213 int
        var count213 int

        fmt.Println("Masukkan bilangan bulat (akhiri -5313541):")

        for {
                fmt.Scan(&input213)
                if input213 == -5313541 {
                        break
                }

                if input213 != 0 {
                        if count213 < Maxcuyy {
                                data213[count213] = input213
                                count213++
                        } else {
                                fmt.Println("Array penuh!")
                        }
                } else {
                        tempdata213 := make([]int, count213)
                        copy(tempdata213, data213[:count213])

                        med := median(tempdata213)
                        fmt.Printf("Median saat ini: %.1f\n", med)
                }
        }
}