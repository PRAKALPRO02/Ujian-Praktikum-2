//Nama	: Tri Panji Utomo
//NIM	: 2311102213

package main

import (
	"fmt"
)

const nMax int = 51

type Mahasiswa struct {
	NIM    string
	Nama   string
	Nilai []int
}

type ArrayMahasiswa [nMax]Mahasiswa

func main() {
	var mahasiswa213 ArrayMahasiswa
	var N int

	fmt.Print("Masukkan jumlah mahasiswa (N): ")
	fmt.Scan(&N)

	for i := 0; i < N; i++ {
		fmt.Printf("Data mahasiswa ke-%d:\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&mahasiswa213[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&mahasiswa213[i].Nama)

		fmt.Print("Masukkan nilai-nilai (pisahkan dengan spasi, akhiri dengan -1): ")
		var nilai int
		for {
			fmt.Scan(&nilai)
			if nilai == -1 {
				break
			}
			mahasiswa213[i].Nilai = append(mahasiswa213[i].Nilai, nilai)
		}
	}

	var targetNIM string
	fmt.Print("Masukkan NIM untuk mencari data: ")
	fmt.Scan(&targetNIM)

	nilaiPertama := cariNilaiPertama(mahasiswa213, N, targetNIM)
	if nilaiPertama != -1 {
		fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah %d\n", targetNIM, nilaiPertama)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", targetNIM)
	}

	nilaiTerbesar := cariNilaiTerbesar(mahasiswa213, N, targetNIM)
	if nilaiTerbesar != -1 {
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d\n", targetNIM, nilaiTerbesar)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", targetNIM)
	}
}

func cariNilaiPertama(mahasiswa213 ArrayMahasiswa, N int, targetNIM string) int {
	for i := 0; i < N; i++ {
		if mahasiswa213[i].NIM == targetNIM {
			if len(mahasiswa213[i].Nilai) > 0 { 
				return mahasiswa213[i].Nilai[0] 
			} else {
				return -1 
			}
		}
	}
	return -1
}

func cariNilaiTerbesar(mahasiswa213 ArrayMahasiswa, N int, targetNIM string) int {
	nilaiTerbesar := -1
	for i := 0; i < N; i++ {
		if mahasiswa213[i].NIM == targetNIM {
			for _, nilai := range mahasiswa213[i].Nilai { 
				if nilai > nilaiTerbesar {
					nilaiTerbesar = nilai
				}
			}
			return nilaiTerbesar 
		}
	}
	return -1 
}