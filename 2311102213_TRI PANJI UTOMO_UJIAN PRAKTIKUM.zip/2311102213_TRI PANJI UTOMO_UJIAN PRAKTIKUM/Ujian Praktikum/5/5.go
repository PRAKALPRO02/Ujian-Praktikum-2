//Nama	: Tri Panji Utomo
//NIM	: 2311102213

package main

import (
	"fmt"
	"sort"
)

type Partai struct {
	nama  int
	suara int
}

const NMAX = 1000000

type tabPartai []Partai

func main() {
	var suara int
	var daftarPartai tabPartai

	fmt.Println("Masukkan suara (akhiri dengan -1):")
	for {
		fmt.Scan(&suara)
		if suara == -1 {
			break
		}

		idx := posisi(daftarPartai, suara)
		if idx == -1 {
			daftarPartai = append(daftarPartai, Partai{nama: suara, suara: 1})
		} else {
			daftarPartai[idx].suara++
		}
	}

	sort.Slice(daftarPartai, func(i, j int) bool {
		if daftarPartai[i].suara == daftarPartai[j].suara {
			return daftarPartai[i].nama < daftarPartai[j].nama
		}
		return daftarPartai[i].suara > daftarPartai[j].suara
	})

	fmt.Println("Hasil perolehan suara:")
	for _, partai := range daftarPartai {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}

func posisi(daftar tabPartai, nama int) int {
	for i, partai := range daftar {
		if partai.nama == nama {
			return i
		}
	}
	return -1
}