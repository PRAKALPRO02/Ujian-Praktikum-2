//Nama	: Tri Panji Utomo
//NIM	: 2311102213

package main

import (
	"fmt"
)

const JmlhProvinsi = 10

type NamaProv [JmlhProvinsi]string
type PopProv [JmlhProvinsi]int
type pertumbuhanprovProv [JmlhProvinsi]float64

func InputData(prov *NamaProv, pop *PopProv, pertumbuhanprov *pertumbuhanprovProv) {
	fmt.Println("Masukkan data provinsi (nama, populasi, pertumbuhan):")
	for i := 0; i < JmlhProvinsi; i++ {
		fmt.Printf("Provinsi ke-%d: ", i+1)
		fmt.Scanln(&prov[i], &pop[i], &pertumbuhanprov[i])
	}
}

func ProvinsiTercepat(pertumbuhanprov pertumbuhanprovProv) int {
	indeksTercepat := 0
	perpertumbuhanprovanTercepat := pertumbuhanprov[0]
	for i := 1; i < JmlhProvinsi; i++ {
		if pertumbuhanprov[i] > perpertumbuhanprovanTercepat {
			perpertumbuhanprovanTercepat = pertumbuhanprov[i]
			indeksTercepat = i
		}
	}
	return indeksTercepat
}


func Prediksi(prov NamaProv, pop PopProv, pertumbuhanprov pertumbuhanprovProv) {
	fmt.Println("Prediksi jumlah penduduk tahun depan (pertumbuhan di atas 2%):")
	for i := 0; i < JmlhProvinsi; i++ {
		if pertumbuhanprov[i] > 0.02 {
			prediksi := float64(pop[i]) + (float64(pop[i]) * pertumbuhanprov[i])
			fmt.Printf("%s: %.0f\n", prov[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < JmlhProvinsi; i++ {
		if prov[i] == nama {
			return i
		}
	}
	return -1
}

func main() {
	var prov NamaProv
	var pop PopProv
	var pertumbuhanprov pertumbuhanprovProv
	var cari string

	InputData(&prov, &pop, &pertumbuhanprov)

	indeksTercepat := ProvinsiTercepat(pertumbuhanprov)
	fmt.Printf("Provinsi dengan pertumbuhan tercepat: %s\n", prov[indeksTercepat])

	fmt.Print("Masukkan nama provinsi: ")
	fmt.Scanln(&cari)

	indeksCari := IndeksProvinsi(prov, cari)
	if indeksCari != -1 {
		fmt.Printf("Indeks provinsi %s: %d\n", cari, indeksCari)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan\n", cari)
	}

	Prediksi(prov, pop, pertumbuhanprov)
}