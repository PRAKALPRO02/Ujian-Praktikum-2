package main

//NAMA : CHRIST DANIEL SANTOSO
//NIM  : 2311102305
import (
	"fmt"
	"strings"
)

const nProv = 11

type (
	NamaProv   [nProv]string
	PopProv    [nProv]int
	TumbuhProv [nProv]float64
)

func InputData(nama *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan nama provinsi ke-%d: ", i+1)
		fmt.Scanln(&nama[i])
		fmt.Printf("Masukkan populasi provinsi %s: ", nama[i])
		fmt.Scanln(&pop[i])
		fmt.Printf("Masukkan angka pertumbuhan penduduk provinsi %s (dalam desimal, misalnya 0.03 untuk 3%%): ", nama[i])
		fmt.Scanln(&tumbuh[i])
	}
}

func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maksIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maksIndex] {
			maksIndex = i
		}
	}
	return maksIndex
}

func IndeksProvinsi(nama NamaProv, target string) int {
	for i, n := range nama {
		if strings.EqualFold(n, target) {
			return i
		}
	}
	return -1
}

func Prediksi(nama NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Prediksi provinsi dengan pertumbuhan > 2%:")
	for i, t := range tumbuh {
		if t > 0.02 {
			prediksi := float64(pop[i]) * (1 + t)
			fmt.Printf("%s: Populasi tahun depan = %.0f\n", nama[i], prediksi)
		}
	}
}

func main() {
	var (
		nama   NamaProv
		pop    PopProv
		tumbuh TumbuhProv
		cari   string
	)

	InputData(&nama, &pop, &tumbuh)

	tercepat := ProvinsiTercepat(tumbuh)
	fmt.Printf("\nProvinsi dengan pertumbuhan tercepat: %s\n", nama[tercepat])

	fmt.Print("\nMasukkan nama provinsi yang ingin dicari: ")
	fmt.Scanln(&cari)
	indeks := IndeksProvinsi(nama, cari)
	if indeks != -1 {
		fmt.Printf("Provinsi %s ditemukan pada indeks %d\n", cari, indeks)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan\n", cari)
	}

	fmt.Println()
	Prediksi(nama, pop, tumbuh)
}
