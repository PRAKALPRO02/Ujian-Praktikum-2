package main
			NAMA : CHRIST DANIEL SANTOSO
			NIM  : 2311102305

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

type Player struct {
	Name    string
	Goals   int
	Assists int
}

func readInput() ([]Player, error) {
	scanner := bufio.NewScanner(os.Stdin)

	fmt.Print("Masukkan jumlah pemain: ")
	if !scanner.Scan() {
		return nil, fmt.Errorf("gagal membaca jumlah pemain")
	}
	n, err := strconv.Atoi(scanner.Text())
	if err != nil || n <= 0 {
		return nil, fmt.Errorf("input jumlah pemain tidak valid")
	}

	players := make([]Player, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama Depan, Nama Belakang, Gol, Assist): ", i+1)
		if !scanner.Scan() {
			return nil, fmt.Errorf("gagal membaca data pemain")
		}
		data := strings.Fields(scanner.Text())
		if len(data) != 4 {
			return nil, fmt.Errorf("data pemain tidak lengkap")
		}
		goals, err := strconv.Atoi(data[2])
		if err != nil {
			return nil, fmt.Errorf("gol harus berupa angka")
		}
		assists, err := strconv.Atoi(data[3])
		if err != nil {
			return nil, fmt.Errorf("assist harus berupa angka")
		}
		players[i] = Player{
			Name:    data[0] + " " + data[1],
			Goals:   goals,
			Assists: assists,
		}
	}

	return players, nil
}

func sortPlayers(players []Player) {
	sort.SliceStable(players, func(i, j int) bool {
		if players[i].Goals != players[j].Goals {
			return players[i].Goals > players[j].Goals
		}
		return players[i].Assists > players[j].Assists
	})
}

func main() {
	players, err := readInput()
	if err != nil {
		fmt.Println("Error:", err)
		return
	}

	sortPlayers(players)

	fmt.Println("\nHasil pengurutan pemain:")
	for _, player := range players {
		fmt.Printf("%s %d %d\n", player.Name, player.Goals, player.Assists)
	}
}
