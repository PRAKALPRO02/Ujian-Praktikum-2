package main

import (
	"fmt"
	"sort"
	"strings"
)

type Player struct {
	Name    string
	Goals   int
	Assists int
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	players := make([]Player, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama JumlahGol JumlahAssist): ", i+1)
		var name string
		var goals, assists int
		fmt.Scan(&name, &goals, &assists)

		// Format ulang nama jika terdiri dari 2 kata
		if strings.Contains(name, "_") {
			name = strings.Replace(name, "_", " ", -1)
		}
		players[i] = Player{Name: name, Goals: goals, Assists: assists}
	}

	// Sort pemain berdasarkan jumlah gol dan assist
	sort.Slice(players, func(i, j int) bool {
		if players[i].Goals == players[j].Goals {
			return players[i].Assists > players[j].Assists
		}
		return players[i].Goals > players[j].Goals
	})

	// Cetak hasil sorting
	fmt.Println("\nPemain dengan urutan peringkat:")
	for i, player := range players {
		fmt.Printf("%d. %s %d %d\n", i+1, player.Name, player.Goals, player.Assists)
	}
}
