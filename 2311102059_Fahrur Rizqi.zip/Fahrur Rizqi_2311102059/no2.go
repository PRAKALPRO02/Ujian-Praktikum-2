package main

import "fmt"

const maxMahasiswa = 51

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type ArrayMahasiswa [maxMahasiswa]Mahasiswa

func main() {
	var arrMahasiswa ArrayMahasiswa
	var n int

	// Membaca jumlah mahasiswa
	fmt.Print("Masukkan jumlah mahasiswa: ")
	fmt.Scanln(&n)

	// Membaca data mahasiswa
	for i := 0; i < n; i++ {
		fmt.Printf("Mahasiswa ke-%d\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scanln(&arrMahasiswa[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scanln(&arrMahasiswa[i].Nama)
		fmt.Print("Nilai: ")
		fmt.Scanln(&arrMahasiswa[i].Nilai)
	}

	// Mencari nilai pertama dan terbesar untuk NIM tertentu
	var nimCari string
	fmt.Print("Masukkan NIM yang ingin dicari: ")
	fmt.Scanln(&nimCari)

	nilaiPertama := -1
	nilaiTerbesar := -1
	for _, mhs := range arrMahasiswa {
		if mhs.NIM == nimCari {
			if nilaiPertama == -1 {
				nilaiPertama = mhs.Nilai
			}
			if mhs.Nilai > nilaiTerbesar {
				nilaiTerbesar = mhs.Nilai
			}
		}
	}

	// Menampilkan hasil
	fmt.Printf("Nilai pertama mahasiswa dengan NIM %s: %d\n", nimCari, nilaiPertama)
	fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s: %d\n", nimCari, nilaiTerbesar)
}
