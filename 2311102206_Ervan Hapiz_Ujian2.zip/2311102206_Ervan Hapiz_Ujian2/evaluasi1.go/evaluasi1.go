package main

import "fmt"

// Ervan Hapiz 2311102206
// Ervan Hapiz 2311102206

type set [2022]int

func exist(T206 set, n int, V int) bool {
	for i := 0; i < n; i++ {
		if V == T206[i] {
			return true
		}
	}
	return false
}

func input(T206 *set, n *int) {
	var V int

	for {
		fmt.Scan(&V)
		if exist(*T206, *n, V) == true {
			break
		}
		T206[*n] = V
		*n++
	}
}

func findIntersection(T1, T2 set, n, n2 int, T3 *set, n3 *int) {
	*n3 = 0
	for i := 0; i < n; i++ {
		if exist(T2, n2, T1[i]) {
			T3[*n3] = T1[i]
			*n3++
		}
	}
}

func printSet(T206 set, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("%d ", T206[i])
	}
	fmt.Println()
}

func main() {
	var s1, s2, s3 set
	var n, n2, n3 int

	fmt.Println("duplikat untuk berhenti")
	fmt.Print("Masukkan Pertama :")
	input(&s1, &n)

	fmt.Print("Masukkan Kedua   :")
	input(&s2, &n2)

	findIntersection(s1, s2, n, n2, &s3, &n3)

	fmt.Print("Irisan kedua himpunan :")
	printSet(s3, n3)
}
