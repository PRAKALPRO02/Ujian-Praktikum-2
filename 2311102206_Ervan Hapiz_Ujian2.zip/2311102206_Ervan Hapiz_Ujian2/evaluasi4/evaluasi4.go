package main

import "fmt"

//Ervan Hapiz 2311102206

type Pemain struct {
	Nama   string
	Gol    int
	assist int
}

func selectionSort(arr []Pemain) {
	n := len(arr)
	for i := 0; i < n-1; i++ {
		minIdx := i
		for j := i + 1; j < n; j++ {
			if arr[j].Gol > arr[minIdx].Gol || (arr[j].Gol == arr[minIdx].Gol && arr[j].assist > arr[minIdx].assist) {

				minIdx = j
			}
		}
		arr[i], arr[minIdx] = arr[minIdx], arr[i]
	}
}
func main() {

	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)
	pemain := make([]Pemain, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan (nama, jumlah, dan assist) ke-%d: ", i+1)
		fmt.Scan(&pemain[i].Nama, &pemain[i].Gol, &pemain[i].assist)
	}

	selectionSort(pemain)

	fmt.Println("Pemain setelah diurutkan:")
	for _, player := range pemain {
		fmt.Printf("%s - Gol: %d, assist: %d\n", player.Nama, player.Gol, player.assist)
	}
}
