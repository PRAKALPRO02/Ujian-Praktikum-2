package main

import "fmt"
//Ervan Hapiz 2311102206
const NMAX = 1000000

type Partai struct {
	Nama  int
	Suara int
}

func insertionSort(daftarPartai []Partai) {
	n := len(daftarPartai)
	for i := 1; i < n; i++ {
		key := daftarPartai[i]
		j := i - 1
		for j >= 0 && daftarPartai[j].Suara < key.Suara {
			daftarPartai[j+1] = daftarPartai[j]
			j = j - 1
		}
		daftarPartai[j+1] = key
	}
}
func posisi(daftarPartai []Partai, nama int) {
	n := len(daftarPartai)
	for i := 0; i < n; i++ {
		if nama == daftarPartai[i].Nama {
			fmt.Print("Partai yang di cari ditemukan : ", daftarPartai[i].Nama, " dengan suara : ", daftarPartai[i].Suara)
		}
	}
}

func main() {
	var suara [NMAX]int
	var input int

	fmt.Println("Masukkan suara partai (akhiri dengan -1):")
	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		suara[input]++
	}

	var daftarPartai []Partai
	for i := 0; i < NMAX; i++ {
		if suara[i] > 0 {
			daftarPartai = append(daftarPartai, Partai{Nama: i, Suara: suara[i]})
		}
	}

	insertionSort(daftarPartai)

	fmt.Println("Hasil perolehan suara:")
	for _, partai := range daftarPartai {
		fmt.Printf("%d(%d) ", partai.Nama, partai.Suara)
	}
	fmt.Println()
	var cari int
	fmt.Print("Masukan partai yang dicari : ")
	fmt.Scan(&cari)
	posisi(daftarPartai, cari)

}
