package main

import "fmt"

// Ervan Hapiz 2311102206
// Ervan hapiz 2311102206

const nmax = 51

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type ArrayMahasiswa [nmax]Mahasiswa

func nilaiPertama(data ArrayMahasiswa, n206 int, nim string) int {
	for i := 0; i < n206; i++ {
		if data[i].NIM == nim {
			return data[i].Nilai
		}
	}
	return -1
}

func nilaiTerbesar(data ArrayMahasiswa, n206 int, nim string) int {
	maxNilai := -1
	for i := 0; i < n206; i++ {
		if data[i].NIM == nim && data[i].Nilai > maxNilai {
			maxNilai = data[i].Nilai
		}
	}
	return maxNilai
}

func main() {
	var n206 int
	var data ArrayMahasiswa

	fmt.Print("Masukkan jumlah data mahasiswa: ")
	fmt.Scan(&n206)
	fmt.Println("Masukkan Nim, Nama, Nilai")
	for i := 0; i < n206; i++ {
		fmt.Printf("Mahasiswa ke-%d : ", i+1)
		fmt.Scan(&data[i].NIM, &data[i].Nama, &data[i].Nilai)
	}

	var nim string
	fmt.Print("Masukkan NIM Yang Akan Dicari: ")
	fmt.Scan(&nim)

	nilaiPertama := nilaiPertama(data, n206, nim)
	nilaiTerbesar := nilaiTerbesar(data, n206, nim)

	fmt.Printf("Nilai pertama mahasiswa dengan NIM %s: %d\n", nim,nilaiPertama)
	fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s: %d\n", nim, nilaiTerbesar)
}
