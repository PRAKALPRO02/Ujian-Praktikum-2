package main

import "fmt"

// Ervan Hapiz 2311102206
const nProv = 9

type Provensi struct {
	Nama_Provensi        string
	Populasi_Provensi    int
	Pertumbuhan_Provensi float64
}

type Prov [nProv]Provensi

func ProvinsiTercepat(arr Prov) int {
	maxIdx := 0
	for i := 1; i < nProv; i++ {
		if arr[i].Pertumbuhan_Provensi > arr[maxIdx].Pertumbuhan_Provensi {
			maxIdx = i
		}
	}
	return maxIdx
}
func Prediksi(arr Prov) {
	for i := 0; i < nProv; i++ {
		if arr[i].Pertumbuhan_Provensi > 2.0 {
			prediksiPop := float64(arr[i].Populasi_Provensi) * (1 + arr[i].Pertumbuhan_Provensi/100)
			fmt.Printf("%s: %.0f\n", arr[i].Nama_Provensi, prediksiPop)
		}
	}
}

func CariProvensi(arr Prov, nama string) int {
	for i := 0; i < nProv; i++ {
		if arr[i].Nama_Provensi == nama {
			return i+1
		}
	}
	return -1
}

func main() {
	var prov Prov
	var provDicari string

	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan (Nama, populasi, pertumbuhan)provensi ke-%v: ", i+1)
		fmt.Scan(&prov[i].Nama_Provensi, &prov[i].Populasi_Provensi, &prov[i].Pertumbuhan_Provensi)
	}

	fmt.Print("Masukkan nama provinsi yang akan dicari: ")
	fmt.Scan(&provDicari)

	idxTercepat := ProvinsiTercepat(prov)
	fmt.Println("Provinsi dengan angka pertumbuhan tercepat adalah:", prov[idxTercepat])


	idxProvinsi := CariProvensi(prov, provDicari)
	fmt.Println("Indeks provinsi yang dicari:", idxProvinsi)

	
	fmt.Println("Prediksi jumlah penduduk untuk provinsi dengan pertumbuhan di atas 2%:")
	Prediksi(prov)
}
