// ALIFATUS SHABRINA AMALIA
// 2311102225
// S1 - IF - 11 - 02

package main

import (
	"fmt"
	"sort"
)

const MAX = 1000000

// Struct untuk menyimpan data partai
type Partai struct {
	nama  int
	suara int
}

// Fungsi untuk mencari indeks partai berdasarkan nama
func posisi(tabelPartai []Partai, nama int) int {
	for i, partai := range tabelPartai {
		if partai.nama == nama {
			return i
		}
	}
	return -1
}

// Fungsi untuk mencetak hasil perolehan suara
func cetakHasil(tabelPartai []Partai) {
	for _, partai := range tabelPartai {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}

func main() {
	// Deklarasi array untuk menyimpan perolehan suara partai
	tabelPartai := []Partai{}

	// Proses input suara
	var suara int
	for {
		fmt.Scan(&suara)
		if suara == -1 {
			break
		}
		// Cari apakah partai sudah ada di tabel
		index := posisi(tabelPartai, suara)
		if index != -1 {
			// Jika sudah ada, tambahkan jumlah suara
			tabelPartai[index].suara++
		} else {
			// Jika belum ada, tambahkan partai baru
			tabelPartai = append(tabelPartai, Partai{nama: suara, suara: 1})
		}
	}

	// Mengurutkan tabel partai secara descending berdasarkan suara
	sort.Slice(tabelPartai, func(i, j int) bool {
		if tabelPartai[i].suara == tabelPartai[j].suara {
			return tabelPartai[i].nama < tabelPartai[j].nama
		}
		return tabelPartai[i].suara > tabelPartai[j].suara
	})

	// Tampilkan hasil
	cetakHasil(tabelPartai)
}
