// ALIFATUS SHABRINA AMALIA
// 2311102225
// S1 - IF - 11 - 02

package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

const nProv = 10

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

// Procedure InputData
func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	reader := bufio.NewReader(os.Stdin) // Untuk membaca input string

	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data provinsi ke-%d:\n", i+1)

		// Membaca nama provinsi
		fmt.Print("  Nama Provinsi: ")
		prov[i], _ = reader.ReadString('\n')
		prov[i] = strings.TrimSpace(prov[i]) // Menghapus karakter newline di akhir input

		// Membaca populasi
		fmt.Print("  Populasi: ")
		fmt.Scan(&pop[i])

		// Membaca angka pertumbuhan
		fmt.Print("  Angka Pertumbuhan: ")
		fmt.Scan(&tumbuh[i])

		// Kosongkan buffer input untuk menghindari masalah newline
		reader.ReadString('\n')
	}
}

// Function ProvinsiTercepat
func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIndex := 0
	maxGrowth := tumbuh[0]

	for i := 1; i < nProv; i++ {
		if tumbuh[i] > maxGrowth {
			maxGrowth = tumbuh[i]
			maxIndex = i
		}
	}
	return maxIndex
}

// Procedure TampilkanData
func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Provinsi dengan pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2.0 {
			prediksi := float64(pop[i]) * (1 + tumbuh[i]/100)
			fmt.Printf("  %s: Populasi saat ini %d, Prediksi tahun depan %.0f\n", prov[i], pop[i], prediksi)
		}
	}
}

// Function IndeksProvinsi
func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) {
			return i
		}
	}
	return -1
}

func main() {
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv

	// Input data
	InputData(&prov, &pop, &tumbuh)

	// Cari provinsi dengan pertumbuhan tercepat
	tercepatIndex := ProvinsiTercepat(tumbuh)
	fmt.Printf("Provinsi dengan pertumbuhan tercepat: %s\n", prov[tercepatIndex])

	// Cari indeks provinsi berdasarkan nama
	var namaDicari string
	reader := bufio.NewReader(os.Stdin) // Membaca input string dengan spasi
	fmt.Print("Masukkan nama provinsi untuk pencarian: ")
	namaDicari, _ = reader.ReadString('\n')
	namaDicari = strings.TrimSpace(namaDicari)

	indeks := IndeksProvinsi(prov, namaDicari)
	if indeks == -1 {
		fmt.Println("Provinsi tidak ditemukan.")
	} else {
		fmt.Printf("Indeks provinsi %s: %d\n", namaDicari, indeks)
	}

	// Tampilkan data provinsi dengan pertumbuhan di atas 2%
	TampilkanData(prov, pop, tumbuh)
}
