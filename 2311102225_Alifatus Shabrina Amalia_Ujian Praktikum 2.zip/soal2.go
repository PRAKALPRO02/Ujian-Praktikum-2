// ALIFATUS SHABRINA AMALIA
// 2311102225
// S1 - IF - 11 - 02

package main

import (
	"fmt"
)

const nMax = 51

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type ArrayMahasiswa [nMax]Mahasiswa

// Fungsi untuk menerima masukan data mahasiswa
func inputData(data *ArrayMahasiswa, n *int) {
	fmt.Print("Masukkan jumlah data mahasiswa (N): ")
	fmt.Scan(n)

	for i := 0; i < *n; i++ {
		fmt.Printf("Data mahasiswa ke-%d:\n", i+1)
		fmt.Print("  NIM: ")
		fmt.Scan(&data[i].NIM)
		fmt.Print("  Nama: ")
		fmt.Scan(&data[i].Nama)
		fmt.Print("  Nilai: ")
		fmt.Scan(&data[i].Nilai)
	}
}

// Fungsi untuk mencari nilai pertama berdasarkan NIM
func cariNilaiPertama(data ArrayMahasiswa, n int, nim string) int {
	for i := 0; i < n; i++ {
		if data[i].NIM == nim {
			return data[i].Nilai
		}
	}
	return -1 // Mengembalikan -1 jika NIM tidak ditemukan
}

// Fungsi untuk mencari nilai terbesar berdasarkan NIM
func cariNilaiTerbesar(data ArrayMahasiswa, n int, nim string) int {
	maxNilai := -1
	for i := 0; i < n; i++ {
		if data[i].NIM == nim && data[i].Nilai > maxNilai {
			maxNilai = data[i].Nilai
		}
	}
	return maxNilai
}

// Fungsi untuk menampilkan hasil pencarian
func tampilkanHasil(nama string, nilaiPertama, nilaiTerbesar int) {
	fmt.Printf("Nama: %s\n", nama)
	if nilaiPertama == -1 {
		fmt.Println("Nilai pertama: Tidak ditemukan")
	} else {
		fmt.Printf("Nilai pertama: %d\n", nilaiPertama)
	}
	if nilaiTerbesar == -1 {
		fmt.Println("Nilai terbesar: Tidak ditemukan")
	} else {
		fmt.Printf("Nilai terbesar: %d\n", nilaiTerbesar)
	}
}

func main() {
	var data ArrayMahasiswa
	var n int

	// Input data mahasiswa
	inputData(&data, &n)

	// Masukkan NIM yang ingin dicari
	var nim string
	fmt.Print("Masukkan NIM untuk pencarian: ")
	fmt.Scan(&nim)

	// Cari nilai pertama dan nilai terbesar
	nilaiPertama := cariNilaiPertama(data, n, nim)
	nilaiTerbesar := cariNilaiTerbesar(data, n, nim)

	// Tampilkan hasil
	if nilaiPertama != -1 {
		// Temukan nama mahasiswa berdasarkan NIM
		var nama string
		for i := 0; i < n; i++ {
			if data[i].NIM == nim {
				nama = data[i].Nama
				break
			}
		}
		tampilkanHasil(nama, nilaiPertama, nilaiTerbesar)
	} else {
		fmt.Println("Mahasiswa dengan NIM tersebut tidak ditemukan.")
	}
}
