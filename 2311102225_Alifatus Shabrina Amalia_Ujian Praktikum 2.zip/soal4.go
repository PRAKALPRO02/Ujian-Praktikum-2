// ALIFATUS SHABRINA AMALIA
// 2311102225
// S1 - IF - 11 - 02

package main

import (
	"fmt"
)

// Struktur data pemain
type Player struct {
	name    string
	goals   int
	assists int
}

// Fungsi untuk membaca input data pemain
func inputPlayers(n int) []Player {
	players := make([]Player, n)
	for i := 0; i < n; i++ {
		var firstName, lastName string
		fmt.Scan(&firstName, &lastName)
		fullName := firstName + " " + lastName
		var goals, assists int
		fmt.Scan(&goals, &assists)
		players[i] = Player{name: fullName, goals: goals, assists: assists}
	}
	return players
}

// Fungsi untuk mengurutkan data pemain menggunakan Selection Sort
func selectionSort(players []Player) {
	n := len(players)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if players[j].goals > players[maxIdx].goals ||
				(players[j].goals == players[maxIdx].goals && players[j].assists > players[maxIdx].assists) {
				maxIdx = j
			}
		}
		// Tukar posisi pemain
		players[i], players[maxIdx] = players[maxIdx], players[i]
	}
}

// Fungsi untuk menampilkan data pemain
func printPlayers(players []Player) {
	for _, player := range players {
		fmt.Printf("%s %d %d\n", player.name, player.goals, player.assists)
	}
}

func main() {
	// Input jumlah pemain
	var n int
	fmt.Scan(&n)

	// Input data pemain
	players := inputPlayers(n)

	// Urutkan data pemain
	selectionSort(players)

	// Cetak hasil
	printPlayers(players)
}
