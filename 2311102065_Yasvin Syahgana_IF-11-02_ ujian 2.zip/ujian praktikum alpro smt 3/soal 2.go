package main

import (
	"fmt"
	"strings"
)

const nMax = 51

// 2311102065
type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

func main() {
	var data [nMax]Mahasiswa
	var N int

	fmt.Print("Masukkan jumlah data mahasiswa (N): ")
	fmt.Scanln(&N)

	for i := 0; i < N; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d:\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&data[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&data[i].Nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&data[i].Nilai)
	}

	var cariNIM string
	fmt.Print("Masukkan NIM yang ingin dicari: ")
	fmt.Scan(&cariNIM)

	nilaiPertama := CariNilaiPertama(data[:N], cariNIM)

	nilaiTerbesar := CariNilaiTerbesar(data[:N], cariNIM)

	TampilkanHasil(cariNIM, nilaiPertama, nilaiTerbesar)
}

func CariNilaiPertama(data []Mahasiswa, cariNIM string) int {
	for _, m := range data {
		if strings.TrimSpace(m.NIM) == strings.TrimSpace(cariNIM) {
			return m.Nilai
		}
	}
	return -1
}

func CariNilaiTerbesar(data []Mahasiswa, cariNIM string) int {
	max := -1
	found := false
	for _, m := range data {
		if strings.TrimSpace(m.NIM) == strings.TrimSpace(cariNIM) {
			found = true
			if m.Nilai > max {
				max = m.Nilai
			}
		}
	}
	if !found {
		return -1
	}
	return max
}

func TampilkanHasil(cariNIM string, nilaiPertama, nilaiTerbesar int) {
	fmt.Printf("\nHasil pencarian untuk NIM: %s\n", cariNIM)
	if nilaiPertama != -1 {
		fmt.Printf("Nilai pertama: %d\n", nilaiPertama)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", cariNIM)
	}

	if nilaiTerbesar != -1 {
		fmt.Printf("Nilai terbesar: %d\n", nilaiTerbesar)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", cariNIM)
	}
}
