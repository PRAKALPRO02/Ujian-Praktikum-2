package main

import "fmt"

const MAX = 1000000

type Partai struct { //2311102065
	Nama  int
	Suara int
}

func main() {
	var p []Partai
	var input int

	fmt.Println("Masukkan suara partai (akhiri dengan -1):")
	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		if pos := posisi(p, input); pos != -1 {
			p[pos].Suara++
		} else {
			p = append(p, Partai{Nama: input, Suara: 1})
		}
	}

	insertionSortDescending(p)

	fmt.Println("Hasil perolehan suara partai:")
	for _, partai := range p {
		fmt.Printf("%d(%d)\n", partai.Nama, partai.Suara)
	}
}

func posisi(tabelPartai []Partai, nama int) int {
	for i, partai := range tabelPartai {
		if partai.Nama == nama {
			return i
		}
	}
	return -1
}

func insertionSortDescending(arr []Partai) {
	for i := 1; i < len(arr); i++ {
		key := arr[i]
		j := i - 1

		for j >= 0 && arr[j].Suara < key.Suara {
			arr[j+1] = arr[j]
			j--
		}

		for j >= 0 && arr[j].Suara == key.Suara && arr[j].Nama > key.Nama {
			arr[j+1] = arr[j]
			j--
		}
		arr[j+1] = key
	}
}
