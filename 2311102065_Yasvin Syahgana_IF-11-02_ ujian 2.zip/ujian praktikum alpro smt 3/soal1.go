package main

import "fmt"

type set [2022]int

// 2311102065
func exist(T set, n, val int) bool {
	for i := 0; i < n; i++ {
		if T[i] == val {
			return true
		}
	}
	return false
}

func inputSet(T *set, n *int) {
	*n = 0
	for {
		var val int
		fmt.Scan(&val)

		if exist(*T, *n, val) {
			break
		}

		T[*n] = val
		*n++
	}
}

func findIntersection(T1 set, n1 int, T2 set, n2 int, T3 *set, h *int) {
	*h = 0
	for i := 0; i < n1; i++ {
		if exist(T2, n2, T1[i]) {

			T3[*h] = T1[i]
			*h++
		}
	}
}

func printSet(T set, n int) {
	for i := 0; i < n; i++ {
		fmt.Print(T[i], " ")
	}
	fmt.Println()
}

func main() {
	var S1, S2, S3 set
	var n1, n2, n3 int

	fmt.Println("Masukkan bilangan untuk himpunan pertama (akhiri dengan duplikat):")
	inputSet(&S1, &n1)

	fmt.Println("Masukkan bilangan untuk himpunan kedua (akhiri dengan duplikat):")
	inputSet(&S2, &n2)

	findIntersection(S1, n1, S2, n2, &S3, &n3)

	fmt.Println("Irisan dari kedua himpunan adalah:")
	printSet(S3, n3)
}
