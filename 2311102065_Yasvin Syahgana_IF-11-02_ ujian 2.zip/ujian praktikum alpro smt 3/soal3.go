package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const nProv = 11

type Provinsi struct {
	Nama        string
	Populasi    int
	Pertumbuhan float64
}

func main() {
	var data [nProv]Provinsi
	var namaDicari string
	scanner := bufio.NewScanner(os.Stdin)

	// Input data 11 provinsi
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data provinsi ke-%d:\n", i+1)

		// Input nama provinsi (dengan spasi)
		fmt.Print("Nama provinsi: ")
		scanner.Scan()
		data[i].Nama = scanner.Text()

		// Input populasi
		fmt.Print("Populasi (dalam juta): ")
		scanner.Scan()
		data[i].Populasi, _ = strconv.Atoi(scanner.Text())

		// Input angka pertumbuhan
		fmt.Print("Angka pertumbuhan (%): ")
		scanner.Scan()
		data[i].Pertumbuhan, _ = strconv.ParseFloat(scanner.Text(), 64)
	}

	// Input nama provinsi yang ingin dicari
	fmt.Print("Masukkan nama provinsi yang ingin dicari: ")
	scanner.Scan()
	namaDicari = scanner.Text()

	// 1. Temukan provinsi dengan angka pertumbuhan tercepat
	tercepatIdx := CariProvinsiTercepat(data[:])
	fmt.Printf("1. Provinsi dengan angka pertumbuhan tercepat: %s\n", data[tercepatIdx].Nama)

	// 2. Cari indeks dari provinsi yang dicari
	cariIdx := CariIndeksProvinsi(data[:], namaDicari)
	if cariIdx == -1 {
		fmt.Printf("2. Provinsi %s tidak ditemukan.\n", namaDicari)
	} else {
		fmt.Printf("2. Indeks provinsi %s: %d\n", namaDicari, cariIdx+1)
	}

	// 3. Tampilkan maksimal 9 provinsi dengan pertumbuhan di atas 2%
	fmt.Println("Provinsi dengan angka pertumbuhan di atas 2%:")
	count := 0
	for _, prov := range data {
		if prov.Pertumbuhan > 2.0 {
			prediksi := float64(prov.Populasi) * (1 + prov.Pertumbuhan/100)
			fmt.Printf("%s - Populasi saat ini: %d juta, Prediksi: %.2f juta\n", prov.Nama, prov.Populasi, prediksi)
			count++
		}
		if count == 9 { // Batas maksimal 9 baris
			break
		}
	}
}

// Cari indeks provinsi dengan angka pertumbuhan tercepat
func CariProvinsiTercepat(data []Provinsi) int {
	maxIdx := 0
	for i := 1; i < len(data); i++ {
		if data[i].Pertumbuhan > data[maxIdx].Pertumbuhan {
			maxIdx = i
		}
	}
	return maxIdx
}

// Cari indeks berdasarkan nama provinsi
func CariIndeksProvinsi(data []Provinsi, nama string) int {
	for i, prov := range data {
		if strings.EqualFold(prov.Nama, nama) { // Perbandingan tidak case-sensitive
			return i
		}
	}
	return -1
}
