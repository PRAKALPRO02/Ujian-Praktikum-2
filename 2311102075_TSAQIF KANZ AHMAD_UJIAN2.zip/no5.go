package main

import (
	"fmt"
)

const MAX = 1000000

type Partai struct {
	Nama  int
	Suara int
}

func main() {
	var suaraPartai [MAX]int

	fmt.Println("Masukkan suara:")
	var input int
	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		if input >= 1 && input <= MAX {
			suaraPartai[input-1]++
		}
	}

	var hasil []Partai
	for i := 0; i < MAX; i++ {
		if suaraPartai[i] > 0 {
			hasil = append(hasil, Partai{Nama: i + 1, Suara: suaraPartai[i]})
		}
	}

	insertionSort(hasil)

	fmt.Println("Hasil perolehan suara:")
	for _, p := range hasil {
		fmt.Printf("%d(%d) ", p.Nama, p.Suara)
	}
	fmt.Println()
}

func insertionSort(partai []Partai) {
	n := len(partai)
	for i := 1; i < n; i++ {
		key := partai[i]
		j := i - 1

		for j >= 0 && partai[j].Suara < key.Suara {
			partai[j+1] = partai[j]
			j--
		}
		partai[j+1] = key
	}
}
