package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type Pemain struct {
	Nama   string
	Gol    int
	Assist int
}

func main() {
	var n int

	fmt.Print("Masukkan jumlah pencetak gol: ")
	fmt.Scan(&n)

	if n < 1 || n > 1001 {
		fmt.Println("Jumlah pemain harus antara 1 dan 1001.")
		return
	}

	pemain := make([]Pemain, n)
	reader := bufio.NewReader(os.Stdin)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama, Gol, Assist): ", i+1)
		input, _ := reader.ReadString('\n')
		data := strings.Fields(input)

		if len(data) < 4 {
			fmt.Println("Input tidak valid. Harus terdiri dari Nama depan, Nama belakang, Gol, dan Assist.")
			return
		}

		nama := data[0] + " " + data[1]
		gol, errGol := strconv.Atoi(data[2])
		assist, errAssist := strconv.Atoi(data[3])

		if errGol != nil || errAssist != nil {
			fmt.Println("Gol dan Assist harus berupa angka.")
			return
		}

		pemain[i] = Pemain{Nama: nama, Gol: gol, Assist: assist}
	}

	insertionSort(pemain)

	fmt.Println("Peringkat pencetak gol:")
	for i, p := range pemain {
		fmt.Printf("%d. %s - Gol: %d, Assist: %d\n", i+1, p.Nama, p.Gol, p.Assist)
	}
}

func insertionSort(pemain []Pemain) {
	n := len(pemain)
	for i := 1; i < n; i++ {
		key := pemain[i]
		j := i - 1

		for j >= 0 && (pemain[j].Gol < key.Gol || (pemain[j].Gol == key.Gol && pemain[j].Assist < key.Assist)) {
			pemain[j+1] = pemain[j]
			j--
		}
		pemain[j+1] = key
	}
}
