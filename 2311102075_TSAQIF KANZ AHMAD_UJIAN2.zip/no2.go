// Tsaqif Kanz Ahmad
// 2311102075
package main

import (
	"fmt"
)

const maxJumlahMahasiswa = 51

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

func main() {
	var daftarMahasiswa [maxJumlahMahasiswa]Mahasiswa
	var totalMahasiswa int

	fmt.Print("Masukkan jumlah mahasiswa: ")
	fmt.Scan(&totalMahasiswa)

	if totalMahasiswa > maxJumlahMahasiswa {
		fmt.Printf("Maksimum jumlah mahasiswa yang dapat dimasukkan adalah %d.\n", maxJumlahMahasiswa)
		return
	}

	for i := 0; i < totalMahasiswa; i++ {
		fmt.Printf("\nMasukkan data untuk mahasiswa ke-%d:\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&daftarMahasiswa[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&daftarMahasiswa[i].Nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&daftarMahasiswa[i].Nilai)
	}

	fmt.Print("\nMasukkan NIM untuk mencari nilai pertama: ")
	var nimDicari string
	fmt.Scan(&nimDicari)

	nilaiPertama := cariNilaiPertama(daftarMahasiswa[:totalMahasiswa], nimDicari)
	if nilaiPertama == -1 {
		fmt.Println("Data mahasiswa dengan NIM tersebut tidak ditemukan.")
	} else {
		fmt.Printf("Nilai pertama untuk mahasiswa dengan NIM %s adalah %d.\n", nimDicari, nilaiPertama)
	}

	fmt.Print("\nMasukkan NIM untuk mencari nilai terbesar: ")
	fmt.Scan(&nimDicari)

	nilaiTerbesar := cariNilaiTerbesar(daftarMahasiswa[:totalMahasiswa], nimDicari)
	if nilaiTerbesar == -1 {
		fmt.Println("Data mahasiswa dengan NIM tersebut tidak ditemukan.")
	} else {
		fmt.Printf("Nilai terbesar untuk mahasiswa dengan NIM %s adalah %d.\n", nimDicari, nilaiTerbesar)
	}
}

func cariNilaiPertama(daftar []Mahasiswa, nim string) int {
	for _, mahasiswa := range daftar {
		if mahasiswa.NIM == nim {
			return mahasiswa.Nilai
		}
	}
	return -1
}

func cariNilaiTerbesar(daftar []Mahasiswa, nim string) int {
	nilaiMax := -1
	ditemukan := false

	for _, mahasiswa := range daftar {
		if mahasiswa.NIM == nim {
			ditemukan = true
			if mahasiswa.Nilai > nilaiMax {
				nilaiMax = mahasiswa.Nilai
			}
		}
	}

	if !ditemukan {
		return -1
	}
	return nilaiMax
}
