// Tsaqif Kanz Ahmad
// 2311102075
package main

import (
	"fmt"
	"strings"
)

const nProv = 10

type Provinsi struct {
	nama        string
	populasi    int
	pertumbuhan float64
}

func inputData() ([]Provinsi, string) {
	provinsi := make([]Provinsi, nProv)
	var namaCari string

	fmt.Println("Masukkan data provinsi:")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi %d:\n", i+1)
		fmt.Print("Nama: ")
		fmt.Scanln(&provinsi[i].nama)
		fmt.Print("Populasi: ")
		fmt.Scanln(&provinsi[i].populasi)
		fmt.Print("Pertumbuhan: ")
		fmt.Scanln(&provinsi[i].pertumbuhan)
	}

	fmt.Print("Masukkan nama provinsi yang ingin dicari: ")
	fmt.Scanln(&namaCari)

	return provinsi, namaCari
}

func provinsiTercepat(provinsi []Provinsi) int {
	maxIndex := 0
	maxPertumbuhan := provinsi[0].pertumbuhan

	for i := 1; i < len(provinsi); i++ {
		if provinsi[i].pertumbuhan > maxPertumbuhan {
			maxPertumbuhan = provinsi[i].pertumbuhan
			maxIndex = i
		}
	}

	return maxIndex
}

func indeksProvinsi(provinsi []Provinsi, nama string) int {
	for i, p := range provinsi {
		if strings.EqualFold(p.nama, nama) {
			return i
		}
	}
	return -1
}

func tampilkanData(provinsi []Provinsi) {
	fmt.Println("\nProvinsi dengan pertumbuhan di atas 2%:")
	for _, p := range provinsi {
		if p.pertumbuhan > 2 {
			prediksi := p.populasi + int(float64(p.populasi)*p.pertumbuhan/100)
			fmt.Printf("%s: Prediksi populasi tahun berikutnya: %d\n", p.nama, prediksi)
		}
	}
}

func main() {
	provinsi, namaCari := inputData()

	tercepatIndex := provinsiTercepat(provinsi)
	fmt.Printf("\nProvinsi dengan pertumbuhan tercepat: %s\n", provinsi[tercepatIndex].nama)

	indeks := indeksProvinsi(provinsi, namaCari)
	if indeks != -1 {
		fmt.Printf("Indeks provinsi %s: %d\n", namaCari, indeks)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan.\n", namaCari)
	}

	tampilkanData(provinsi)
}
