package main

import (
	"fmt"
	"strings"
)

const nProv = 10

type namaAhmadan_038 [nProv]string
type jumlahPopulasi_038 [nProv]int
type tumbuhPopulasi_038 [nProv]float64

func InputData(prov *namaAhmadan_038, Populasi *jumlahPopulasi_038, tumbuh *tumbuhPopulasi_038) {
	fmt.Println("Masukkan data provinsi (Nama Populasi Pertumbuhan):")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi ke-%d: ", i+1)
		fmt.Scan(&(*prov)[i], &(*Populasi)[i], &(*tumbuh)[i])
	}
}

func ProvinsiPalingCepat(tumbuh tumbuhPopulasi_038) int {
	maxIdx := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIdx] {
			maxIdx = i
		}
	}
	return maxIdx
}

func Prediksi(prov namaAhmadan_038, Populasi jumlahPopulasi_038, tumbuh tumbuhPopulasi_038) {
	fmt.Println("Prediksi populasi untuk provinsi dengan pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			prediksi := int(float64(Populasi[i]) * (1 + tumbuh[i]))
			fmt.Printf("%s %d\n", prov[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov namaAhmadan_038, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) {
			return i
		}
	}
	return -1
}

func main() {
	var prov namaAhmadan_038
	var Populasi jumlahPopulasi_038
	var tumbuh tumbuhPopulasi_038

	InputData(&prov, &Populasi, &tumbuh)

	tercepatIdx := ProvinsiPalingCepat(tumbuh)
	fmt.Println("Provinsi dengan pertumbuhan tercepat:", prov[tercepatIdx])

	fmt.Println("Masukkan nama provinsi yang dicari:")
	var namaCari string
	fmt.Scan(&namaCari)

	cariIdx := IndeksProvinsi(prov, namaCari)
	fmt.Println("Indeks provinsi yang dicari:", cariIdx)

	Prediksi(prov, Populasi, tumbuh)
}
