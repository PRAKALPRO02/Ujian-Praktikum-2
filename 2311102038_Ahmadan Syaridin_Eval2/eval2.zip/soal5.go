package main

import (
	"fmt"
	"sort"
)

const NMAX = 1000000

type Partai struct {
	nomor int
	suara int
}

func main() {
	var suara [NMAX + 1]int
	var input int

	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		suara[input]++
	}

	var ListPartai []Partai
	for i := 1; i <= NMAX; i++ {
		if suara[i] > 0 {
			ListPartai = append(ListPartai, Partai{nomor: i, suara: suara[i]})
		}
	}

	sort.Slice(ListPartai, func(i, j int) bool {
		if ListPartai[i].suara == ListPartai[j].suara {
			return ListPartai[i].nomor < ListPartai[j].nomor
		}
		return ListPartai[i].suara > ListPartai[j].suara
	})

	for _, partai := range ListPartai {
		fmt.Printf("%d(%d) ", partai.nomor, partai.suara)
	}
	fmt.Println()
}
