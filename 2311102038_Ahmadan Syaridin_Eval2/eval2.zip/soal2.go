package main

import (
	"fmt"
)

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

func nilaiPertama038(mahasiswaArray []Mahasiswa, NIMCari string) (int, bool) {
	for _, mahasiswa := range mahasiswaArray {
		if mahasiswa.NIM == NIMCari {
			return mahasiswa.Nilai, true
		}
	}
	return 0, false
}

func nilaiTerbesar2311102038(mahasiswaArray []Mahasiswa, NIMCari string) (int, bool) {
	nilaiTerbesar := -1
	found := false
	for _, mahasiswa := range mahasiswaArray {
		if mahasiswa.NIM == NIMCari {
			if !found || mahasiswa.Nilai > nilaiTerbesar {
				nilaiTerbesar = mahasiswa.Nilai
			}
			found = true
		}
	}
	return nilaiTerbesar, found
}

func main() {
	var N int
	fmt.Print("Masukkan jumlah data mahasiswa: ")
	fmt.Scan(&N)

	mahasiswaArray := make([]Mahasiswa, 0, N)
	for i := 0; i < N; i++ {
		fmt.Printf("\nMasukkan data mahasiswa ke-%d:\n", i+1)
		var NIM, Nama string
		var Nilai int
		fmt.Print("NIM: ")
		fmt.Scan(&NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&Nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&Nilai)

		mahasiswaArray = append(mahasiswaArray, Mahasiswa{NIM, Nama, Nilai})
	}
	var NIMCari string
	fmt.Print("\nMasukkan NIM mahasiswa yang ingin dicari: ")
	fmt.Scan(&NIMCari)

	nilaiPertama, foundPertama := nilaiPertama038(mahasiswaArray, NIMCari)
	if foundPertama {
		fmt.Printf("\nNilai pertama mahasiswa dengan NIM %s adalah %d\n", NIMCari, nilaiPertama)
	} else {
		fmt.Printf("\nMahasiswa dengan NIM %s tidak ditemukan.\n", NIMCari)
	}

	nilaiTerbesar, foundTerbesar := nilaiTerbesar2311102038(mahasiswaArray, NIMCari)
	if foundTerbesar {
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d\n", NIMCari, nilaiTerbesar)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", NIMCari)
	}
}
