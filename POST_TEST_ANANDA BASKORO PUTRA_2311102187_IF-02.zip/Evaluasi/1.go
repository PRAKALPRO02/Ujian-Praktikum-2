package main

import (
	"fmt"
	"strconv"
)

func main() {
	var input_2311102187 int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scan(&input_2311102187)

	strInput := strconv.Itoa(input_2311102187)
	length := len(strInput)

	mid := length / 2

	var bagiankiri, bagiankanan string
	if length%2 == 0 {
		
		bagiankiri = strInput[:mid]
		bagiankanan = strInput[mid:]
	} else {
		
		bagiankiri = strInput[:mid+1]
		bagiankanan = strInput[mid+1:]
	}

	kiriNum, _ := strconv.Atoi(bagiankiri)
	kananNum, _ := strconv.Atoi(bagiankanan)

	fmt.Println("Bilangan 1:", kiriNum)
	fmt.Println("Bilangan 2:", kananNum)
	fmt.Println("Hasil penjumlahan:", kiriNum+kananNum)
}

