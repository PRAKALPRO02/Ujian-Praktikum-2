package main

import (
	"fmt"
	"strconv"
)

func checkHadiah(nomorKartu int) string {
	strKartu := strconv.Itoa(nomorKartu)

	allSame := true
	allDifferent := true
	for i := 1; i < len(strKartu); i++ {
		if strKartu[i] != strKartu[i-1] {
			allSame = false
		} else {
			allDifferent = false
		}
	}

	if allSame {
		return "Hadiah A"
	} else if allDifferent {
		return "Hadiah B"
	} else {
		return "Hadiah C"
	}
}

func inputNomorKartu_2311102187(i int) int {
	var nomorKartu int
	fmt.Printf("Masukkan nomor kartu peserta %d: ", i)
	fmt.Scan(&nomorKartu)
	return nomorKartu
}

func tampilkanHadiahPeserta(i int, hasilHadiah string) {
	fmt.Printf("Peserta %d: %s\n", i, hasilHadiah)
}

func tampilkanTotalHadiah(hadiahCounts map[string]int) {
	fmt.Println("Total per jenis hadiah:")
	for hadiah, count := range hadiahCounts {
		fmt.Printf("%s: %d\n", hadiah, count)
	}
}

func main() {
	var N int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scan(&N)

	hadiahCounts := map[string]int{"Hadiah A": 0, "Hadiah B": 0, "Hadiah C": 0}

	for i := 1; i <= N; i++ {
		nomorKartu := inputNomorKartu_2311102187(i)
		hasilHadiah := checkHadiah(nomorKartu)
		tampilkanHadiahPeserta(i, hasilHadiah)

		hadiahCounts[hasilHadiah]++
	}

	tampilkanTotalHadiah(hadiahCounts)
}
