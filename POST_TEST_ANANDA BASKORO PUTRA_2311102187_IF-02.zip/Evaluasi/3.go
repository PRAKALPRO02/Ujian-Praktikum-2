package main

import (
	"fmt"
)

func hitungPerkalian(x int, y int) int {
	if y < 0 {
		return 0
	}

	hasil := 0
	for i := 0; i < y; i++ {
		hasil += x 
	}
	return hasil
}

func main() {
	var bilangan int
	var pengali int

	fmt.Print("Masukkan bilangan n: ")
	fmt.Scanln(&bilangan)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scanln(&pengali)

	hasil := hitungPerkalian(bilangan, pengali)

	fmt.Printf("Hasil %d dikali %d adalah %d\n", bilangan, pengali, hasil)
}