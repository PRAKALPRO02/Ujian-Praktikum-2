package main

import (
	"fmt"
)

const nMax = 51

type mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type arrayMahasiswa [nMax]mahasiswa

func main() {
	var N int
	fmt.Print("Masukkan jumlah data mahasiswa: ")
	fmt.Scanln(&N)

	var dataMahasiswa arrayMahasiswa
	fmt.Println("Masukkan data mahasiswa (NIM, Nama, Nilai):")
	for i := 0; i < N; i++ {
		fmt.Printf("Mahasiswa %d: ", i+1)
		var nim, nama string
		var nilai int
		fmt.Scanln(&nim, &nama, &nilai)
		dataMahasiswa[i] = mahasiswa{nim, nama, nilai}
	}

	var nimCari string
	fmt.Print("Masukkan NIM mahasiswa yang ingin dicari: ")
	fmt.Scanln(&nimCari)

	nilaiPertama, foundPertama := cariNilaiPertama(dataMahasiswa, nimCari)
	if foundPertama {
		fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah %d\n", nimCari, nilaiPertama)
	} else {
		fmt.Printf("Tidak ditemukan mahasiswa dengan NIM %s\n", nimCari)
	}

	nilaiTerbesar, foundTerbesar := cariNilaiTerbesar(dataMahasiswa, nimCari)
	if foundTerbesar {
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d\n", nimCari, nilaiTerbesar)
	} else {
		fmt.Printf("Tidak ditemukan mahasiswa dengan NIM %s\n", nimCari)
	}
}

func cariNilaiPertama(data arrayMahasiswa, nimCari string) (int, bool) {
	for i := 0; i < len(data); i++ {
		if data[i].NIM == nimCari {
			return data[i].Nilai, true
		}
	}
	return 0, false
}

func cariNilaiTerbesar(data arrayMahasiswa, nimCari string) (int, bool) {
	nilaiTerbesar := -1
	found := false

	for i := 0; i < len(data); i++ {
		if data[i].NIM == nimCari {
			if data[i].Nilai > nilaiTerbesar {
				nilaiTerbesar = data[i].Nilai
				found = true
			}
		}
	}
	return nilaiTerbesar, found
}

// Dwi Hesti Ariani 2311102094
