package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const nProv = 11

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func main() {
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv

	InputData(&prov, &pop, &tumbuh)

	tercepat := ProvinsiTercepat(tumbuh)

	fmt.Println("Provinsi dengan pertumbuhan tercepat:", prov[tercepat], ":", tumbuh[tercepat])

	var nama string
	fmt.Print("Masukkan nama provinsi: ")
	fmt.Scanln(&nama)
	indeks := IndeksProvinsi(prov, nama)

	if indeks != -1 {
		fmt.Println("Provinsi", prov[indeks], "dengan pertumbuhan", tumbuh[indeks])
	} else {
		fmt.Println("Provinsi", nama, "tidak ditemukan")
	}

	TampilkanData(prov, pop, tumbuh)
}

// Procedure InputData
func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {

	scanner := bufio.NewScanner(os.Stdin)
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data provinsi ke-%d (format: Nama, Populasi, Angka Pertumbuhan): ", i+1)
		scanner.Scan()
		data := strings.Split(scanner.Text(), " ")

		// Input data provinsi
		prov[i] = data[0]

		// Input data populasi
		pop[i], _ = strconv.Atoi(data[1])

		// Input data pertumbuhan
		tumbuh[i], _ = strconv.ParseFloat(data[2], 64)
	}
}

// Function ProvinsiTercepat
func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIndex] {
			maxIndex = i
		}
	}
	return maxIndex
}

// Procedure TampilkanData
func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Provinsi dengan pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2.0 {
			fmt.Printf("Nama Provinsi: %s, Populasi: %d, Pertumbuhan: %.2f%%\n", prov[i], pop[i], tumbuh[i])
		}
	}
}

// Function IndeksProvinsi
func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if prov[i] == nama {
			return i
		}
	}
	return -1
}

// Dwi Hesti Ariani_2311102094
