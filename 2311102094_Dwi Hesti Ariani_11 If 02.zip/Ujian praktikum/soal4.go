package main

import (
	"fmt"
	"sort"
)

type Player struct {
	Name   string
	Goals  int
	Assist int
}

func main() {
	// Input data pemain
	var n int
	fmt.Scanln(&n)
	players := make([]Player, n)
	for i := 0; i < n; i++ {
		fmt.Scanln(&players[i].Name, &players[i].Goals, &players[i].Assist)
	}

	// Sorting data pemain
	sort.Slice(players, func(i, j int) bool {
		// Urutkan berdasarkan jumlah gol
		if players[i].Goals > players[j].Goals {
			return true
		} else if players[i].Goals < players[j].Goals {
			return false
		} else {
			// Jika jumlah gol sama, urutkan berdasarkan jumlah assist
			return players[i].Assist > players[j].Assist
		}
	})

	// Output data pemain
	for _, player := range players {
		fmt.Println(player.Name, player.Goals, player.Assist)
	}
}

// Dwi Hesti Ariani 2311102094
