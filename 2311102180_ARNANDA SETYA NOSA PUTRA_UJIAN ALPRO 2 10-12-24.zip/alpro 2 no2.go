package main

import (
	"fmt"
)

const nMax = 51

type Mahasiswa struct {
	NIM2311102180 string
	Nama          string
	Nilai         int
}

type ArrayMahasiswa [nMax]Mahasiswa

func main() {
	var dataMahasiswa ArrayMahasiswa
	var N int

	fmt.Println("Pencarian Data Mahasiswa(NIM2311102180,nama,nilai)")
	fmt.Print("Masukkan jumlah mahasiswa (maks 50): ")
	fmt.Scan(&N)

	for i := 0; i < N; i++ {
		fmt.Printf("\nMasukkan data mahasiswa ke-%d:\n", i+1)
		fmt.Print("  NIM2311102180: ")
		fmt.Scan(&dataMahasiswa[i].NIM2311102180)
		fmt.Print("  Nama: ")
		fmt.Scan(&dataMahasiswa[i].Nama)
		fmt.Print("  Nilai: ")
		fmt.Scan(&dataMahasiswa[i].Nilai)
	}

	fmt.Println("\nPencarian Data")
	var cariNIM2311102180 string
	fmt.Print("Masukkan NIM2311102180 mahasiswa untuk mencari nilai pertama: ")
	fmt.Scan(&cariNIM2311102180)
	nilaiPertama := cariNilaiPertama(dataMahasiswa, N, cariNIM2311102180)
	if nilaiPertama != -1 {
		fmt.Printf("\nNilai pertama mahasiswa dengan NIM2311102180 '%s' adalah: %d\n", cariNIM2311102180, nilaiPertama)
	} else {
		fmt.Printf("\nmahasiswa dengan NIM2311102180 '%s' tidak ditemukan.\n", cariNIM2311102180)
	}

	fmt.Print("\nMasukkan NIM2311102180 mahasiswa untuk mencari nilai terbesar: ")
	fmt.Scan(&cariNIM2311102180)
	nilaiTerbesar := cariNilaiTerbesar(dataMahasiswa, N, cariNIM2311102180)
	if nilaiTerbesar != -1 {
		fmt.Printf("\nNilai terbesar mahasiswa dengan NIM2311102180 '%s' adalah: %d\n", cariNIM2311102180, nilaiTerbesar)
	} else {
		fmt.Printf("\nmahasiswa dengan NIM2311102180 '%s' tidak ditemukan.\n", cariNIM2311102180)
	}

	fmt.Println("\ndone kakak :)")
}

// nilai pertama
func cariNilaiPertama(data ArrayMahasiswa, N int, cariNIM2311102180 string) int {
	for i := 0; i < N; i++ {
		if data[i].NIM2311102180 == cariNIM2311102180 {
			return data[i].Nilai
		}
	}
	return -1
}

// nilai terbesar
func cariNilaiTerbesar(data ArrayMahasiswa, N int, cariNIM2311102180 string) int {
	nilaiMax := -1
	found := false
	for i := 0; i < N; i++ {
		if data[i].NIM2311102180 == cariNIM2311102180 {
			found = true
			if data[i].Nilai > nilaiMax {
				nilaiMax = data[i].Nilai
			}
		}
	}
	if !found {
		return -1
	}
	return nilaiMax
}
