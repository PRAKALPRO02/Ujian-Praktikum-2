package main

import (
	"fmt"
	"sort"
)

type Partai struct {
	Nama2311102180 int
	suara          int
}

func main() {
	const MAX = 1000000
	var suara [MAX + 1]int
	var input int

	fmt.Println("Perhitungan Suara Partai")
	fmt.Println("Masukkan nomor partai (1 - 1000000), akhiri dengan -1:")

	// data suara
	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		if input < 1 || input > MAX {
			fmt.Println("Nomor partai tidak valid. mohon masukkan nomor partai antara 1 dan 1000000.")
			continue
		}
		suara[input]++
	}

	// hasil suara
	var hasil []Partai
	for i := 1; i <= MAX; i++ {
		if suara[i] > 0 {
			hasil = append(hasil, Partai{Nama2311102180: i, suara: suara[i]})
		}
	}

	sort.Slice(hasil, func(i, j int) bool {
		if hasil[i].suara == hasil[j].suara {
			return hasil[i].Nama2311102180 < hasil[j].Nama2311102180
		}
		return hasil[i].suara > hasil[j].suara
	})

	// hasil akhir
	fmt.Println("\nHasil Perhitungan Suara:")
	if len(hasil) == 0 {
		fmt.Println("Tidak ada suara yang dihitung.")
	} else {
		for i, p := range hasil {
			fmt.Printf("%d. Partai %d: %d suara\n", i+1, p.Nama2311102180, p.suara)
		}
	}

	fmt.Println("\ndone kakakk :)")
}
