package main

import (
	"fmt"
)

type Pemain struct {
	Nama2311102180 string
	Gol            int
	Assist         int
}

func InputData(n int) []Pemain {
	pemain := make([]Pemain, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama2311102180, Gol, Assist):\n", i+1)
		var Nama2311102180Depan, Nama2311102180Belakang string
		fmt.Scan(&Nama2311102180Depan, &Nama2311102180Belakang)
		pemain[i].Nama2311102180 = Nama2311102180Depan + " " + Nama2311102180Belakang
		fmt.Scan(&pemain[i].Gol, &pemain[i].Assist)
	}
	return pemain
}

func SelectionSort(pemain []Pemain) {
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if pemain[j].Gol > pemain[maxIdx].Gol ||
				(pemain[j].Gol == pemain[maxIdx].Gol && pemain[j].Assist > pemain[maxIdx].Assist) {
				maxIdx = j
			}
		}
		pemain[i], pemain[maxIdx] = pemain[maxIdx], pemain[i]
	}
}

func TampilkanData(pemain []Pemain) {
	fmt.Println("Peringkat pemain berdasarkan jumlah gol dan assist:")
	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", p.Nama2311102180, p.Gol, p.Assist)
	}
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	pemain := InputData(n)

	SelectionSort(pemain)

	TampilkanData(pemain)
}
