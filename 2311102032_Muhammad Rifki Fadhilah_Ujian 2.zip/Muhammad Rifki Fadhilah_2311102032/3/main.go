package main
import "fmt"

const nProv = 5
type NamaProv[nProv] string
type PopProv [nProv] int
type TumbuhProv [nProv] float64

func InputData(prov *NamaProv, pop *PopProv, tum *TumbuhProv) {
  for i:=0; i<nProv; i++ {
    fmt.Println("Provinsi ke-", i+1)
    fmt.Print("Masukkan nama provinsi: ")
    fmt.Scan(&prov[i])
    fmt.Print("Masukkan jumlah penduduk: ")
    fmt.Scan(&pop[i])
    fmt.Print("Masukkan tingkat pertumbuhan penduduk: ")
    fmt.Scan(&tum[i])
    fmt.Println()
  }
}

func ProvinsiTercepat(tumbuh TumbuhProv) int{
  var idx int = 0
  var i int
  for i=1; i<nProv; i++ {
    if tumbuh[i] > tumbuh[idx] {
      idx = i
    }
  }
  return idx
}

func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
  var result float64
  for i := 0; i < nProv; i++ {
    if tumbuh[i] > 0.02 {
      result = (tumbuh[i] + 1) * float64(pop[i])
      fmt.Println(prov[i], result)
    }
  }
}

func IndeksProvinsi(prov NamaProv, nama string) int {
  var nemu int = -1
  var i int = 0
  for i < nProv && nemu == -1 {
    if prov[i] == nama {
      nemu = i
    }
    i++
  }
  return nemu
}

func main() {
  var prov NamaProv
  var pop PopProv
  var tumbuh TumbuhProv
  var cari string
  var idxTercepat, idxProvinsi int

  InputData(&prov, &pop, &tumbuh)
  fmt.Print("Masukkan nama provinsi: ")
  fmt.Scan(&cari)

  idxTercepat = ProvinsiTercepat(tumbuh)
  fmt.Println("Provinsi dengan pertumbuhan penduduk tertinggi adalah", prov[idxTercepat])

  idxProvinsi = IndeksProvinsi(prov, cari)
  fmt.Println("Indeks provinsi", cari, "adalah", idxProvinsi)

  fmt.Println("Data pertumbuhan penduduk provinsi")
  TampilkanData(prov, pop, tumbuh)
}