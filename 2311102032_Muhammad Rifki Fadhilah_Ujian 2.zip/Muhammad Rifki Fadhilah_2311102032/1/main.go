package main

import "fmt"

type set [2022]int

func exist(T set, n int, vall int) bool {
/* mengevaluasi true apabila bilangan n ada di dalam array T yang berisi sejumlah n bilangan bulat */
    var status bool = false
    var i int
    for i < n && !status {
        if T[i] == vall {
            status = T[i] == vall
        }
        i++
    }
    return status
}

func inputSet(T *set, n *int) {
/* I.S. data himpunan telah siap pada piranti masukan
   F.S. array T berisi sejumlah n bilangan bulat yang berasal dari masukan (masukan berakhir apabila bilangan ada yang duplikat, atau array penuh)
   Catatan: Panggil function exist di sini untuk membantu pengecekan */
    *n = 0
    var bilangan int
    fmt.Scan(&bilangan)
    for *n < 2022 && !exist(*T, *n, bilangan) {
        T[*n] = bilangan
        *n++
        fmt.Scan(&bilangan)
    }
}

func findIntersection(T1, T2 set, n, m int, T3 *set, h *int) {
/* I.S. terdefinisi himpunan T1 dan T2 yang berisi sejumlah n dan m anggota himpunan
F.S. himpunan T3 berisi sejumlah h bilangan bulat yang merupakan irisan dari himpunan T1 dan T2
Catatan: Panggil function exist di sini untuk membantu pengecekan */
    var j int
    *h = 0
    for j < n {
        if exist(T2, m, T1[j]) {
            T3[*h] = T1[j]
            *h++
        }
        j++
    }
}

func printSet(T set, n int) {
/* I.S. terdefinisi sebuah himpunan T yang berisi sejumlah n bilangan bulat
F.S. menampilkan isi array T secara horizontal (dipisahkan oleh spasi) */

    var i int = 0
    for i < n-1 {
        fmt.Print(T[i], " ")
        i++
    }
    if n > 0 {
        fmt.Print(T[n-1])
    }
}

func main() {
    var S1, S2, S3 set
    var n1, n2, n3 int
    inputSet(&S1, &n1)
    inputSet(&S2, &n2)
    findIntersection(S1, S2, n1, n2, &S3, &n3)
    printSet(S3, n3)
}
