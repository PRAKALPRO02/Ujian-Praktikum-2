// Fajar Farizqi Azmi 
// 2311102192

package main

import (
	"fmt"
	"sort"
	"strings"
)

type Player struct {
	Name    string
	Goals   int
	Assists int
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	players := make([]Player, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama JumlahGol JumlahAssist): ", i+1)
		var name string
		var goals, assists int
		fmt.Scan(&name, &goals, &assists)

		if strings.Contains(name, "_") {
			name = strings.Replace(name, "_", " ", -1)
		}
		players[i] = Player{Name: name, Goals: goals, Assists: assists}
	}

	sort.Slice(players, func(i, j int) bool {
		if players[i].Goals == players[j].Goals {
			return players[i].Assists > players[j].Assists
		}
		return players[i].Goals > players[j].Goals
	})

	fmt.Println("\nPemain dengan urutan peringkat:")
	for i, player := range players {
		fmt.Printf("%d. %s %d %d\n", i+1, player.Name, player.Goals, player.Assists)
	}
}