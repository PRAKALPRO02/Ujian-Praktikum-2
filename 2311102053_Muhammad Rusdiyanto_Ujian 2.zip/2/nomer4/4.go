// MUHAMMAD RUSDIYANTO | 2311102053 | S1IF-11-02
package main

import "fmt"

type Pemain struct {
	nama_depan    string
	nama_belakang string
	gol           int
	assist        int
}

func main() {
	var n int

	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	arrPemain := make([]Pemain, n)
	fmt.Println("Masukkan pemain: ")
	for i := 0; i < n; i++ {
		fmt.Scan(&arrPemain[i].nama_depan)
		fmt.Scan(&arrPemain[i].nama_belakang)
		fmt.Scan(&arrPemain[i].gol)
		fmt.Scan(&arrPemain[i].assist)
	}

	for i := 0; i < n; i++ {
		idMax := i
		for j := i + 1; j < n; j++ {
			if arrPemain[idMax].gol < arrPemain[j].gol || arrPemain[idMax].gol <= arrPemain[j].gol && arrPemain[idMax].assist < arrPemain[j].assist {
				idMax = j
			}
		}

		temp := arrPemain[i]
		arrPemain[i] = arrPemain[idMax]
		arrPemain[idMax] = temp
	}

	fmt.Println()
	for i := 0; i < n; i++ {
		fmt.Printf("%v %v %v %v\n", arrPemain[i].nama_depan, arrPemain[i].nama_belakang, arrPemain[i].gol, arrPemain[i].assist)
	}
}
