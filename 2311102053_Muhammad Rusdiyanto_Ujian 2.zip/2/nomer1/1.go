// MUHAMMAD RUSDIYANTO | 2311102053 | S1IF-11-02
package main

import "fmt"

type set [2022]int

func exist(T set, n int, vall int) bool {
	/* mengevaluasi true apabila bilangan n ada di dalam array T yang berisi sejumlah n bilangan bulat */
	for i := 0; i < n; i++ {
		if T[i] == vall {
			return true
		}
	}
	return false
}

func inputSet(T *set, n *int) {
	/* I.S. data himpunan telah siap pada piranti masukan
	   F.S. array T berisi sejumlah n bilangan bulat yang berasal dari masukan (masukan berakhir apabila bilangan ada yang duplikat, atau array penuh)
	   Catatan: Panggil function exist di sini untuk membantu pengecekan */
	fmt.Println("Masukkan elemen dalam set: ")
	for i := 0; i < 2022; i++ {
		var temp int
		fmt.Scan(&temp)
		if exist(*T, *n, temp) {
			break
		} else {
			T[i] = temp
			*n++
		}
	}
}

func findIntersection(T1, T2 set, n, m int, T3 *set, h *int) {
	/* I.S. terdefinisi himpunan T1 dan T2 yang berisi sejumlah n dan m anggota himpunan
	   F.S. himpunan T3 berisi sejumlah h bilangan bulat yang merupakan irisan dari himpunan T1 dan T2
	   Catatan: Panggil function exist di sini untuk membantu pengecekan */
	*h = 0
	for i := 0; i < n; i++ {
		if exist(T2, m, T1[i]) {
			T3[*h] = T1[i]
			*h++
		}
	}
}

func printSet(T set, n int) {
	/* I.S. terdefinisi sebuah himpunan T yang berisi sejumlah n bilangan bulat
	   F.S. menampilkan isi array T secara horizontal (dipisahkan oleh spasi) */
	for i := 0; i < n; i++ {
		fmt.Printf("%v ", T[i])
	}
}

func main() {
	var S1, S2, S3 set
	var n1, n2, n3 int
	inputSet(&S1, &n1)
	inputSet(&S2, &n2)
	findIntersection(S1, S2, n1, n2, &S3, &n3)
	printSet(S3, n3)
}
