// MUHAMMAD RUSDIYANTO | 2311102053 | S1IF-11-02
package main

import "fmt"

const nMax int = 51

type mahasiswa struct {
	NIM   int
	nama  string
	nilai int
}
type arrayMahasiswa [nMax]mahasiswa

func inputData(arr *arrayMahasiswa, n *int) {
	fmt.Print("Masukkan jumlah data mahasiswa: ")
	fmt.Scan(n)
	for i := 0; i < *n; i++ {
		fmt.Printf("Masukkan data ke-%v\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&arr[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&arr[i].nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&arr[i].nilai)
	}
}

func findMax(arr arrayMahasiswa, n, nim int) int {
	nilai := -1
	for i := 0; i < n; i++ {
		if arr[i].NIM == nim && arr[i].nilai > nilai {
			nilai = arr[i].nilai
		}
	}
	return nilai
}

func findFirst(arr arrayMahasiswa, n, nim int) int {
	for i := 0; i < n; i++ {
		if arr[i].NIM == nim {
			return arr[i].nilai
		}
	}
	return -1
}

func main() {
	var arrMhs arrayMahasiswa
	var n, nim, first, max int
	inputData(&arrMhs, &n)
	fmt.Print("Masukkan NIM mahasiswa: ")
	fmt.Scan(&nim)
	first = findFirst(arrMhs, n, nim)
	max = findMax(arrMhs, n, nim)
	fmt.Printf("Nilai pertama: %v\n", first)
	fmt.Printf("Nilai terbesar: %v", max)
}
