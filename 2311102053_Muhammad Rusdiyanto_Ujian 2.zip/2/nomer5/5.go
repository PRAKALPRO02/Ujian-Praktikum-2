// MUHAMMAD RUSDIYANTO | 2311102053 | S1IF-11-02
package main

import "fmt"

const NMAX = 1000000

type partai struct {
	nama, suara int
}

type arrPartai [NMAX]partai

func main() {

	var arr arrPartai
	var n, x, idx int

	n = 0
	fmt.Scan(&x)
	for x != -1 {
		idx = posisi(arr, n, x)
		if idx == -1 {
			arr[n].nama = x
			arr[n].suara = 1
			n++
		} else {
			arr[idx].suara++
		}
		fmt.Scan(&x)
	}

	var pass, k int
	var temp partai
	for pass = 1; pass <= n-1; pass++ {
		k = pass
		temp = arr[k]
		for k > 0 && temp.suara > arr[k-1].suara {
			arr[k] = arr[k-1]
			k--
		}
		arr[k] = temp
	}
	for k = 0; k < n; k++ {
		fmt.Printf("%v(%v) ", arr[k].nama, arr[k].suara)
	}
}

func posisi(arr arrPartai, n int, nama int) int {
	indeks := -1
	for i := 0; i < n && indeks == -1; i++ {
		if arr[i].nama == nama {
			indeks = i
		}
	}
	return indeks
}
