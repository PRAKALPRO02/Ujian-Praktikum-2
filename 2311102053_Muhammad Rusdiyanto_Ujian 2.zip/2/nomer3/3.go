// MUHAMMAD RUSDIYANTO | 2311102053 | S1IF-11-02
package main

import "fmt"

const nProv int = 10

type namaProv [nProv]string
type popProv [nProv]int
type tumbuhProv [nProv]float64

func inputData(prov *namaProv, pop *popProv, tumbuh *tumbuhProv) {
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi %v\n", i+1)
		fmt.Print("Masukkan nama provinsi: ")
		fmt.Scan(&prov[i])
		fmt.Print("Masukkan populasi: ")
		fmt.Scan(&pop[i])
		fmt.Print("Masukkan angka pertumbuhan: ")
		fmt.Scan(&tumbuh[i])
	}
}

func provinsiTercepat(tumbuh tumbuhProv) int {
	index := 0
	max := 0.0
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > max {
			max = tumbuh[i]
			index = i
		}
	}
	return index
}

func tampilkanData(prov namaProv, pop popProv, tumbuh tumbuhProv) {
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			fmt.Printf("%v: (Penduduk tahun ini: %v; Penduduk tahun depan: %.0f)\n", prov[i], pop[i], float64(pop[i])*(1.0+tumbuh[i]))
		}
	}
}

func indeksProvinsi(prov namaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if prov[i] == nama {
			return i
		}
	}
	return -1
}

func main() {
	var prov namaProv
	var pop popProv
	var tumbuh tumbuhProv
	var nama string

	inputData(&prov, &pop, &tumbuh)
	fmt.Print("Masukkan nama provinsi: ")
	fmt.Scan(&nama)

	fmt.Println("Daftar provinsi dengan pertumbuhan di atas 2%")
	fmt.Printf("Provinsi dengan angka pertumbuhan tercepat: %v\n", prov[provinsiTercepat(tumbuh)])
	fmt.Printf("Provinsi %v ada di indeks ke-%v\n", nama, indeksProvinsi(prov, nama))
	tampilkanData(prov, pop, tumbuh)
}
