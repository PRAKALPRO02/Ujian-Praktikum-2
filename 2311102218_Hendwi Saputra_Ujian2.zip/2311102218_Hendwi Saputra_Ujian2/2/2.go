// Hendwi Saputra
// 2311102218

package main

import "fmt"

const nMax = 51

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type ArrayMahasiswa218 [nMax]Mahasiswa

func main() {
	var N int
	var data ArrayMahasiswa218

	fmt.Print("Masukkan jumlah data mahasiswa: ")
	fmt.Scan(&N)

	for i := 0; i < N; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d (NIM, Nama, Nilai): ", i+1)
		fmt.Scan(&data[i].NIM, &data[i].Nama, &data[i].Nilai)
	}

	var nim string
	fmt.Print("Masukkan NIM untuk pencarian: ")
	fmt.Scan(&nim)

	nilaiPertama := cariNilaiPertama(data, N, nim)
	nilaiTerbesar := cariNilaiTerbesar(data, N, nim)

	fmt.Printf("Nilai pertama mahasiswa dengan NIM %s: %d\n", nim, nilaiPertama)
	fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s: %d\n", nim, nilaiTerbesar)
}

func cariNilaiPertama(data ArrayMahasiswa218, N int, nim string) int {
	for i := 0; i < N; i++ {
		if data[i].NIM == nim {
			return data[i].Nilai
		}
	}
	return -1
}

func cariNilaiTerbesar(data ArrayMahasiswa218, N int, nim string) int {
	maxNilai := -1
	for i := 0; i < N; i++ {
		if data[i].NIM == nim && data[i].Nilai > maxNilai {
			maxNilai = data[i].Nilai
		}
	}
	return maxNilai
}
