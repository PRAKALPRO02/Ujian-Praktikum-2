// Hendwi Saputra
// 2311102218

package main

import "fmt"

const MAX = 1000000

type Partai struct {
	nama218 int
	suara   int
}

type ArrayPartai [MAX]Partai

func main() {
	var p ArrayPartai
	var n int

	fmt.Println("Masukkan suara (akhiri dengan -1):")
	for {
		var suara int
		fmt.Scan(&suara)
		if suara == -1 {
			break
		}

		idx := posisi(p[:n], suara)
		if idx == -1 {
			p[n] = Partai{nama218: suara, suara: 1}
			n++
		} else {
			p[idx].suara++
		}
	}

	for i := 1; i < n; i++ {
		key := p[i]
		j := i - 1
		for j >= 0 && p[j].suara < key.suara {
			p[j+1] = p[j]
			j = j - 1
		}
		p[j+1] = key
	}

	fmt.Println("Hasil perolehan suara:")
	for i := 0; i < n; i++ {
		fmt.Printf("%d(%d) ", p[i].nama218, p[i].suara)
	}
	fmt.Println()
}

func posisi(tabelPartai []Partai, nama218 int) int {
	for i, partai := range tabelPartai {
		if partai.nama218 == nama218 {
			return i
		}
	}
	return -1
}
