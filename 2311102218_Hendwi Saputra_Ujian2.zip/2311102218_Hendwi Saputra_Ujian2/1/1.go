// Hendwi Saputra
// 2311102218

package main

import "fmt"

type set [2022]int

func exist(T set, n int, val218 int) bool {
	for i := 0; i < n; i++ {
		if T[i] == val218 {
			return true
		}
	}
	return false
}

func inputSet(T *set, n *int) {
	var val218 int
	*n = 0
	for {
		fmt.Scan(&val218)
		if val218 == -1 || exist(*T, *n, val218) {
			break
		}
		T[*n] = val218
		*n++
	}
}

func findIntersection(T1, T2 set, n1, n2 int, T3 *set, n3 *int) {
	*n3 = 0
	for i := 0; i < n1; i++ {
		if exist(T2, n2, T1[i]) {
			T3[*n3] = T1[i]
			*n3++
		}
	}
}

func printSet(T set, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("%d ", T[i])
	}
	fmt.Println()
}

func main() {
	var S1, S2, S3 set
	var n1, n2, n3 int

	fmt.Println("Masukkan set pertama:")
	inputSet(&S1, &n1)

	fmt.Println("Masukkan set kedua:")
	inputSet(&S2, &n2)

	findIntersection(S1, S2, n1, n2, &S3, &n3)

	fmt.Println("Irisan kedua set:")
	printSet(S3, n3)
}
