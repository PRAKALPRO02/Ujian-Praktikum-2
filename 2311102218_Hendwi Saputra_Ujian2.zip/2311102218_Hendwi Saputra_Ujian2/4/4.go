// Hendwi Saputra
// 2311102218

package main

import "fmt"

type Pemain struct {
	Nama   string
	Gol    int
	Assist int
}

func selectionSort_218(pemain []Pemain) {
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if pemain[j].Gol > pemain[maxIdx].Gol ||
				(pemain[j].Gol == pemain[maxIdx].Gol && pemain[j].Assist > pemain[maxIdx].Assist) {
				maxIdx = j
			}
		}
		pemain[i], pemain[maxIdx] = pemain[maxIdx], pemain[i]
	}
}

func main() {
	var N int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&N)

	if N <= 0 || N > 1000 {
		fmt.Println("Jumlah pemain tidak valid. Harus antara 1 dan 1000.")
		return
	}

	pemain := make([]Pemain, N)
	for i := 0; i < N; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama Gol Assist): ", i+1)
		fmt.Scan(&pemain[i].Nama, &pemain[i].Gol, &pemain[i].Assist)
	}

	selectionSort_218(pemain)

	fmt.Println("\nPemain yang telah diurutkan berdasarkan gol dan assist:")
	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", p.Nama, p.Gol, p.Assist)
	}
}
