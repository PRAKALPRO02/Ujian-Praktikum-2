package main

import (
	"fmt"
)

type Pemain struct {
	nama   string
	gol    int
	assist int
}

func selectionSort(pemain []Pemain) {
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIndex := i
		for j := i + 1; j < n; j++ {
			if pemain[j].gol > pemain[maxIndex].gol || (pemain[j].gol == pemain[maxIndex].gol && pemain[j].assist > pemain[maxIndex].assist) {
				maxIndex = j
			}
		}
		pemain[i], pemain[maxIndex] = pemain[maxIndex], pemain[i]
	}
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	var pemain []Pemain

	for i := 0; i < n; i++ {
		var nama string
		var gol, assist int
		fmt.Printf("Masukkan data pemain ke-%d:\n", i+1)

		fmt.Print("Nama pemain: ")
		fmt.Scanln(&nama)

		fmt.Print("Jumlah gol: ")
		fmt.Scan(&gol)

		fmt.Print("Jumlah assist: ")
		fmt.Scan(&assist)

		pemain = append(pemain, Pemain{nama: nama, gol: gol, assist: assist})
	}

	selectionSort(pemain)

	fmt.Println("\nPeringkat Pencetak Gol Terbanyak:")
	for i := 0; i < n; i++ {
		fmt.Printf("%d. %s: %d gol, %d assist\n", i+1, pemain[i].nama, pemain[i].gol, pemain[i].assist)
	}
}
