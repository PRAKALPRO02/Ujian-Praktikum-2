package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

// Yayang Alya Bilqis
// 2311102229

const nProv = 10

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func main() {
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv
	var namaCari string

	InputData(&prov, &pop, &tumbuh)

	idxTercepat := ProvinsiTercepat(tumbuh)
	fmt.Printf("1. Provinsi dengan angka pertumbuhan tercepat: %s\n", prov[idxTercepat])

	fmt.Println("\nMasukkan nama provinsi yang akan dicari:")
	scanner := bufio.NewScanner(os.Stdin)
	if scanner.Scan() {
		namaCari = scanner.Text()
	}

	idxCari := IndeksProvinsi(prov, namaCari)
	fmt.Printf("2. Indeks dari provinsi yang dicari: %d\n", idxCari)

	fmt.Println("\n3. Provinsi dengan angka pertumbuhan di atas 2% dan prediksi populasi tahun depan:")
	TampilkanData(prov, pop, tumbuh)
}

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	reader := bufio.NewReader(os.Stdin)
	fmt.Println("Masukkan data untuk 10 provinsi:")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan nama provinsi ke-%d: ", i+1)
		nama, _ := reader.ReadString('\n')
		prov[i] = strings.TrimSpace(nama)

		fmt.Printf("Masukkan populasi provinsi %s: ", prov[i])
		popInput, _ := reader.ReadString('\n')
		pop[i], _ = strconv.Atoi(strings.TrimSpace(popInput))

		fmt.Printf("Masukkan angka pertumbuhan penduduk provinsi %s (dalam persen): ", prov[i])
		tumbuhInput, _ := reader.ReadString('\n')
		tumbuh[i], _ = strconv.ParseFloat(strings.TrimSpace(tumbuhInput), 64)
	}
}

func ProvinsiTercepat(tumbuh TumbuhProv) int {
	idxMax := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[idxMax] {
			idxMax = i
		}
	}
	return idxMax
}

func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2 {
			prediksi := float64(pop[i]) * (1 + tumbuh[i]/100)
			fmt.Printf("- %s: Populasi saat ini %d, Prediksi populasi %.0f\n",
				prov[i], pop[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) {
			return i
		}
	}
	return -1
}
