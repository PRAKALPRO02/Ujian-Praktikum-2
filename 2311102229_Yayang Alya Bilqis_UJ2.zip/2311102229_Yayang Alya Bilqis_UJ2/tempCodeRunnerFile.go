package main

import (
	"fmt"
)

// Yayang Alya Bilqis
// 2311102229 - IF 02

type Player struct {
	name    string
	goals   int
	assists int
}

func main() {
	var n int
	fmt.Scan(&n)

	players := make([]Player, n)

	for i := 0; i < n; i++ {
		var firstName, lastName string
		var goals, assists int
		fmt.Scan(&firstName, &lastName, &goals, &assists)
		players[i] = Player{
			name:    firstName + " " + lastName,
			goals:   goals,
			assists: assists,
		}
	}

	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if players[j].goals > players[maxIdx].goals ||
				(players[j].goals == players[maxIdx].goals && players[j].assists > players[maxIdx].assists) {
				maxIdx = j
			}
		}
		players[i], players[maxIdx] = players[maxIdx], players[i]
	}

	for _, player := range players {
		fmt.Printf("%s %d %d\n", player.name, player.goals, player.assists)
	}
}
