package main

import (
	"fmt"
)

// Fungsi untuk membaca masukan dan menghasilkan slice unik
func inputSet() []int {
	var set []int
	var val int
	seen := make(map[int]bool)
	fmt.Println("Masukkan bilangan :")
	for {
		fmt.Scan(&val)
		if seen[val] {
			break
		}
		seen[val] = true
		set = append(set, val)
	}
	return set
}

// Fungsi untuk mencari irisan dua himpunan
func findIntersection(set1, set2 []int) []int {
	var intersection []int
	seen := make(map[int]bool)

	// Tandai semua elemen di himpunan pertama
	for _, val := range set1 {
		seen[val] = true
	}

	// Periksa elemen yang sama di himpunan kedua
	for _, val := range set2 {
		if seen[val] {
			intersection = append(intersection, val)
		}
	}

	return intersection
}

// Fungsi untuk mencetak hasil
func printSet(set []int) {
	if len(set) == 0 {
		fmt.Println("tidak ada")
		return
	}
	for i, val := range set {
		if i > 0 {
			fmt.Print(" ")
		}
		fmt.Print(val)
	}
	fmt.Println()
}

func main() {
	fmt.Println("Masukkan himpunan : ")
	set1 := inputSet()

	intersection := findIntersection(set1)

	fmt.Print("Irisan himpunan: ")
	printSet(intersection)
}
