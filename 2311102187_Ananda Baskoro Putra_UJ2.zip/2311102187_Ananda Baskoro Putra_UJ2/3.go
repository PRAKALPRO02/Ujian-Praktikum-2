// Ananda Baskoro Putra
//2311102187

package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const nProv = 10

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	reader := bufio.NewReader(os.Stdin)
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data provinsi ke-%d (Nama, Populasi, Pertumbuhan):\n", i+1)
		
		provName, _ := reader.ReadString('\n')
		(*prov)[i] = strings.TrimSpace(provName)

		var popInput string
		fmt.Print("Populasi: ")
		fmt.Scanln(&popInput)
		popValue, err := strconv.Atoi(popInput)
		if err != nil {
			fmt.Println("Populasi harus berupa angka! Ulangi input.")
			i--
			continue
		}
		(*pop)[i] = popValue

		var growthInput string
		fmt.Print("Pertumbuhan (%): ")
		fmt.Scanln(&growthInput)
		growthValue, err := strconv.ParseFloat(growthInput, 64)
		if err != nil {
			fmt.Println("Pertumbuhan harus berupa angka desimal! Ulangi input.")
			i--
			continue
		}
		(*tumbuh)[i] = growthValue
	}
}

func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIndex] {
			maxIndex = i
		}
	}
	return maxIndex
}

func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Prediksi jumlah penduduk untuk provinsi dengan pertumbuhan > 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2 {
			prediksi := float64(pop[i]) * (1 + tumbuh[i]/100)
			fmt.Printf("%s: Populasi Saat Ini: %d, Prediksi: %.0f\n", prov[i], pop[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.ToLower(prov[i]) == strings.ToLower(nama) {
			return i
		}
	}
	return -1
}

func main() {
	var provinsi NamaProv
	var populasi PopProv
	var pertumbuhan TumbuhProv
	var targetProvinsi string

	InputData(&provinsi, &populasi, &pertumbuhan)

	fmt.Println("Masukkan nama provinsi yang ingin dicari:")
	reader := bufio.NewReader(os.Stdin)
	targetProvinsi, _ = reader.ReadString('\n')
	targetProvinsi = strings.TrimSpace(targetProvinsi)

	tercepat := ProvinsiTercepat(pertumbuhan)
	fmt.Printf("Provinsi dengan angka pertumbuhan penduduk tercepat: %s\n", provinsi[tercepat])

	index := IndeksProvinsi(provinsi, targetProvinsi)
	if index == -1 {
		fmt.Printf("Provinsi %s tidak ditemukan.\n", targetProvinsi)
	} else {
		fmt.Printf("Indeks provinsi %s adalah: %d\n", targetProvinsi, index)
	}

	TampilkanData(provinsi, populasi, pertumbuhan)
}
