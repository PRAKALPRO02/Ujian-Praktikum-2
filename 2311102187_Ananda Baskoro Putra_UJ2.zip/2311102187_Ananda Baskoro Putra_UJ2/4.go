//Ananda Baskoro Putra
//2311102187

package main

import (
	"fmt"
)

const MAX_PLAYERS = 1001

type Player struct {
	nama   string
	gol    int
	assist int
}

type Players [MAX_PLAYERS]Player

func printPlayers(players Players, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("%s %d %d\n", players[i].nama, players[i].gol, players[i].assist)
	}
}

func selectionSort(players *Players, n int) {
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if players[j].gol > players[maxIdx].gol || 
				(players[j].gol == players[maxIdx].gol && players[j].assist > players[maxIdx].assist) {
				maxIdx = j
			}
		}
		players[i], players[maxIdx] = players[maxIdx], players[i]
	}
}

func main() {
	var players Players
	var n int

	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	if n < 1 || n > MAX_PLAYERS {
		fmt.Println("Jumlah pemain tidak valid.")
		return
	}

	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama Gol Assist): ", i+1)
		var firstName, lastName string
		fmt.Scan(&firstName, &lastName, &players[i].gol, &players[i].assist)
		players[i].nama = firstName + " " + lastName
	}

	selectionSort(&players, n)

	fmt.Println("\nPeringkat pemain berdasarkan gol dan assist:")
	printPlayers(players, n)
}
