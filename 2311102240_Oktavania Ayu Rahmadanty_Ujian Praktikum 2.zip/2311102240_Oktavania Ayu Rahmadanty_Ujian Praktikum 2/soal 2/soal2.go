package main

import "fmt"

//oktavania ayu rahmadanty
//2311102240

const nMax = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

type arrayMahasiswa [nMax]mahasiswa

func inputData(arr *arrayMahasiswa, n *int) {
	var jumlah int
	fmt.Print("Masukkan jumlah mahasiswa: ")
	fmt.Scan(&jumlah)

	for i := 0; i < jumlah; i++ {
		var nim, nama string
		var nilai int

		fmt.Printf("Masukkan data mahasiswa ke-%d:\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&nim)
		fmt.Print("Nama: ")
		fmt.Scan(&nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&nilai)

		arr[*n] = mahasiswa{NIM: nim, nama: nama, nilai: nilai}
		*n++
	}
}

func cariNilaiPertama(arr arrayMahasiswa, n int, nim string) int {
	for i := 0; i < n; i++ {
		if arr[i].NIM == nim {
			return arr[i].nilai
		}
	}
	return -1
}

func cariNilaiTerakhir(arr arrayMahasiswa, n int, nim string) int {
	var nilaiTerakhir = -1
	for i := 0; i < n; i++ {
		if arr[i].NIM == nim {
			nilaiTerakhir = arr[i].nilai
		}
	}
	return nilaiTerakhir
}

func printHasil(nilaiPertama, nilaiTerakhir int) {
	fmt.Printf("Nilai pertama: %d\n", nilaiPertama)
	fmt.Printf("Nilai terakhir: %d\n", nilaiTerakhir)
}

func main() {
	var arr arrayMahasiswa
	var n int

	inputData(&arr, &n)

	var nim string
	fmt.Print("Masukkan NIM mahasiswa yang ingin dicari: ")
	fmt.Scan(&nim)

	nilaiPertama := cariNilaiPertama(arr, n, nim)
	nilaiTerakhir := cariNilaiTerakhir(arr, n, nim)

	printHasil(nilaiPertama, nilaiTerakhir)
}
