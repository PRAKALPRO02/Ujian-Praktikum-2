package main

//oktavania ayu rahmadanty
//2311102240
import (
	"fmt"
)

const NMAX = 1000000

type partai struct {
	nama  int
	suara int
}

type tabPartai []partai

func main() {
	var p tabPartai
	var input int

	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}

		pos := posisi(p, len(p), input)
		if pos != -1 {
			p[pos].suara++
		} else {
			p = append(p, partai{nama: input, suara: 1})
		}
	}

	insertionSort(&p)

	for _, partai := range p {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}

func posisi(t tabPartai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if t[i].nama == nama {
			return i
		}
	}
	return -1
}

func insertionSort(t *tabPartai) {
	n := len(*t)
	for i := 1; i < n; i++ {
		key := (*t)[i]
		j := i - 1
		for j >= 0 && (*t)[j].suara < key.suara {
			(*t)[j+1] = (*t)[j]
			j--
		}
		(*t)[j+1] = key
	}
}
