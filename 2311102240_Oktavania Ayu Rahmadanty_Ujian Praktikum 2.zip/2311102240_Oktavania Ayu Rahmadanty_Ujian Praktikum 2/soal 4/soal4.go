package main

//oktavania ayu rahmadanty
//2311102240

import (
	"fmt"
	"strings"
)

type Pemain struct {
	nama   string
	gol    int
	assist int
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	if n > 1001 {
		fmt.Println("Jumlah pemain tidak boleh lebih dari 1001.")
		return
	}

	pemain := make([]Pemain, n)
	fmt.Println("Masukkan data pemain:")
	for i := 0; i < n; i++ {
		var namaDepan, namaBelakang string
		var gol, assist int
		fmt.Scan(&namaDepan, &namaBelakang, &gol, &assist)
		pemain[i] = Pemain{nama: namaDepan + " " + namaBelakang, gol: gol, assist: assist}
	}

	for i := 0; i < n-1; i++ {
		idxMaks := i
		for j := i + 1; j < n; j++ {
			if pemain[j].gol > pemain[idxMaks].gol ||
				(pemain[j].gol == pemain[idxMaks].gol && pemain[j].assist > pemain[idxMaks].assist) {
				idxMaks = j
			}
		}

		pemain[i], pemain[idxMaks] = pemain[idxMaks], pemain[i]
	}

	fmt.Println("\nData pemain setelah diurutkan:")
	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", strings.ReplaceAll(p.nama, " ", ""), p.gol, p.assist)
	}
}
