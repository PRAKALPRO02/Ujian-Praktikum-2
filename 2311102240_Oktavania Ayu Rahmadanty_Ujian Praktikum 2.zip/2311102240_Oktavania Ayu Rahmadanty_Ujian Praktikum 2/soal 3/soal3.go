package main

//oktavania ayu rahmadanty
//2311102240

import (
	"fmt"
)

const nProv = 10

func main() {
	var provinsi [nProv]string
	var populasi [nProv]int
	var pertumbuhan [nProv]float64
	var namaDicari string

	fmt.Println("Masukkan data untuk", nProv, "provinsi:")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi ke-%d:\n", i+1)
		fmt.Print("Nama: ")
		fmt.Scanln(&provinsi[i])
		fmt.Print("Populasi: ")
		fmt.Scanln(&populasi[i])
		fmt.Print("Pertumbuhan (%): ")
		fmt.Scanln(&pertumbuhan[i])
	}

	fmt.Print("Masukkan nama provinsi yang ingin dicari: ")
	fmt.Scanln(&namaDicari)

	idxTercepat := 0
	for i := 1; i < nProv; i++ {
		if pertumbuhan[i] > pertumbuhan[idxTercepat] {
			idxTercepat = i
		}
	}

	idxDicari := -1
	for i := 0; i < nProv; i++ {
		if provinsi[i] == namaDicari {
			idxDicari = i
			break
		}
	}

	fmt.Println("\nHasil:")
	fmt.Println("1. Provinsi dengan pertumbuhan tercepat:", provinsi[idxTercepat])

	if idxDicari != -1 {
		fmt.Println("2. Indeks provinsi", namaDicari, "adalah:", idxDicari)
	} else {
		fmt.Println("2. Provinsi", namaDicari, "tidak ditemukan.")
	}

	fmt.Println("3. Data provinsi dengan angka pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if pertumbuhan[i] > 2 {
			prediksi := populasi[i] + int(float64(populasi[i])*pertumbuhan[i]/100)
			fmt.Printf("- %s: Populasi sekarang = %d, Prediksi tahun depan = %d\n", provinsi[i], populasi[i], prediksi)
		}
	}
}
