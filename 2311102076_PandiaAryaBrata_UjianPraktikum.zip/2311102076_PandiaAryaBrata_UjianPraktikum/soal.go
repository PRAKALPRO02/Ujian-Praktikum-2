package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func main() {
	// Membaca input dari user
	fmt.Println("Masukkan angka untuk baris pertama (pisahkan dengan spasi):")
	set1 := readUniqueInput()
	fmt.Println("Masukkan angka untuk baris kedua (pisahkan dengan spasi):")
	set2 := readUniqueInput()

	// Mencari irisan
	intersection := findIntersection(set1, set2)

	// Menampilkan hasil
	fmt.Println("Irisan dari dua himpunan:", intersection)
}

// Fungsi untuk membaca input dan memastikan tidak ada duplikasi dalam satu baris
func readUniqueInput() map[int]struct{} {
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
	line := scanner.Text()

	// Membagi input berdasarkan spasi
	numbers := strings.Split(line, " ")
	uniqueNumbers := make(map[int]struct{})

	for _, numStr := range numbers {
		num, err := strconv.Atoi(numStr)
		if err != nil {
			fmt.Println("Input tidak valid. Harap masukkan angka.")
			os.Exit(1)
		}

		// Hentikan jika angka sudah ada dalam map
		if _, exists := uniqueNumbers[num]; exists {
			break
		}
		uniqueNumbers[num] = struct{}{}
	}

	return uniqueNumbers
}

// Fungsi untuk mencari irisan dari dua himpunan
func findIntersection(set1, set2 map[int]struct{}) []int {
	intersection := []int{}

	for num := range set1 {
		if _, exists := set2[num]; exists {
			intersection = append(intersection, num)
		}
	}

	return intersection
}
