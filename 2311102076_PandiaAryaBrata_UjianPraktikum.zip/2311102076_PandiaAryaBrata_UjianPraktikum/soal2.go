package main

//Nama	: Pandia Arya Brata
//Nim	: 2311102076
//Kelas	: IF-11-02

import (
	"fmt"
)

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

const nMax = 51

var ArrayMahasiswa [nMax]Mahasiswa
var N int

func main() {
	fmt.Print("Masukkan jumlah data mahasiswa: ")
	fmt.Scan(&N)
	for i := 0; i < N; i++ {
		fmt.Println("Masukkan data mahasiswa ke-", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&ArrayMahasiswa[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&ArrayMahasiswa[i].Nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&ArrayMahasiswa[i].Nilai)
	}

	var nim string
	fmt.Print("Masukkan NIM untuk mencari nilai pertama: ")
	fmt.Scan(&nim)
	nilaiPertama := cariNilaiPertama(nim)
	if nilaiPertama != -1 {
		fmt.Println("Nilai pertama mahasiswa dengan NIM", nim, "adalah", nilaiPertama)
	} else {
		fmt.Println("Mahasiswa dengan NIM", nim, "tidak ditemukan.")
	}

	fmt.Print("Masukkan NIM untuk mencari nilai terbesar: ")
	fmt.Scan(&nim)
	nilaiTerbesar := cariNilaiTerbesar(nim)
	if nilaiTerbesar != -1 {
		fmt.Println("Nilai terbesar mahasiswa dengan NIM", nim, "adalah", nilaiTerbesar)
	} else {
		fmt.Println("Mahasiswa dengan NIM", nim, "tidak ditemukan.")
	}
}

func cariNilaiPertama(nim string) int {
	for i := 0; i < N; i++ {
		if ArrayMahasiswa[i].NIM == nim {
			return ArrayMahasiswa[i].Nilai
		}
	}
	return -1
}

func cariNilaiTerbesar(nim string) int {
	nilaiTerbesar := -1
	found := false
	for i := 0; i < N; i++ {
		if ArrayMahasiswa[i].NIM == nim {
			found = true
			if ArrayMahasiswa[i].Nilai > nilaiTerbesar {
				nilaiTerbesar = ArrayMahasiswa[i].Nilai
			}
		}
	}
	if found {
		return nilaiTerbesar
	}
	return -1
}
