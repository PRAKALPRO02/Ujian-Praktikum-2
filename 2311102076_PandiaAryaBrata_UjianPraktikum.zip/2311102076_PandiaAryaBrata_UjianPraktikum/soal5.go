package main

//Nama	: Pandia Arya  Brata
//Nim	: 2311102076
//Kelas	: IF-11-02

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

type Party struct {
	ID    int
	Votes int
}

func main() {
	reader := bufio.NewReader(os.Stdin)

	const maxParties = 1000000
	votes := make([]int, maxParties+1)

	fmt.Println("Masukkan suara (akhiri dengan -1):")
	input, _ := reader.ReadString('\n')
	input = strings.TrimSpace(input)

	tokens := strings.Split(input, " ")
	for _, token := range tokens {
		num, err := strconv.Atoi(token)
		if err != nil || num == -1 {
			break
		}
		if num >= 1 && num <= maxParties {
			votes[num]++
		}
	}

	parties := []Party{}
	for id, count := range votes {
		if count > 0 {
			parties = append(parties, Party{ID: id, Votes: count})
		}
	}

	sort.Slice(parties, func(i, j int) bool {
		if parties[i].Votes == parties[j].Votes {
			return parties[i].ID < parties[j].ID
		}
		return parties[i].Votes > parties[j].Votes
	})

	fmt.Println("\nHasil perolehan suara:")
	for _, party := range parties {
		fmt.Printf("%d(%d) ", party.ID, party.Votes)
	}
	fmt.Println()
}
