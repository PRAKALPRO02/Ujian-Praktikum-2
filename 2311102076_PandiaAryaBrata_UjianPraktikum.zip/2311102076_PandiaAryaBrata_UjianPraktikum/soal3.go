package main

//Nama	: Pandia Arya Brata
//Nim	: 2311102076
//Kelas	: IF-11-02

import (
	"fmt"
	"strings"
)

const nProv = 10

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func main() {
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv
	var cariNama string

	InputData(&prov, &pop, &tumbuh, &cariNama)

	tercepatIndex := ProvinsiTercepat(tumbuh)
	fmt.Println("Provinsi dengan angka pertumbuhan tercepat:", prov[tercepatIndex])

	indexProvinsi := IndeksProvinsi(prov, cariNama)
	fmt.Println("Indeks provinsi yang dicari:", indexProvinsi)

	TampilkanData(prov, pop, tumbuh)
}

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv, cariNama *string) {
	fmt.Println("Masukkan data 10 provinsi:")

	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi %d:\n", i+1)
		fmt.Print("Nama: ")
		fmt.Scan(&(*prov)[i])
		fmt.Print("Populasi: ")
		fmt.Scan(&(*pop)[i])
		fmt.Print("Angka Pertumbuhan (%): ")
		fmt.Scan(&(*tumbuh)[i])
	}

	fmt.Println("Masukkan nama provinsi yang dicari:")
	fmt.Scan(cariNama)
}

func ProvinsiTercepat(tumbuh TumbuhProv) int {
	tercepatIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[tercepatIndex] {
			tercepatIndex = i
		}
	}
	return tercepatIndex
}

func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Provinsi dengan pertumbuhan di atas 2% (data asli dan prediksi):")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2.0 {
			prediksi := float64(pop[i]) * (1 + tumbuh[i]/100)
			fmt.Printf("%s: Populasi Saat Ini: %d, Prediksi Populasi Tahun Depan: %.0f\n",
				prov[i], pop[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) {
			return i
		}
	}
	return -1
}
