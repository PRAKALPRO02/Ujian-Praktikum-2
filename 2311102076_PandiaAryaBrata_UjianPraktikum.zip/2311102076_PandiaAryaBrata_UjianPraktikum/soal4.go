package main

//Nama	: Pandia Arya  Brata
//Nim	: 2311102076
//Kelas	: IF-11-02

import (
	"fmt"
)

type Player struct {
	Name    string
	Goals   int
	Assists int
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	players := make([]Player, n)
	fmt.Println("Masukkan data pemain (Nama, Jumlah Gol, Jumlah Assist):")
	for i := 0; i < n; i++ {
		fmt.Printf("Pemain %d:\n", i+1)
		fmt.Print("Nama: ")
		fmt.Scan(&players[i].Name)
		fmt.Print("Jumlah Gol: ")
		fmt.Scan(&players[i].Goals)
		fmt.Print("Jumlah Assist: ")
		fmt.Scan(&players[i].Assists)
	}

	SelectionSort(players)

	fmt.Println("\nPeringkat pemain berdasarkan jumlah gol dan assist:")
	for i, player := range players {
		fmt.Printf("%d. %s - Gol: %d, Assist: %d\n", i+1, player.Name, player.Goals, player.Assists)
	}
}

func SelectionSort(players []Player) {
	n := len(players)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if players[j].Goals > players[maxIdx].Goals {
				maxIdx = j
			} else if players[j].Goals == players[maxIdx].Goals {
				if players[j].Assists > players[maxIdx].Assists {
					maxIdx = j
				}
			}
		}
		players[i], players[maxIdx] = players[maxIdx], players[i]
	}
}
