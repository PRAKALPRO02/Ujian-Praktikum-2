package main

import "fmt"

type set [2022]int

func exist(T []int, val int) bool { //2311102042_Ahmad Titana
	for _, v := range T {
		if v == val {
			return true
		}
	}
	return false
}

func inputSet() (set, int) { //2311102042_Ahmad Titana
	var T set
	var n int

	for {
		var x int
		fmt.Scan(&x)
		if exist(T[:n], x) {
			break
		}
		T[n] = x
		n++
	}

	return T, n
}

func findIntersection(T1 []int, n1 int, T2 []int, n2 int) (set, int) { //2311102042_Ahmad Titana
	var result set
	var k int
	for i := 0; i < n1; i++ {
		if exist(T2[:n2], T1[i]) {
			result[k] = T1[i]
			k++
		}
	}
	return result, k
}

func printSet(T []int, n int) {
	for i := 0; i < n; i++ {
		if i > 0 {
			fmt.Print(" ")
		}
		fmt.Print(T[i])
	}
	fmt.Println()
}

func main() {
	var s1, s2, s3 set
	var n1, n2, n3 int
	s1, n1 = inputSet()
	s2, n2 = inputSet()
	s3, n3 = findIntersection(s1[:], n1, s2[:], n2)
	fmt.Println("Irisan dari kedua himpunan adalah:")
	printSet(s3[:], n3)
}
