package main

import (
	"fmt"
)

type Pemain struct {
	Nama    string
	Gol     int
	Assist  int
}

func main() { // 2311102042_ Ahmad Titana 
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	data := make([]Pemain, n)

	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama Gol Assist): ", i+1)
		var namaDepan, namaBelakang string
		fmt.Scan(&namaDepan, &namaBelakang)
		data[i].Nama = namaDepan + " " + namaBelakang
		fmt.Scan(&data[i].Gol, &data[i].Assist)
	}

	selectionSort(data)

	fmt.Println("\nData pemain setelah diurutkan:")
	for _, pemain := range data {
		fmt.Printf("%s %d %d\n", pemain.Nama, pemain.Gol, pemain.Assist)
	}
}

func selectionSort(data []Pemain) { // 2311102042_ Ahmad Titana
	n := len(data)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if data[j].Gol > data[maxIdx].Gol || (data[j].Gol == data[maxIdx].Gol && data[j].Assist > data[maxIdx].Assist) {
				maxIdx = j
			}
		}
		data[i], data[maxIdx] = data[maxIdx], data[i]
	}
}
