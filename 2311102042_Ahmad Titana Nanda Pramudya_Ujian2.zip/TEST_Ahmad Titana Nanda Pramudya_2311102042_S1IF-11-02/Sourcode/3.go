package main

import (
	"fmt"
)

const nProv = 10

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func main() {//2311102042_Ahmad Titana
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv
	var namaDicari string

	InputData(&prov, &pop, &tumbuh, &namaDicari)

	idxTercepat := ProvinsiTercepat(tumbuh)
	fmt.Printf("Provinsi dengan angka pertumbuhan tercepat: %s\n", prov[idxTercepat])

	idxProvinsi := IndeksProvinsi(prov, namaDicari)
	if idxProvinsi != -1 {
		fmt.Printf("Indeks provinsi %s adalah %d\n", namaDicari, idxProvinsi)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan\n", namaDicari)
	}

	fmt.Println("Daftar provinsi dengan pertumbuhan di atas 2% (dengan prediksi populasi):")
	TampilkanData(prov, pop, tumbuh)
}

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv, namaDicari *string) {//2311102042_Ahmad Titana
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data provinsi ke-%d (Nama Populasi Pertumbuhan): ", i+1)
		fmt.Scan(&(*prov)[i], &(*pop)[i], &(*tumbuh)[i])
	}
	fmt.Print("Masukkan nama provinsi yang ingin dicari: ")
	fmt.Scan(namaDicari)
}

func ProvinsiTercepat(tumbuh TumbuhProv) int {//2311102042_Ahmad Titana
	idx := 0
	maxPertumbuhan := tumbuh[0]
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > maxPertumbuhan {
			maxPertumbuhan = tumbuh[i]
			idx = i
		}
	}
	return idx
}

func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {//2311102042_Ahmad Titana
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2.0 {
			prediksi := float64(pop[i]) + float64(pop[i])*(tumbuh[i]/100)
			fmt.Printf("%s: Populasi Sekarang: %d, Prediksi Tahun Depan: %.0f\n", prov[i], pop[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if prov[i] == nama {
			return i
		}
	}
	return -1
}
