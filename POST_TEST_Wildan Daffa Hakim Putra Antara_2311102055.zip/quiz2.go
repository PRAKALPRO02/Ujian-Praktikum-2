/*
Nama : Wildan Daffa' Hakim Putra Antara
NIM : 2311102055
Kelas : IF - 11 - 02
*/

package main

import "fmt"

const nMax int = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}
type arrayMahasiswa [nMax]mahasiswa

func skorPertama(T arrayMahasiswa, N int, nim string) int {
	for i := 0; i < N; i++ {
		if T[i].NIM == nim {
			return i
		}
		i++
	}
	return -1
}

func skorTerbesar(T arrayMahasiswa, N int, nim string) int {
	var found int = skorPertama(T, N, nim)
	var i int
	if found != -1 {
		max := found
		for i = 0; i < N; i++ {
			if (T[max].nilai < T[i].nilai) && (T[i].NIM == nim) {
				max = i
			}
		}
		return max
	} else {
		return found
	}
}

func inputMahasiswa(T *arrayMahasiswa, N *int) {
	fmt.Print("Masukkan banyaknya MHS : ")
	fmt.Scan(N)
	for i := 0; i < *N; i++ {
		fmt.Print("Masukkan data ke ", i+1, " (Nim, Nama, Nilai) : ")
		fmt.Scan(&T[i].NIM, &T[i].nama, &T[i].nilai)
	}
}

func main() {
	var ArrMhs arrayMahasiswa
	var N int
	var nim string
	inputMahasiswa(&ArrMhs, &N)
	fmt.Print("Masukkan nim yang dicari : ")
	fmt.Scan(&nim)
	var idxPer int = skorPertama(ArrMhs, N, nim)
	var idxmax int = skorTerbesar(ArrMhs, N, nim)
	fmt.Println("Nilai pertama NIM", nim, "adalah : ", ArrMhs[idxPer].nilai)
	fmt.Println("Nilai terbesar NIM", nim, "adalah : ", ArrMhs[idxmax].nilai)

}
