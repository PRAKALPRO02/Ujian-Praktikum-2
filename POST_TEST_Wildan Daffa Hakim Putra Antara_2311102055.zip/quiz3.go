/*
Nama : Wildan Daffa' Hakim Putra Antara
NIM : 2311102055
Kelas : IF - 11 - 02
*/

package main

import "fmt"

const nProv int = 10

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	for i := 0; i < nProv; i++ {
		fmt.Print("Masukkan data ke ", i+1, " (nama, populasi, tumbuh (%)) : ")
		fmt.Scan(&prov[i], &pop[i], &tumbuh[i])
	}
}
func ProvinsiTercepat(tumbuh TumbuhProv) int {
	var maximum int = 0
	for i := 1; i < nProv; i++ {
		if tumbuh[maximum] < tumbuh[i] {
			maximum = i
		}
	}
	return maximum
}
func Prediksi(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			fmt.Printf("Penduduk prov %s tahun depan adalah : %d\n", prov[i], int((tumbuh[i]+1)*float64(pop[i])))
		}
	}
}
func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if prov[i] == nama {
			return i
		}
	}
	return -1
}

func main() {
	var DataProv NamaProv
	var DataPopulasi PopProv
	var DataPertumbuhan TumbuhProv
	var cariProv string
	InputData(&DataProv, &DataPopulasi, &DataPertumbuhan)
	fmt.Print("Masukkan nama Provinsi : ")
	fmt.Scan(&cariProv)
	var indexCepat int = ProvinsiTercepat(DataPertumbuhan)
	fmt.Println("Provinsi dengan pertumbuhan tercepat ", DataProv[indexCepat])
	var indexProvinsi int = IndeksProvinsi(DataProv, cariProv)
	if indexProvinsi != -1 {
		fmt.Println("Provinsi ", cariProv, "ada pada index : ", indexProvinsi)
	} else {
		fmt.Println("Provinsi ", cariProv, " tidak ada pada data")
	}
	Prediksi(DataProv, DataPopulasi, DataPertumbuhan)
}
