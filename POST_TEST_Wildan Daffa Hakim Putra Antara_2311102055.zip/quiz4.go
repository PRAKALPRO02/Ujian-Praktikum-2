/*
Nama : Wildan Daffa' Hakim Putra Antara
NIM : 2311102055
Kelas : IF - 11 - 02
*/

package main

import "fmt"

type pemainBola struct {
	name        string
	gol, assist int
}

type arrClub [1000]pemainBola

func SelSortCustomized(arr *arrClub, n int) {

	for k := 1; k <= n-1; k++ {
		idx_max := k - 1
		for i := k; i < n; i++ {
			if arr[idx_max].gol < arr[i].gol || (arr[idx_max].gol == arr[i].gol && arr[idx_max].assist <= arr[i].assist) {
				idx_max = i
			}
		}
		temp := arr[idx_max]
		arr[idx_max] = arr[k-1]
		arr[k-1] = temp
	}
}

func inputData(dataPemClub *arrClub, n int) {
	var namaDepan, namaBelakag string
	for i := 0; i < n && i < 1000; i++ {
		fmt.Scan(&namaDepan, &namaBelakag, &dataPemClub[i].gol, &dataPemClub[i].assist)
		dataPemClub[i].name = namaDepan + " " + namaBelakag
	}
}

func tampilPemain(dataPemClub arrClub, n int) {
	for i := 0; i < n; i++ {
		fmt.Println(dataPemClub[i].name, dataPemClub[i].gol, dataPemClub[i].assist)
	}

}

func main() {
	var DataPemain arrClub
	var n int

	fmt.Scan(&n)
	if n > 1000 {
		fmt.Println("Melebihi kapasitas")
		return
	}
	inputData(&DataPemain, n)
	SelSortCustomized(&DataPemain, n)
	fmt.Println()
	tampilPemain(DataPemain, n)

}
