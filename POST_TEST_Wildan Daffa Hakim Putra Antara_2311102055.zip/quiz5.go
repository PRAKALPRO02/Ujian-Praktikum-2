/*
Nama : Wildan Daffa' Hakim Putra Antara
NIM : 2311102055
Kelas : IF - 11 - 02
*/

package main

import "fmt"

const NMAX = 1000000

type partai struct {
	nama, suara int
}

func posisi(t [NMAX]partai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if t[i].nama == nama {
			return i
		}
	}
	return -1
}

func main() {
	var datpartai [NMAX]partai
	var n, nampartai int
	fmt.Scan(&nampartai)
	for nampartai != -1 {
		index := posisi(datpartai, n, nampartai)
		if index == -1 {
			datpartai[n].nama = nampartai
			datpartai[n].suara = 1
			n++
		} else {
			datpartai[index].suara++
		}
		fmt.Scan(&nampartai)
	}

	var temp partai
	for i := 1; i <= n-1; i++ {
		suar := i
		temp = datpartai[suar]
		for suar > 0 && temp.suara > datpartai[suar-1].suara {
			datpartai[suar] = datpartai[suar-1]
			suar--
		}
		datpartai[suar] = temp
	}

	for i := 0; i < n; i++ {
		fmt.Printf("%d(%d) ", datpartai[i].nama, datpartai[i].suara)
	}

}
