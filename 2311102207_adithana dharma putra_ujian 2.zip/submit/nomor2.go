/*
NAMA	: ADITHANA DHARMA PUTRA
NIM		: 2311102207
*/

package main
import "fmt"

const nMax int = 51

type Mahasiswa struct {
    NIM   string
    Nama  string
    Nilai int
}

type ArrayMahasiswa [nMax]Mahasiswa

func NilaiPertama(Mahasiswa ArrayMahasiswa, N int, NimDicari string) int {
    for i := 0; i < N; i++ {
        if Mahasiswa[i].NIM == NimDicari {
            return Mahasiswa[i].Nilai
        }
    }
    return -1
}

func NilaiMax(Mahasiswa ArrayMahasiswa, N int, NimDicari string) int {
    NilaiTerbesar := -1
    for i := 0; i < N; i++ {
        if Mahasiswa[i].NIM == NimDicari {
            if Mahasiswa[i].Nilai > NilaiTerbesar {
                NilaiTerbesar = Mahasiswa[i].Nilai
            }
        }
    }
    return NilaiTerbesar
}

func main() {
    var Mahasiswa ArrayMahasiswa
    var N int

    fmt.Print("Masukkan jumlah Mahasiswa (N): ")
    fmt.Scan(&N)

    for i := 0; i < N; i++ {
        fmt.Printf("Data Mahasiswa ke-%d:\n", i+1)

        fmt.Print("NIM: ")
        fmt.Scan(&Mahasiswa[i].NIM)

        fmt.Print("Nama: ")
        fmt.Scan(&Mahasiswa[i].Nama)

        fmt.Print("Nilai: ")
        fmt.Scan(&Mahasiswa[i].Nilai)
    }

    var NimDicari string
    fmt.Print("Masukkan NIM yang dicari datanya: ")
    fmt.Scan(&NimDicari)

    nilaiPertama := NilaiPertama(Mahasiswa, N, NimDicari)
    if nilaiPertama != -1 {
        fmt.Printf("Nilai pertama Mahasiswa dengan NIM %s adalah %d\n", NimDicari, nilaiPertama)
    } else {
        fmt.Printf("Data Mahasiswa dengan NIM %s tidak ditemukan.\n", NimDicari)
    }

    NilaiTerbesar := NilaiMax(Mahasiswa, N, NimDicari)
    if NilaiTerbesar != -1 {
        fmt.Printf("Nilai tertinggi Mahasiswa dengan NIM %s adalah %d\n", NimDicari, NilaiTerbesar)
    } else {
        fmt.Printf("Data Mahasiswa dengan NIM %s tidak ditemukan.\n", NimDicari)
    }
}

