/*
NAMA	: ADITHANA DHARMA PUTRA
NIM		: 2311102207
*/

package main
import "fmt"

type DataPemain struct {
	Nama string
	Gol int
	Assist int
}


func SelectionSort(Pemain []DataPemain) {
	n := len(Pemain)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if Pemain[j].Gol > Pemain[maxIdx].Gol {
				maxIdx = j
			} else if Pemain[j].Gol == Pemain[maxIdx].Gol {
				if Pemain[j].Assist > Pemain[maxIdx].Assist {
					maxIdx = j
				}
			}
		}
		Pemain[i], Pemain[maxIdx] = Pemain[maxIdx], Pemain[i]
	}
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	Pemain := make([]DataPemain, n)
	fmt.Println("Masukkan data pemain (Nama, Jumlah Gol, Jumlah Assist):")
	for i := 0; i < n; i++ {
		fmt.Printf("Pemain %d:\n", i+1)
		fmt.Print("Nama: ")
		fmt.Scanln(&Pemain[i].Nama)
		fmt.Print("Jumlah Gol: ")
		fmt.Scan(&Pemain[i].Gol)
		fmt.Print("Jumlah Assist: ")
		fmt.Scan(&Pemain[i].Assist)
	}

	SelectionSort(Pemain)

	fmt.Println("\nPeringkat pemain berdasarkan jumlah gol dan Assist:")
	for i, DataPemain := range Pemain {
		fmt.Printf("%d. %s - Gol: %d, Assist: %d\n", i+1, DataPemain.Nama, DataPemain.Gol, DataPemain.Assist)
	}
}
