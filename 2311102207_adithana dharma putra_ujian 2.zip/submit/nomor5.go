/*
NAMA	: ADITHANA DHARMA PUTRA
NIM		: 2311102207
*/

package main
import "fmt"

type Partai struct {
    nama  int
    suara int
}

const NMAX = 1000000
type tabPartai []Partai

func bubbleSort(arr tabPartai) {
    n := len(arr)
    for i := 0; i < n-1; i++ {
        for j := 0; j < n-i-1; j++ {
            if arr[j].suara < arr[j+1].suara || 
               (arr[j].suara == arr[j+1].suara && arr[j].nama > arr[j+1].nama) {
                arr[j], arr[j+1] = arr[j+1], arr[j]
            }
        }
    }
}

func posisi(daftar tabPartai, nama int) int {
    for i, partai := range daftar {
        if partai.nama == nama {
            return i
        }
    }
    return -1
}

func main() {
    var suara int 
    var daftarPartai tabPartai

    fmt.Println("Masukkan suara (akhiri dengan -1):")
    for {
        fmt.Scan(&suara)
        if suara == -1 {
            break
        }

        idx := posisi(daftarPartai, suara)
        if idx == -1 {
            daftarPartai = append(daftarPartai, Partai{nama: suara, suara: 1})
        } else {
            daftarPartai[idx].suara++
        }
    }

    bubbleSort(daftarPartai)

    fmt.Println("Hasil perolehan suara:")
    for _, partai := range daftarPartai {
        fmt.Printf("%d(%d) ", partai.nama, partai.suara)
    }
    fmt.Println()
}
