package main

import "fmt"

const nMax int = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

type arrayMahasiswa [nMax]mahasiswa


func inputMahasiswa(T *arrayMahasiswa, N *int) {
	fmt.Scan(N)
	var i int = 0
	for i < *N {
		fmt.Scan(&T[i].NIM, &T[i].nama, &T[i].nilai)
		i++
	}
}

func nilaiTerbesar(T arrayMahasiswa, N int, nim string) int {
	var cari int = cariNilaiPertama(T, N, nim)
	var i, max int
	if cari != -1 {
		max = cari
		for i = cari; i < N; i++ {
			if T[max].nilai < T[i].nilai && T[i].NIM == nim {
				max = i
			}
		}
		return max
	} else {
		return cari
	}
}
func cariNilaiPertama(T arrayMahasiswa, N int, nim string) int {
	var i, cari int
	cari = -1
	i = 0
	for i < N && cari == -1 {
		if T[i].NIM == nim {
			cari = i
		}
		i++
	}
	return cari
}


	func main() {
		var A arrayMahasiswa
		var M, i, j int
		var NIM string
	
		inputMahasiswa(&A, &M)
		NIM = "113"
		i = cariNilaiPertama(A, M, NIM)
		j = nilaiTerbesar(A, M, NIM)
	
		if i != -1 {
			fmt.Println("Nilai pertama dari", NIM, "yaitu", A[i].nilai)
		} else {
			fmt.Println("NIM", NIM, "tidak ada")
		}
	
		if j != -1 {
			fmt.Println("Nilai terbesar dari NIM", NIM, "yaitu", A[j].nilai)
		} else {
			fmt.Println("NIM", NIM, "tidak ada")
		}
	}

// GALIH TRISNA
// 2311102050