package main

import "fmt"
type set [2022]int

func exist(T set, n int, vall int) bool {
	var status bool = false
	var i int = 0
	for i < n && !status {
		status = T[i] == vall
		i++
	}
	return status
}

func inputSet(T *set, n *int) {
	var bilangan int
	fmt.Scan(&bilangan)
	for *n < 2022 && !exist(*T,*n,bilangan) {
		T[*n] = bilangan
		*n++
		fmt.Scan(&bilangan)
	}

}

func findIntersection(T1, T2 set, n, m int, T3 *set, h *int) {
	*h = 0
	var j int = 0
	for j < n {
		if exist(T2,m, T1[j]) {
			T3[*h] = T1[j]
			*h++
		}
		j++
	}
}

func printSet(T set, n int) {
	var i int = 0
	for i < n {
		fmt.Print(T[i]," ")
		i++
	}
}

func main() {
	var S1, S2, S3 set
	var n1, n2, n3 int
	inputSet(&S1, &n1)
	inputSet(&S2, &n2)
	findIntersection(S1, S2, n1, n2, &S3, &n3)
	printSet(S3, n3)
}
