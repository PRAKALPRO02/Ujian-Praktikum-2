package main

import (
	"fmt"
)

type Pemain struct {
	Nama   string
	Gol    int
	Assist int
}

func InputData(n int) []Pemain { //2311102074_Arvan Murbiyanto
	pemain := make([]Pemain, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama, Gol, Assist):\n", i+1)
		var namaDepan, namaBelakang string
		fmt.Scan(&namaDepan, &namaBelakang)
		pemain[i].Nama = namaDepan + " " + namaBelakang
		fmt.Scan(&pemain[i].Gol, &pemain[i].Assist)
	}
	return pemain
}

func SelectionSort(pemain []Pemain) { //2311102074_Arvan Murbiyanto
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if pemain[j].Gol > pemain[maxIdx].Gol ||
				(pemain[j].Gol == pemain[maxIdx].Gol && pemain[j].Assist > pemain[maxIdx].Assist) {
				maxIdx = j
			}
		}
		pemain[i], pemain[maxIdx] = pemain[maxIdx], pemain[i]
	}
}

func TampilkanData(pemain []Pemain) { //2311102074_Arvan Murbiyanto
	fmt.Println("Peringkat pemain berdasarkan jumlah gol dan assist:")
	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", p.Nama, p.Gol, p.Assist)
	}
}

func main() { //2311102074_Arvan Murbiyanto
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	pemain := InputData(n)

	SelectionSort(pemain)

	TampilkanData(pemain)
}