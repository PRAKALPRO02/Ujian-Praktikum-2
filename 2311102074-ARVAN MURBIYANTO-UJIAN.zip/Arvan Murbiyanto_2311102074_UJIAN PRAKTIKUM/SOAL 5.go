package main

import (
	"fmt"
	"sort"
)

type Partai struct {
	nama  int
	suara int
}

func main() { //2311102074_Arvan Murbiyanto
	const MAX = 1000000
	var suara [MAX + 1]int 
	var input int

	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		suara[input]++
	}

	var hasil []Partai
	for i := 1; i <= MAX; i++ {
		if suara[i] > 0 {
			hasil = append(hasil, Partai{nama: i, suara: suara[i]})
		}
	}

	sort.Slice(hasil, func(i, j int) bool {
		if hasil[i].suara == hasil[j].suara {
			return hasil[i].nama < hasil[j].nama 
		}
		return hasil[i].suara > hasil[j].suara
	})

	for i, p := range hasil {
		if i > 0 {
			fmt.Print(" ")
		}
		fmt.Printf("%d(%d)", p.nama, p.suara)
	}
	fmt.Println()
}
