package main

import (
	"fmt"
	"strings"
)

// Konstanta jumlah provinsi
const nProv = 10

// Tipe data
type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

// Prosedur InputData
func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	fmt.Println("Masukkan data provinsi (nama, populasi, angka pertumbuhan):")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi %d:\n", i+1)
		fmt.Print("Nama: ")
		fmt.Scan(&(*prov)[i])
		fmt.Print("Populasi: ")
		fmt.Scan(&(*pop)[i])
		fmt.Print("Angka Pertumbuhan (%): ")
		fmt.Scan(&(*tumbuh)[i])
	}
}

// Fungsi ProvinsiTercepat
func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIndex] {
			maxIndex = i
		}
	}
	return maxIndex
}

// Fungsi IndeksProvinsi
func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) { // Perbandingan case-insensitive
			return i
		}
	}
	return -1 // Jika tidak ditemukan
}

// Prosedur TampilkanData
func TampilkanData(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Provinsi dengan angka pertumbuhan di atas 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2 {
			prediksi := float64(pop[i]) * (1 + tumbuh[i]/100)
			fmt.Printf("%s: Populasi saat ini = %d, Prediksi tahun berikutnya = %.0f\n", prov[i], pop[i], prediksi)
		}
	}
}

func main() {
	// Deklarasi variabel
	var prov NamaProv
	var pop PopProv
	var tumbuh TumbuhProv
	var cariNama string

	// Input data
	InputData(&prov, &pop, &tumbuh)

	// Input nama provinsi yang akan dicari
	fmt.Print("Masukkan nama provinsi yang akan dicari: ")
	fmt.Scan(&cariNama)

	// Menentukan provinsi dengan angka pertumbuhan tercepat
	tercepatIndex := ProvinsiTercepat(tumbuh)
	fmt.Println("Provinsi dengan angka pertumbuhan tercepat:", prov[tercepatIndex])

	// Mencari indeks provinsi berdasarkan nama
	indexCari := IndeksProvinsi(prov, cariNama)
	if indexCari != -1 {
		fmt.Printf("Indeks provinsi %s adalah: %d\n", cariNama, indexCari)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan.\n", cariNama)
	}

	// Menampilkan data provinsi dengan angka pertumbuhan di atas 2%
	TampilkanData(prov, pop, tumbuh)
}

// Zahrina Antika Malahati_2311102109
