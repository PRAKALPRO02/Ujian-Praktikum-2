package main

import "fmt"

// Definisi struct mahasiswa
type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

// Fungsi untuk mencari nilai pertama mahasiswa dengan NIM tertentu
func cariNilaiPertama(data []mahasiswa, n int, nim string) int {
	for i := 0; i < n; i++ {
		if data[i].NIM == nim {
			return data[i].nilai
		}
	}
	return -1 // Mengembalikan -1 jika NIM tidak ditemukan
}

// Fungsi untuk mencari nilai terbesar mahasiswa dengan NIM tertentu
func cariNilaiTerbesar(data []mahasiswa, n int, nim string) int {
	maxNilai := -1
	for i := 0; i < n; i++ {
		if data[i].NIM == nim && data[i].nilai > maxNilai {
			maxNilai = data[i].nilai
		}
	}
	return maxNilai
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah data mahasiswa: ")
	fmt.Scan(&n)

	// Array untuk menyimpan data mahasiswa
	data := make([]mahasiswa, n)

	// Input data mahasiswa
	fmt.Println("Masukkan data mahasiswa (NIM, nama, nilai):")
	for i := 0; i < n; i++ {
		fmt.Print("Data ke-", i+1, ": ")
		fmt.Scan(&data[i].NIM, &data[i].nama, &data[i].nilai)
	}

	// Input NIM yang akan dicari
	var nim string
	fmt.Print("Masukkan NIM yang akan dicari: ")
	fmt.Scan(&nim)

	// Mencari nilai pertama
	nilaiPertama := cariNilaiPertama(data, n, nim)
	if nilaiPertama != -1 {
		fmt.Println("Nilai pertama mahasiswa dengan NIM", nim, "adalah:", nilaiPertama)
	} else {
		fmt.Println("Mahasiswa dengan NIM", nim, "tidak ditemukan.")
	}

	// Mencari nilai terbesar
	nilaiTerbesar := cariNilaiTerbesar(data, n, nim)
	if nilaiTerbesar != -1 {
		fmt.Println("Nilai terbesar mahasiswa dengan NIM", nim, "adalah:", nilaiTerbesar)
	} else {
		fmt.Println("Mahasiswa dengan NIM", nim, "tidak ditemukan.")
	}
}

// Zahrina Antika Malahati_2311102109
