package main

import (
	"fmt"
)

// Struktur untuk pemain
type Player struct {
	Name    string
	Goals   int
	Assists int
}

// Fungsi untuk Selection Sort
func selectionSort(players []Player) {
	n := len(players)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if players[j].Goals > players[maxIdx].Goals ||
				(players[j].Goals == players[maxIdx].Goals && players[j].Assists > players[maxIdx].Assists) {
				maxIdx = j
			}
		}
		players[i], players[maxIdx] = players[maxIdx], players[i]
	}
}

// Fungsi utama
func main() {
	var n int
	fmt.Println("Masukkan jumlah pemain:")
	fmt.Scan(&n)

	players := make([]Player, n)
	fmt.Println("Masukkan data pemain (Nama, Gol, Assist):")
	for i := 0; i < n; i++ {
		fmt.Scan(&players[i].Name, &players[i].Goals, &players[i].Assists)
	}

	// Sorting menggunakan Selection Sort
	selectionSort(players)

	fmt.Println("Hasil urutan pemain:")
	for _, player := range players {
		fmt.Printf("%s %d %d\n", player.Name, player.Goals, player.Assists)
	}
}

// Zahrina Antika Malahati_2311102109
