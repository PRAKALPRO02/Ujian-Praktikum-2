package main

import (
	"fmt"
)

const MAX = 1000000

// Struct untuk Partai
type Partai struct {
	Nama  int
	Suara int
}

// Fungsi untuk mencari indeks partai dalam tabel
func posisi(tabelPartai []Partai, nama int) int {
	for i, partai := range tabelPartai {
		if partai.Nama == nama {
			return i
		}
	}
	return -1 // Jika tidak ditemukan
}

// Fungsi untuk melakukan Insertion Sort secara descending
func insertionSort(partai []Partai) {
	for i := 1; i < len(partai); i++ {
		key := partai[i]
		j := i - 1

		// Geser elemen yang lebih kecil ke kanan
		for j >= 0 && (partai[j].Suara < key.Suara || (partai[j].Suara == key.Suara && partai[j].Nama > key.Nama)) {
			partai[j+1] = partai[j]
			j--
		}
		partai[j+1] = key
	}
}

func main() {
	// Deklarasi variabel
	var suaraMasuk int
	partaiMap := make([]Partai, 0, MAX)

	fmt.Println("Masukkan suara partai (akhiri dengan -1):")

	// Input suara partai
	for {
		fmt.Scan(&suaraMasuk)
		if suaraMasuk == -1 {
			break
		}

		pos := posisi(partaiMap, suaraMasuk)
		if pos != -1 {
			// Jika partai sudah ada, tambahkan suara
			partaiMap[pos].Suara++
		} else {
			// Jika partai belum ada, tambahkan ke array
			partaiMap = append(partaiMap, Partai{Nama: suaraMasuk, Suara: 1})
		}
	}

	// Urutkan partai berdasarkan suara dan nama partai
	insertionSort(partaiMap)

	// Tampilkan hasil
	fmt.Println("Hasil perolehan suara:")
	for _, partai := range partaiMap {
		fmt.Printf("%d(%d) ", partai.Nama, partai.Suara)
	}
	fmt.Println()
}

// Zahrina Antika Malahati_2311102109
