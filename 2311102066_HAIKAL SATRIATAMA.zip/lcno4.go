package main

import "fmt"

type Player struct {
	Name    string
	Goals   int
	Assists int
}

func insertionSort(players []Player) {
	n := len(players)
	for i := 1; i < n; i++ {
		key := players[i]
		j := i - 1
		for j >= 0 && (players[j].Goals < key.Goals ||
			(players[j].Goals == key.Goals && players[j].Assists < key.Assists)) {
			players[j+1] = players[j]
			j--
		}
		players[j+1] = key
	}
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	players := make([]Player, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan nama, jumlah gol, dan assist pemain ke-%d: ", i+1)
		fmt.Scan(&players[i].Name, &players[i].Goals, &players[i].Assists)
	}

	insertionSort(players)

	fmt.Println("Pemain setelah diurutkan:")
	for _, player := range players {
		fmt.Printf("%s - Goals: %d, Assists: %d\n", player.Name, player.Goals, player.Assists)
	}
}
