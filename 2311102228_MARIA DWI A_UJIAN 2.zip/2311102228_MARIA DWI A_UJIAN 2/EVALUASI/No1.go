package main

import "fmt"


/*
Nama : Maria Dwi A
NIM : 2311102228

*/

type himpunan228 [100]int 

func inputan(himpunanA *himpunan228, himpunanB *himpunan228,  jumlahA *int, jumlahB *int) {

	fmt.Print("Masukkan jumlah elemen dalam himpunan A : ")
	fmt.Scan(jumlahA)

	fmt.Println("Masukkan elemen himpunan A : ")
	for i:= 0; i < *jumlahA; i++ {
		fmt.Scan(&(himpunanA)[i])

	}

	fmt.Print("Masukkan jumlah elemen dalam himpunan B : ")
	fmt.Scan(jumlahB)


	fmt.Println("Masukkan elemen himpunan B : ")
	for j := 0; j < *jumlahB; j++ {
		fmt.Scan(&(*himpunanB)[j])
	}
}

func cariIrisan(himpunanA *himpunan228, himpunanB *himpunan228, jumlahA int, jumlahB int) (*himpunan228, int) {
	k := 0
	hasil := &himpunan228{}
	
	for i := 0; i < jumlahA; i++ {
		for j := 0; j < jumlahB; j++ {
			if (*himpunanA)[i] == (*himpunanB)[j] {
				ada := false 
				for m := 0; m < k; m++ {
					if (*hasil)[m] == (*himpunanA)[i]{
						ada = true 
						break
					}
				}
				if !ada {
					(*hasil)[k] = (*himpunanA)[i]
					k++
				}

			}
		}
	}
	return  hasil, k
}

func main() {
	var himpunanA, himpunanB himpunan228
	var jumlahA, jumlahB int

	inputan(&himpunanA, &himpunanB, &jumlahA, &jumlahB)
	hasil, jumlahHasil := cariIrisan(&himpunanA, &himpunanB, jumlahA, jumlahB)

	fmt.Println("\nElemen irisan himpunan A dan B adalah : ")
	for i := 0; i < jumlahHasil; i++ {
		fmt.Print(hasil[i], " ")
	}
	fmt.Println()
}