/*
Nama : Maria Dwi A
NIM : 2311102228
Kelas : S1 -IF - 11 - 02 


*/
package main

import "fmt"

const nMax = 51 


type Mahasiswa struct {
	nama228 string
	nim string
	nilai int

}

type arrayMahasiswa [nMax]Mahasiswa


func cariNilaiPertama (nim string, data arrayMahasiswa, n int) (int, bool) {

	for i := 0; i < n; i++ {
		if data[i].nim == nim {
			return data[i].nilai, true 

		}
	}
	return 0, false 
}

func cariNilaiTerbesar(nim string, data arrayMahasiswa, n int) (int, bool) {
	ketemu := false 
	nilaiMaksimal := -1
	for i := 0; i < n; i++ {
		if data[i].nim == nim {
			ketemu = true
			if data[i].nilai > nilaiMaksimal {
				nilaiMaksimal = data[i].nilai
			}
		}
	}
	return nilaiMaksimal, ketemu
}

func main() {
	var dataMahasiswa arrayMahasiswa
	var n int


	fmt.Print("Masukkan jumlah mahasiswa : ")
	fmt.Scan(&n)

	if n < 1 || n > nMax {
		fmt.Printf("jumlah mahasiswa harus diantara 1 dan %d\n", nMax)
		return 

	}

	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d\n", i+1)
		fmt.Print("Nama : ")
		fmt.Scan(&dataMahasiswa[i].nama228)
		fmt.Print("NIM : ")
		fmt.Scan(&dataMahasiswa[i].nim)
		fmt.Print("Nilai : ")
		fmt.Scan(&dataMahasiswa[i].nilai)
	}

	var cari string
	fmt.Print("Masukkan NIM yang dicari : ")
	fmt.Scan(&cari)


	nilaiPertama, ketemu1 := cariNilaiPertama(cari, dataMahasiswa, n)

	nilaiTerbesar, ketemu2 := cariNilaiTerbesar(cari, dataMahasiswa, n)

	if ketemu1 {
		fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah %d\n", cari, nilaiPertama)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", cari)

	}
	

	if ketemu2 {
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d\n", cari, nilaiTerbesar)

	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", cari)
	}
}