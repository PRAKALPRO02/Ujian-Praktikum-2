package main

import "fmt"

/*

Nama : Maria Dwi A
NIM : 2311102228
*/

type Partai struct{
	nama228 int
	suara int
}

func main() {
	const nMax = 1000000
	var suaraMasuk [nMax] int
	var partai [nMax]Partai
	var jumlahPartai int

	fmt.Print("Masukkan nomor partai yang dipilihah (-1 untuk berhenti) : ")
	for {
		var pilihan int
		fmt.Scan(&pilihan) 
		if pilihan == -1 {
			break
		}
		if pilihan >= 1 && pilihan <= nMax {
			suaraMasuk[pilihan-1]++
		}
	}

	for i := 0; i < nMax; i++ {
		if suaraMasuk[i] > 0 {
			partai[jumlahPartai] = Partai{
				nama228 : i + 1,
				suara : suaraMasuk[i],
			}
			jumlahPartai++
		}
	}

	for i := 0; i < jumlahPartai-1; i++ {
		for j := 0; j < jumlahPartai-i-1; j++ {
			if partai[j].suara < partai[j+1].suara || 
				(partai[j].suara == partai[j+1].suara && partai[j].nama228 > partai[j+1].nama228) {

				temp := partai[j]
				partai[j] = partai[j+1]
				partai[j+1] = temp
		}
	}
}

fmt.Println("Hasil perolehan suara partai : ")
for i := 0; i < jumlahPartai; i++ {
	fmt.Printf("%d (%d)\n", partai[i].nama228, partai[i].suara)
}

}