package main

import "fmt"

const NMAX = 1000000

type tabPartai [NMAX]int

func posisi(t tabPartai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if t[i] == nama {
			return i
		}
	}
	return -1
}

func main() {
	var suaraMasuk []int
	var suara int

	fmt.Println("Masukkan suara partai (akhiri dengan -1):")
	for {
		fmt.Scan(&suara)
		if suara == -1 {
			break
		}
		suaraMasuk = append(suaraMasuk, suara)
	}

	if len(suaraMasuk) == 0 {
		fmt.Println()
		return
	}

	var namaPartai tabPartai
	var perolehanSuara tabPartai
	jumlahPartai := 0

	for i := 0; i < len(suaraMasuk); i++ {
		p := suaraMasuk[i]
		idx := posisi(namaPartai, jumlahPartai, p)
		if idx == -1 {
			namaPartai[jumlahPartai] = p
			perolehanSuara[jumlahPartai] = 1
			jumlahPartai++
		} else {
			perolehanSuara[idx]++
		}
	}

	for i := 1; i < jumlahPartai; i++ {
		keyNama := namaPartai[i]
		keySuara := perolehanSuara[i]
		j := i - 1

		for j >= 0 && (perolehanSuara[j] < keySuara || (perolehanSuara[j] == keySuara && namaPartai[j] > keyNama)) {
			namaPartai[j+1] = namaPartai[j]
			perolehanSuara[j+1] = perolehanSuara[j]
			j--
		}
		namaPartai[j+1] = keyNama
		perolehanSuara[j+1] = keySuara
	}

	for i := 0; i < jumlahPartai; i++ {
		fmt.Printf("%d(%d) ", namaPartai[i], perolehanSuara[i])
	}
	fmt.Println()
}