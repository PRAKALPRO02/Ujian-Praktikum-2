package main

import (
	"fmt"
)

const nProv = 10

type namaProv [nProv]string
type popProv [nProv]int
type tumbuhProv [nProv]float64

func inputData(prov *namaProv, pop *popProv, tumbuh *tumbuhProv) {
	fmt.Println("Masukkan data (Provinsi Populasi Pertumbuhan):")
	for i := 0; i < nProv; i++ {
		fmt.Scan(&prov[i], &pop[i], &tumbuh[i])
	}
}

func provinsiTercepat(tumbuh tumbuhProv) int {
	maxIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIndex] {
			maxIndex = i
		}
	}
	return maxIndex
}

func prediksi(prov namaProv, pop popProv, tumbuh tumbuhProv) {
	fmt.Println("Prediksi populasi untuk provinsi dengan pertumbuhan > 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 2 {
			prediksiPop := float64(pop[i]) * (1 + tumbuh[i]/100)
			fmt.Printf("%s: %.0f\n", prov[i], prediksiPop)
		}
	}
}

func indeksProvinsi(prov namaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if prov[i] == nama {
			return i
		}
	}
	return -1
}

func main() {
	var prov namaProv
	var pop popProv
	var tumbuh tumbuhProv

	inputData(&prov, &pop, &tumbuh)

	var cariNama string
	fmt.Print("Masukkan nama provinsi yang dicari: ")
	fmt.Scan(&cariNama)

	tercepatIndex := provinsiTercepat(tumbuh)
	fmt.Println("Provinsi dengan pertumbuhan tercepat:", prov[tercepatIndex])

	cariIndex := indeksProvinsi(prov, cariNama)
	if cariIndex == -1 {
		fmt.Println("Provinsi tidak ditemukan.")
	} else {
		fmt.Println("Indeks provinsi yang dicari:", cariIndex)
	}

	prediksi(prov, pop, tumbuh)
}