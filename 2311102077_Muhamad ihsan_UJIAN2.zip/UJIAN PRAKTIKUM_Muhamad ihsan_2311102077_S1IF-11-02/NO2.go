package main

import "fmt"

const max = 51

type mhs struct {
	nim   string
	nama  string
	nilai int
}

type arrMhs [max]mhs

func input(arr *arrMhs, n *int) {
	fmt.Println("Masukkan data (NIM Nama Nilai):")
	for i := 0; i < *n; i++ {
		var nim, nama string
		var nilai int
		fmt.Scan(&nim, &nama, &nilai)
		arr[i] = mhs{nim: nim, nama: nama, nilai: nilai}
	}
}

func cariNilaiPertama(arr arrMhs, n int, nim string) int {
	for i := 0; i < n; i++ {
		if arr[i].nim == nim {
			return arr[i].nilai
		}
	}
	return -1
}

func cariNilaiMaks(arr arrMhs, n int, nim string) int {
	maks := -1
	ada := false
	for i := 0; i < n; i++ {
		if arr[i].nim == nim {
			ada = true
			if arr[i].nilai > maks {
				maks = arr[i].nilai
			}
		}
	}
	if ada {
		return maks
	}
	return -1
}

func tampilkan(h1, h2 int) {
	fmt.Println("Hasil:")
	if h1 == -1 {
		fmt.Println("Nilai pertama: Tidak ditemukan")
	} else {
		fmt.Printf("Nilai pertama: %d\n", h1)
	}
	if h2 == -1 {
		fmt.Println("Nilai terbesar: Tidak ditemukan")
	} else {
		fmt.Printf("Nilai terbesar: %d\n", h2)
	}
}

func main() {
	var arr arrMhs
	var n int

	fmt.Print("Jumlah data (N): ")
	fmt.Scan(&n)

	input(&arr, &n)

	var nim string
	fmt.Print("Cari NIM: ")
	fmt.Scan(&nim)

	h1 := cariNilaiPertama(arr, n, nim)
	h2 := cariNilaiMaks(arr, n, nim)

	tampilkan(h1, h2)
}