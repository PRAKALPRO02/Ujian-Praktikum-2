package main

import (
	"fmt"
)

const nMax = 51

type Mahasiswa struct {
	NIM   string
	Nama  string
	Nilai int
}

type ArrayMahasiswa [nMax]Mahasiswa

func main() { //2311102064_Ajitriprasetyo
	var dataMahasiswa ArrayMahasiswa
	var N int

	fmt.Print("Masukkan jumlah mahasiswa: ")
	fmt.Scan(&N)

	for i := 0; i < N; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d (NIM Nama Nilai): ", i+1)
		fmt.Scan(&dataMahasiswa[i].NIM, &dataMahasiswa[i].Nama, &dataMahasiswa[i].Nilai)
	}

	var cariNIM string
	fmt.Print("\nMasukkan NIM mahasiswa untuk mencari nilai pertama: ")
	fmt.Scan(&cariNIM)
	nilaiPertama := cariNilaiPertama(dataMahasiswa, N, cariNIM)
	if nilaiPertama != -1 {
		fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah %d\n", cariNIM, nilaiPertama)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan\n", cariNIM)
	}

	fmt.Print("\nMasukkan NIM mahasiswa untuk mencari nilai terbesar: ")
	fmt.Scan(&cariNIM)
	nilaiTerbesar := cariNilaiTerbesar(dataMahasiswa, N, cariNIM)
	if nilaiTerbesar != -1 {
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d\n", cariNIM, nilaiTerbesar)
	} else {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan\n", cariNIM)
	}
}

func cariNilaiPertama(data ArrayMahasiswa, N int, cariNIM string) int { //2311102064_Ajitriprasetyo
	for i := 0; i < N; i++ {
		if data[i].NIM == cariNIM {
			return data[i].Nilai
		}
	}
	return -1
}

func cariNilaiTerbesar(data ArrayMahasiswa, N int, cariNIM string) int { //2311102064_Ajitriprasetyo
	nilaiMax := -1
	found := false
	for i := 0; i < N; i++ {
		if data[i].NIM == cariNIM {
			found = true
			if data[i].Nilai > nilaiMax {
				nilaiMax = data[i].Nilai
			}
		}
	}
	if !found {
		return -1
	}
	return nilaiMax
}
