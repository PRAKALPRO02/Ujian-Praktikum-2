package main

import (
	"fmt"
)

const nProv = 11

type NAMAPROVINSI [nProv]string
type POPULASIPROVINSI [nProv]int
type TUMBUHPROVINSI [nProv]float64

func InputData(prov *NAMAPROVINSI, pop *POPULASIPROVINSI, tumbuh *TUMBUHPROVINSI) {
	fmt.Println("Masukkan provinsi (Nama, Populasi, Pertumbuhan):")
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi ke-%d: ", i+1)
		fmt.Scanln(&prov[i], &pop[i], &tumbuh[i])
	}
}
func ProvinsiTercepat(tumbuh TUMBUHPROVINSI) int {
	indeksTercepat := 0
	pertumbuhanTercepat := tumbuh[0]
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > pertumbuhanTercepat {
			pertumbuhanTercepat = tumbuh[i]
			indeksTercepat = i
		}
	}
	return indeksTercepat
}

func Prediksi(prov NAMAPROVINSI, pop POPULASIPROVINSI, tumbuh TUMBUHPROVINSI) {
	fmt.Println("Prediksi jumlah penduduk tahun depan (pertumbuhan di atas 2%):")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			prediksi := float64(pop[i]) + (float64(pop[i]) * tumbuh[i])
			fmt.Printf("%s: %.0f\n", prov[i], prediksi)
		}
	}
}

func IndeksProvinsi(prov NAMAPROVINSI, nama string) int {
	for i := 0; i < nProv; i++ {
		if prov[i] == nama {
			return i
		}
	}
	return -1
}

func main() {
	var prov NAMAPROVINSI
	var pop POPULASIPROVINSI
	var tumbuh TUMBUHPROVINSI
	var namaCari string

	InputData(&prov, &pop, &tumbuh)

	indeksTercepat := ProvinsiTercepat(tumbuh)
	fmt.Printf("Provinsi dengan pertumbuhan tercepat: %s\n", prov[indeksTercepat])

	fmt.Print("Masukan nama provinsi yang dicari: ")
	fmt.Scanln(&namaCari)

	indeksCari := IndeksProvinsi(prov, namaCari)
	if indeksCari != -1 {
		fmt.Printf("Indeks provinsi %s: %d\n", namaCari, indeksCari)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan\n", namaCari)
	}

	Prediksi(prov, pop, tumbuh)
}
