package main

import (
	"fmt"
)

type Pemain struct {
	NAMA   string
	GOL    int
	ASSIST int
}

func selectionSort(pemain []Pemain) {
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {
			if pemain[j].GOL > pemain[maxIdx].GOL ||
				(pemain[j].GOL == pemain[maxIdx].GOL && pemain[j].ASSIST > pemain[maxIdx].ASSIST) {
				maxIdx = j
			}
		}
		pemain[i], pemain[maxIdx] = pemain[maxIdx], pemain[i]
	}
}

func main() {
	var n int
	fmt.Print("Masukan jumlah pemain: ")
	fmt.Scan(&n)

	if n <= 0 || n > 1000 {
		fmt.Println("Jumlah pemain tidak valid")
		return
	}

	pemain := make([]Pemain, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukan pemain ke-%d (NAMA GOL ASSIST): ", i+1)
		fmt.Scan(&pemain[i].NAMA, &pemain[i].GOL, &pemain[i].ASSIST)
	}

	selectionSort(pemain)

	fmt.Println("\nPemain berdasarkan jumlah GOL dan ASSIST terbanyak:")
	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", p.NAMA, p.GOL, p.ASSIST)
	}
}
