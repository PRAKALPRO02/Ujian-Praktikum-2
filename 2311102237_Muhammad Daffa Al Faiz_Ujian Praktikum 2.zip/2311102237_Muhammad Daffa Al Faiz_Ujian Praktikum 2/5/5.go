package main

import (
	"fmt"
	"sort"
)

type Partai struct {
	NAMA  int
	SUARA int
}

type tabPartai []Partai

func main() {
	var SUARA int
	var DaftarPartai tabPartai

	fmt.Println("Masukan Suara:")
	for {
		fmt.Scan(&SUARA)
		if SUARA == -1 {
			break
		}
		idx := posisi(DaftarPartai, SUARA)
		if idx == -1 {
			DaftarPartai = append(DaftarPartai, Partai{NAMA: SUARA, SUARA: 1})
		} else {
			DaftarPartai[idx].SUARA++
		}
	}

	sort.Slice(DaftarPartai, func(i, j int) bool {
		if DaftarPartai[i].SUARA == DaftarPartai[j].SUARA {
			return DaftarPartai[i].NAMA < DaftarPartai[j].NAMA
		}
		return DaftarPartai[i].SUARA > DaftarPartai[j].SUARA
	})

	fmt.Println("Hasil perolehan SUARA:")
	for _, partai := range DaftarPartai {
		fmt.Printf("%d(%d) ", partai.NAMA, partai.SUARA)
	}
	fmt.Println()
}

func posisi(daftar tabPartai, NAMA int) int {
	for i, partai := range daftar {
		if partai.NAMA == NAMA {
			return i
		}
	}
	return -1
}
