//Muhammad Daffa Al Faiz
//2311102237

package main

import (
	"fmt"
)

const nMax = 51

type Mahasiswa struct {
	NIM   string
	NAMA  string
	NILAI int
}

type ArrayMahasiswa [nMax]Mahasiswa

func main() {
	var N int
	var data ArrayMahasiswa

	fmt.Print("Masukan jumlah data mahasiswa: ")
	fmt.Scan(&N)

	for i := 0; i < N; i++ {
		fmt.Printf("Masukan data mahasiswa ke-%d (NIM NAMA NILAI): ", i+1)
		fmt.Scan(&data[i].NIM, &data[i].NAMA, &data[i].NILAI)
	}

	var NIM string
	fmt.Print("Masukan NIM untuk pencarian: ")
	fmt.Scan(&NIM)

	NilaiPertama := cariNilaiPertama(data, N, NIM)
	NilaiTerbesar := cariNilaiTerbesar(data, N, NIM)

	fmt.Printf("NILAI pertama mahasiswa dengan NIM %s: %d\n", NIM, NilaiPertama)
	fmt.Printf("NILAI terbesar mahasiswa dengan NIM %s: %d\n", NIM, NilaiTerbesar)
}

func cariNilaiPertama(data ArrayMahasiswa, N int, NIM string) int {
	for i := 0; i < N; i++ {
		if data[i].NIM == NIM {
			return data[i].NILAI
		}
	}
	return -1
}

func cariNilaiTerbesar(data ArrayMahasiswa, N int, NIM string) int {
	maxNilai := -1
	for i := 0; i < N; i++ {
		if data[i].NIM == NIM && data[i].NILAI > maxNilai {
			maxNilai = data[i].NILAI
		}
	}
	return maxNilai
}
