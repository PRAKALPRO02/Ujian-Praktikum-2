//Muhammad Daffa Al Faiz
//2311102237

package main

import (
	"fmt"
)

type set [2022]int

func exist(T set, n int, val int) bool {
	for i := 0; i < n; i++ {
		if T[i] == val {
			return true
		}
	}
	return false
}

func inputSet(T *set, n *int) {
	var val int
	*n = 0
	for {
		fmt.Scan(&val)
		if exist(*T, *n, val) {
			break
		}
		T[*n] = val
		*n++
	}
}

func findIntersection(T1, T2 set, N1, N2 int, T3 *set, N3 *int) {
	*N3 = 0
	for i := 0; i < N1; i++ {
		if exist(T2, N2, T1[i]) {

			T3[*N3] = T1[i]
			*N3++
		}
	}
}

func printSet(T set, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("%d ", T[i])
	}
	fmt.Println()
}

func main() {
	var S1, S2, S3 set
	var N1, N2, N3 int

	fmt.Println("Masukkan himpunan elemen pertama:")
	inputSet(&S1, &N1)
	fmt.Println("Masukkan himpunan elemen kedua:")
	inputSet(&S2, &N2)
	findIntersection(S1, S2, N1, N2, &S3, &N3)
	fmt.Println("Irisan kedua himpunan:")
	printSet(S3, N3)
}
