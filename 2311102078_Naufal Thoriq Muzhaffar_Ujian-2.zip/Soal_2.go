package main

import (
	"fmt"
)

/*
Naufal Thoriq Muzhaffar
2311102078
IF-11-02
*/

const nMax = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

type arrayMahasiswa [nMax]mahasiswa

func inputMahasiswa(data *arrayMahasiswa, N *int) {
	fmt.Print("Masukkan jumlah mahasiswa: ")
	fmt.Scan(&*N)
	for i := 0; i < *N; i++ {
		fmt.Print("Masukkan NIM, Nama, dan Nilai: ")
		fmt.Scan(&data[i].NIM, &data[i].nama, &data[i].nilai)
	}
}

func cariNilaiPertama(data arrayMahasiswa, N int, NIM string) int {
	for i := 0; i < N; i++ {
		if data[i].NIM == NIM {
			return data[i].nilai
		}
	}
	return -1
}

func cariNilaiTerbesar(data arrayMahasiswa, N int, NIM string) int {
	max := -1
	for i := 0; i < N; i++ {
		if data[i].NIM == NIM && data[i].nilai > max {
			max = data[i].nilai
		}
	}
	return max
}

func main() {
	var data arrayMahasiswa
	var N int
	inputMahasiswa(&data, &N)

	var NIM string
	fmt.Print("Masukkan NIM untuk mencari nilai pertama: ")
	fmt.Scan(&NIM)
	nilaiPertama := cariNilaiPertama(data, N, NIM)
	fmt.Printf("Nilai pertama mahasiswa dengan NIM %s: %d\n", NIM, nilaiPertama)

	fmt.Print("Masukkan NIM untuk mencari nilai terbesar: ")
	fmt.Scan(&NIM)
	nilaiTerbesar := cariNilaiTerbesar(data, N, NIM)
	fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s: %d\n", NIM, nilaiTerbesar)
}
