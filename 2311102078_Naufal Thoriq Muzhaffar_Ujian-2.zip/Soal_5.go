package main

import (
	"fmt"
	"sort"
)

/*
Naufal Thoriq Muzhaffar
2311102078
IF-11-02
*/

type partai struct {
	nama  int
	suara int
}

type tabPartai []partai

func main() {
	var p tabPartai
	var input int

	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		found := false
		for i := range p {
			if p[i].nama == input {
				p[i].suara++
				found = true
				break
			}
		}
		if !found {
			p = append(p, partai{nama: input, suara: 1})
		}
	}

	sort.Slice(p, func(i, j int) bool {
		return p[i].suara > p[j].suara
	})

	for _, partai := range p {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}
