//IKRAM IRIANSYAH
//2311102184
//IF-11-02

package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)
	
func main() {
	// Baca input dari pengguna
	scanner:= bufio.NewScanner(os.Stdin)
	fmt.Println("Masukkan baris pertama (pisahkan dengan spasi):")
	scanner.Scan()
	line1 := scanner.Text()

	fmt.Println("Masukkan baris kedua (pisahkan dengan spasi):")
	scanner.Scan() 
	line2 := scanner.Text()
	
	// Parse input menjadi slice integer tanpa duplikat
	set1 := parseInputToSet(line1)
	set2 := parseInputToSet(line2)
	
	// Cari irisan antara dua himpunan 
	intersection := findIntersection(set1, set2)
	
	// Tampilkan hasil 
	fmt.Println("Hasil Irisan:", intersection)
	
}

// Fungsi untuk mengubah input string menjadi map (himpunan unik)
func parseInputToSet(input string) map[int]bool {
	set:= make(map[int]bool)
	numbers := strings.Fields(input)
	for _, num:= range numbers {
		val, err := strconv.Atoi(num)
		if err == nil {
			if !set[val] {
				set [val] = true
			} else {
				// Jika duplikat ditemukan, hentikan pengisian
				break
			}
		}	
	}
	return set
}
	
// Fungsi untuk menemukan irisan antara dua himpunan
	
func findIntersection(set1, set2 map[int]bool) []int {
	intersection := []int{}
	for num:= range set1 {
		if set2[num] {
			intersection = append(intersection, num)
		}
	}
	return intersection
}
