//IKRAM IRIANSYAH
//2311102184
//IF-11-02

package main

import "fmt"

const NMAX = 1000000

// struct partai
type tabPartai [NMAX]partai

type partai struct {
	nama_2311102184   int
	suara_2311102184 int
}

func main() {
	// deklarasi variabel
	var p tabPartai
	var n int

	// input suara
	fmt.Print("Masukkan jumlah partai: ")
	fmt.Scanln(&n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan nama partai ke-%d: ", i+1)
		fmt.Scanln(&p[i].nama_2311102184)
		fmt.Printf("Masukkan jumlah suara partai ke-%d: ", i+1)
		fmt.Scanln(&p[i].suara_2311102184)
	}

	// insertion sort descending berdasarkan jumlah suara
	for i := 1; i < n; i++ {
		j := i
		for j > 0 && p[j].suara_2311102184 > p[j-1].suara_2311102184 {
			p[j], p[j-1] = p[j-1], p[j]
			j--
		}
	}

	// tampilkan array p
	fmt.Println("Hasil pengurutan partai:")
	for i := 0; i < n; i++ {
		fmt.Printf("Partai ke-%d: Nama = %d, Suara = %d\n", i+1, p[i].nama_2311102184, p[i].suara_2311102184)
	}
}

func posisi(t tabPartai, n int, nama int) int {
	// mengembalikan indeks partai yang memiliki nama yang dicari pada array t yang berisi n partai atau -1 apabila tidak ditemukan, gunakan pencarian sekuensial
	for i := 0; i < n; i++ {
		if t[i].nama_2311102184 == nama {
			return i
		}
	}
	return -1
}