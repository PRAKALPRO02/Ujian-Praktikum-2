//IKRAM IRIANSYAH
//2311102184
//IF-11-02

package main

import (
	"fmt"
)

const nMax int = 51

type mahasiswa struct {
	NIM 	string
	Nama 	string
	Nilai	int
}

type arrayMahasiswa [nMax]mahasiswa

func main() {
	var dataMahasiswa arrayMahasiswa
	var N int

	// Input jumlah mahasiswa
	fmt.Print("Masukkan jumlah mahasiswa: ")
	fmt.Scan(&N)

	// Input data mahasiswa
	for i := 0; i < N; i++ {
		fmt.Printf("Data mahasiswa ke-%d:\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&dataMahasiswa[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&dataMahasiswa[i].Nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&dataMahasiswa[i].Nilai)
	}

	// Mencari mahasiswa berdasarkan NIM
	var cariNIM string
	fmt.Print("Masukkan NIM yang ingin dicari: ")
	fmt.Scan(&cariNIM)
	index := cariMahasiswaByNIM(dataMahasiswa, N, cariNIM)
	if index != -1 {
		fmt.Printf("Mahasiswa ditemukan: %s %s %d\n", dataMahasiswa[index].NIM, 
		dataMahasiswa[index].Nama, dataMahasiswa[index].Nilai)
	} else {
		fmt.Println("Mahasiswa dengan NIM tersebut tidak ditemukan.")
	}

	// Mencari nilai terbesar
	indexMax := cariNilaiTerbesar(dataMahasiswa, N)
	fmt.Printf("Mahasiswa dengan nilai terbesar: %s %s %d\n", dataMahasiswa[indexMax].NIM, 
	dataMahasiswa[indexMax].Nama, dataMahasiswa[indexMax].Nilai)
}

// Fungsi untuk mencari mahasiswa berdasarkan NIM
func cariMahasiswaByNIM(data arrayMahasiswa, N int, NIM string) int {
	for i := 0; i < N; i++ {
		if data[i].NIM == NIM {
			return i
		}
	}
	return -1
}

// Fungsi untuk mencari indeks mahasiswa dengan nilai terbesar
func cariNilaiTerbesar(data arrayMahasiswa, N int) int {
	maxIndex := 0
	for i := 1; i < N; i++ {
		if data[i].Nilai > data[maxIndex].Nilai {
			maxIndex = i
		}
	}
	return maxIndex
}