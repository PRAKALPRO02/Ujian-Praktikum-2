package main

import (
	"fmt"
)

const maxElements = 10 // Maksimum elemen array

type set [maxElements]int

// Memeriksa apakah elemen sudah ada dalam array
func exist(T set, n int, val int) bool {
	for i := 0; i < n; i++ {
		if T[i] == val {
			return true
		}
	}
	return false
}

// Menginput elemen-elemen himpunan
func inputSet(T *set, n *int) {
	var val int
	*n = 0 // Inisialisasi jumlah elemen
	fmt.Println("Masukkan elemen (maksimum 10 elemen, atau berhenti jika elemen duplikat ditemukan):")
	for {
		if *n >= maxElements {
			fmt.Println("Maksimum 10 elemen tercapai. Input selesai.")
			break
		}
		fmt.Printf("Elemen ke-%d: ", *n+1)
		fmt.Scan(&val)
		if exist(*T, *n, val) { // Menghentikan input jika elemen duplikat dimasukkan
			fmt.Println("Elemen duplikat ditemukan. Input selesai.")
			break
		}
		T[*n] = val // Menambahkan elemen ke dalam array
		(*n)++
	}
}

// Mencari irisan antara dua himpunan
func findIntersection(T1, T2 set, n1, n2 int, T3 *set, n3 *int) {
	*n3 = 0 // Inisialisasi jumlah elemen irisan
	for i := 0; i < n1; i++ {
		// Hanya tambahkan elemen jika ada di kedua himpunan dan belum ada di T3
		if exist(T2, n2, T1[i]) && !exist(*T3, *n3, T1[i]) {
			T3[*n3] = T1[i]
			(*n3)++
		}
	}
}

// Menampilkan isi array dengan format horizontal
func printSet(T set, n int) {
	if n == 0 {
		fmt.Println("Himpunan kosong.")
		return
	}
	for i := 0; i < n; i++ {
		if i > 0 {
			fmt.Print(" ")
		}
		fmt.Print(T[i])
	}
	fmt.Println()
}

func main() {
	// Menampilkan NIM
	fmt.Println("NIM: 2311102196")

	// Deklarasi variabel himpunan dan jumlah elemen
	var s1, s2, s3 set
	var n1, n2, n3 int

	// Input elemen-elemen himpunan pertama
	fmt.Println("Masukkan elemen-elemen himpunan pertama:")
	inputSet(&s1, &n1)

	// Input elemen-elemen himpunan kedua
	fmt.Println("Masukkan elemen-elemen himpunan kedua:")
	inputSet(&s2, &n2)

	// Mencari irisan kedua himpunan
	findIntersection(s1, s2, n1, n2, &s3, &n3)

	// Menampilkan irisan kedua himpunan
	fmt.Println("Irisan dari kedua himpunan adalah:")
	printSet(s3, n3)
}
