package main

import (
	"fmt"
)

const NMAX = 1000000 // Kapasitas maksimum partai

// Struktur data partai
type Partai struct {
	nama_2311102196  int
	suara int
}

// Tipe array untuk menyimpan data partai
type TabPartai [NMAX]Partai

func main() {
	var t TabPartai
	var n int // Jumlah partai yang diproses
	var input int

	fmt.Println("Masukkan suara partai (akhiri dengan -1):")

	// Input suara partai
	for {
		fmt.Scan(&input)
		if input == -1 {
			break // Selesai jika input adalah -1
		}

		processInput(&t, &n, input) // Proses input partai
	}

	// Urutkan data partai secara descending berdasarkan suara
	sortDescending(&t, n)

	// Tampilkan hasil
	printPartai(t, n)
}

// Prosedur untuk memproses input suara partai
func processInput(t *TabPartai, n *int, input int) {
	pos := findIndex(*t, *n, input) // Cari indeks partai berdasarkan nama

	if pos == -1 {
		// Jika partai belum ada, tambahkan partai baru
		t[*n].nama_2311102196 = input
		t[*n].suara = 1
		(*n)++
	} else {
		// Jika partai sudah ada, tambahkan jumlah suaranya
		t[pos].suara++
	}
}

// Fungsi untuk mencari indeks partai berdasarkan nama
func findIndex(t TabPartai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if t[i].nama_2311102196 == nama {
			return i
		}
	}
	return -1 // Jika partai tidak ditemukan
}

// Prosedur untuk mengurutkan array partai secara descending berdasarkan jumlah suara
func sortDescending(t *TabPartai, n int) {
	for i := 1; i < n; i++ {
		key := t[i]
		j := i - 1

		// Pindahkan elemen yang lebih kecil ke kanan
		for j >= 0 && t[j].suara < key.suara {
			t[j+1] = t[j]
			j--
		}
		t[j+1] = key
	}
}

// Prosedur untuk menampilkan hasil partai
func printPartai(t TabPartai, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("%d(%d) ", t[i].nama_2311102196, t[i].suara)
	}
	fmt.Println()
}
