package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

// Struct untuk menyimpan data pemain
type Pemain struct {
	Nama_2311102196    string
	Gol     int
	Assist  int
}

// Fungsi untuk membaca input dari pengguna
func bacaInput() ([]Pemain, error) {
	scanner := bufio.NewScanner(os.Stdin)

	// Membaca jumlah pemain
	fmt.Print("Masukkan jumlah pemain: ")
	if !scanner.Scan() {
		return nil, fmt.Errorf("gagal membaca input jumlah pemain")
	}
	n, err := strconv.Atoi(scanner.Text())
	if err != nil || n <= 0 {
		return nil, fmt.Errorf("input jumlah pemain tidak valid")
	}

	// Membaca data setiap pemain
	pemain := make([]Pemain, n)
	fmt.Println("Masukkan data pemain (Nama Depan, Nama Belakang, Gol, Assist):")
	for i := 0; i < n; i++ {
		if !scanner.Scan() {
			return nil, fmt.Errorf("gagal membaca data pemain")
		}
		data := strings.Fields(scanner.Text())
		if len(data) != 4 {
			return nil, fmt.Errorf("format data pemain salah, harus 4 kolom")
		}

		gol, err := strconv.Atoi(data[2])
		if err != nil {
			return nil, fmt.Errorf("jumlah gol tidak valid")
		}
		assist, err := strconv.Atoi(data[3])
		if err != nil {
			return nil, fmt.Errorf("jumlah assist tidak valid")
		}

		pemain[i] = Pemain{
			Nama_2311102196:   data[0] + " " + data[1],
			Gol:    gol,
			Assist: assist,
		}
	}

	return pemain, nil
}

func main() {
	// Membaca input
	pemain, err := bacaInput()
	if err != nil {
		fmt.Println("Error:", err)
		return
	}

	// Mengurutkan data pemain berdasarkan aturan:
	// 1. Pemain dengan jumlah gol lebih banyak berada di urutan lebih tinggi.
	// 2. Jika jumlah gol sama, pemain dengan assist lebih banyak berada di urutan lebih tinggi.
	sort.SliceStable(pemain, func(i, j int) bool {
		if pemain[i].Gol != pemain[j].Gol {
			return pemain[i].Gol > pemain[j].Gol
		}
		return pemain[i].Assist > pemain[j].Assist
	})

	// Mencetak hasil sorting
	fmt.Println("Hasil urutan pemain:")
	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", p.Nama_2311102196, p.Gol, p.Assist)
	}
}
