package main

import (
	"fmt"
	"strings"
)

// Konstanta jumlah provinsi
const nProv = 11

// Tipe data untuk menyimpan informasi provinsi
type (
	NamaProv_2311102196   [nProv]string
	PopProv    [nProv]int
	TumbuhProv [nProv]float64
)

// Fungsi untuk menginput data provinsi
func InputData(nama *NamaProv_2311102196, pop *PopProv, tumbuh *TumbuhProv) {
	fmt.Println("Masukkan data provinsi:")
	for i := 0; i < nProv; i++ {
		fmt.Printf("\nProvinsi ke-%d:\n", i+1)
		fmt.Print("Nama: ")
		fmt.Scanln(&nama[i])
		fmt.Printf("Populasi (dalam juta): ")
		fmt.Scanln(&pop[i])
		fmt.Printf("Angka pertumbuhan penduduk (dalam desimal, misalnya 0.02): ")
		fmt.Scanln(&tumbuh[i])
	}
}

// Fungsi untuk mencari indeks provinsi dengan pertumbuhan tercepat
func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIndex := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIndex] {
			maxIndex = i
		}
	}
	return maxIndex
}

// Fungsi untuk mencari indeks provinsi berdasarkan nama
func IndeksProvinsi(nama NamaProv_2311102196, target string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(nama[i], target) { // Tidak sensitif terhadap huruf besar/kecil
			return i
		}
	}
	return -1 // Mengembalikan -1 jika tidak ditemukan
}

// Prosedur untuk menampilkan prediksi populasi provinsi
func Prediksi(nama NamaProv_2311102196, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("\nPrediksi populasi tahun depan untuk provinsi dengan pertumbuhan > 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 { // Hanya memproses provinsi dengan pertumbuhan > 2%
			prediksi := float64(pop[i]) * (1 + tumbuh[i])
			fmt.Printf("%s: Populasi tahun depan = %.0f juta\n", nama[i], prediksi)
		}
	}
}

func main() {
	var (
		nama   NamaProv_2311102196
		pop    PopProv
		tumbuh TumbuhProv
		cari   string
	)

	// Input data provinsi
	InputData(&nama, &pop, &tumbuh)

	// Menampilkan provinsi dengan pertumbuhan tercepat
	tercepatIndex := ProvinsiTercepat(tumbuh)
	fmt.Printf("\nProvinsi dengan pertumbuhan tercepat: %s\n", nama[tercepatIndex])

	// Mencari provinsi berdasarkan nama
	fmt.Print("\nMasukkan nama provinsi yang ingin dicari: ")
	fmt.Scanln(&cari)
	indeks := IndeksProvinsi(nama, cari)
	if indeks != -1 {
		fmt.Printf("Provinsi %s ditemukan pada indeks %d\n", cari, indeks)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan\n", cari)
	}

	// Menampilkan prediksi populasi
	Prediksi(nama, pop, tumbuh)
}
