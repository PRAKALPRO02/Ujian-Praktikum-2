package main
import "fmt"

const nMax int = 51  
type mahasiswa struct{
  NIM string
  nama string
  nilai int
}
type arrayMahasiswa [nMax]mahasiswa

func inputMhs(A *arrayMahasiswa, N *int){
  fmt.Print("Masukkan jumlah mahasiswa: ")
  fmt.Scan(N)
  for i:=0; i<*N; i++{
    fmt.Println("Mahasiswa ", i+1, ":")
    fmt.Print("Masukkan NIM: ")
    fmt.Scan(&A[i].NIM)
    fmt.Print("Masukkan nama: ")
    fmt.Scan(&A[i].nama)
    fmt.Print("Masukkan nilai: ")
    fmt.Scan(&A[i].nilai)
    fmt.Println()
  }
}

func CariNilaiPertama(A arrayMahasiswa, N int, NIM string) int{
  var i,nemu int
  nemu = -1
  i = 0
  for i<N && nemu == -1{
    if A[i].NIM == NIM{
      return i
    }
    i++
  }
  return -1
}

func CariNilaiTerbesar(A arrayMahasiswa, N int, NIM string) int{
  var nemu int = CariNilaiPertama(A, N, NIM)
  var i, idxMax int
  if nemu != -1{
    idxMax = nemu
    for i=nemu; i<N; i++{
      if A[i].nilai > A[idxMax].nilai && A[i].NIM == NIM{
        idxMax = i
      }
    }
    return idxMax
  }else{
    return nemu
  }
}

func main(){
  var A arrayMahasiswa
  var M, idx1, idx2 int
  var NIM string
  inputMhs(&A, &M)
  fmt.Print("Masukkan NIM yang ingin dicari: ")
  fmt.Scan(&NIM)
  idx1 = CariNilaiPertama(A, M, NIM)
  idx2 = CariNilaiTerbesar(A, M, NIM)
  fmt.Println("Nilai pertama dari NIM", NIM, "adalah", A[idx1].nilai)
  fmt.Println("Nilai terbesar dari NIM", NIM, "adalah", A[idx2].nilai)
}