package main

import (
	"fmt"
)

const MAX = 1000000

// struct partai
type Partai struct {
	nama  string
	suara int
}

type tabPartai [MAX]Partai

func main() {
	var p tabPartai
	var n, idx int
	var nama string

	n = 0
	fmt.Scan(&nama)
	for nama != "-1" {
		idx = posisi(p, n, nama)
		if idx == -1 {
			// Partai baru, tambahkan ke array
			p[n].nama = nama
			p[n].suara = 1
			n++
		} else {
			// Partai ditemukan, tambahkan suara
			p[idx].suara++
		}
		fmt.Scan(&nama)
	}

	// Proses pengurutan dengan insertion sort secara descending
	for pass := 1; pass < n; pass++ {
		temp := p[pass]
		k := pass
		for k > 0 && temp.suara > p[k-1].suara {
			p[k] = p[k-1]
			k--
		}
		p[k] = temp
	}

	// Tampilkan hasil
	for i := 0; i < n; i++ {
		fmt.Printf("%v(%v) ", p[i].nama, p[i].suara)
	}
}

func posisi(tabelPartai tabPartai, n int, nama string) int {
	// Mencari indeks partai berdasarkan nama
	for i := 0; i < n; i++ {
		if tabelPartai[i].nama == nama {
			return i
		}
	}
	return -1
}