// Ben Waiz Pintus W
// 2311102169
package main

import (
	"fmt"
)

type Pemain struct {
	nama   string
	gol    int
	assist int
}

func selectionSort(pemain []Pemain) {
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIndex := i
		for j := i + 1; j < n; j++ {
			if pemain[j].gol > pemain[maxIndex].gol || (pemain[j].gol == pemain[maxIndex].gol && pemain[j].assist > pemain[maxIndex].assist) {
				maxIndex = j
			}
		}
		pemain[i], pemain[maxIndex] = pemain[maxIndex], pemain[i]
	}
}

func main() {
	var n int
	fmt.Scan(&n)
	pemain := make([]Pemain, n)
	for i := 0; i < n; i++ {
		var namaDepan, namaBelakang string
		var gol, assist int
		fmt.Scan(&namaDepan, &namaBelakang, &gol, &assist)

		nama := namaDepan + " " + namaBelakang

		pemain[i] = Pemain{nama, gol, assist}
	}
	fmt.Println("Hasil Sortingnya adalah: ")
	selectionSort(pemain)

	for _, p := range pemain {
		fmt.Println(p.nama, p.gol, p.assist)
	}
}
