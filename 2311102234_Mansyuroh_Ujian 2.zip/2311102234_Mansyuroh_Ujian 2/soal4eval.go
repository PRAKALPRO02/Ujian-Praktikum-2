package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type pemain struct {
	nama   string
	gol    int
	assist int
}

// Fungsi untuk mengurutkan data menggunakan Selection Sort
func selectionSort(data []pemain, n int) {
	for i := 0; i < n-1; i++ {
		maxIdx := i
		for j := i + 1; j < n; j++ {

			if data[j].gol > data[maxIdx].gol ||
				(data[j].gol == data[maxIdx].gol && data[j].assist > data[maxIdx].assist) {
				maxIdx = j
			}
		}

		data[i], data[maxIdx] = data[maxIdx], data[i]
	}
}

// Fungsi untuk mencetak data pemain
func cetakPemain(data []pemain, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("%s %d %d\n", data[i].nama, data[i].gol, data[i].assist)
	}
}

func main() {
	var n int
	var pemainList []pemain

	// Input
	scanner := bufio.NewScanner(os.Stdin)
	fmt.Print("Masukkan jumlah pencetak gol: ")
	scanner.Scan()
	n, _ = strconv.Atoi(scanner.Text())

	fmt.Println("Masukkan data pemain (Nama Gol Assist):")
	for i := 0; i < n; i++ {
		scanner.Scan()
		input := strings.Fields(scanner.Text())
		if len(input) < 4 {
			fmt.Println("Input tidak valid. Masukkan data dalam format: Nama_Depan Nama_Belakang Gol Assist")
			return
		}

		nama := input[0] + " " + input[1]
		gol, _ := strconv.Atoi(input[2])
		assist, _ := strconv.Atoi(input[3])
		pemainList = append(pemainList, pemain{nama: nama, gol: gol, assist: assist})
	}

	selectionSort(pemainList, n)

	fmt.Println("\nHasil urutan pemain:")
	cetakPemain(pemainList, n)
}
