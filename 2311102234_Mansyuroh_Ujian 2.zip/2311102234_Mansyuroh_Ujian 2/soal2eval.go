package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

const nMax = 51

// Array untuk menyimpan data mahasiswa
type arrayMahasiswa [nMax]mahasiswa

// Fungsi untuk menerima masukan data mahasiswa
func inputMahasiswa(data *arrayMahasiswa, n *int) {
	scanner := bufio.NewScanner(os.Stdin)
	fmt.Print("Masukkan jumlah data mahasiswa: ")
	scanner.Scan()
	jumlah, _ := strconv.Atoi(scanner.Text())
	*n = jumlah

	for i := 0; i < *n; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d (NIM, Nama, Nilai):\n", i+1)
		scanner.Scan()
		input := strings.Fields(scanner.Text())
		nilai, _ := strconv.Atoi(input[2])
		data[i] = mahasiswa{
			NIM:   input[0],
			nama:  input[1],
			nilai: nilai,
		}
	}
}

// Fungsi untuk mencari nilai pertama seorang mahasiswa berdasarkan NIM
func cariNilaiPertama(data arrayMahasiswa, n int, NIM string) int {
	for i := 0; i < n; i++ {
		if data[i].NIM == NIM {
			return data[i].nilai
		}
	}
	return -1 // Jika tidak ditemukan
}

func cariNilaiTerbesar(data arrayMahasiswa, n int, NIM string) int {
	maxNilai := -1
	for i := 0; i < n; i++ {
		if data[i].NIM == NIM && data[i].nilai > maxNilai {
			maxNilai = data[i].nilai
		}
	}
	return maxNilai
}

func tampilkanHasil(nilaiPertama, nilaiTerbesar int, NIM string) {
	if nilaiPertama == -1 {
		fmt.Printf("Mahasiswa dengan NIM %s tidak ditemukan.\n", NIM)
	} else {
		fmt.Printf("Nilai pertama mahasiswa dengan NIM %s adalah %d.\n", NIM, nilaiPertama)
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM %s adalah %d.\n", NIM, nilaiTerbesar)
	}
}

func main() {
	var dataMahasiswa arrayMahasiswa
	var jumlah int

	inputMahasiswa(&dataMahasiswa, &jumlah)

	scanner := bufio.NewScanner(os.Stdin)
	fmt.Print("Masukkan NIM mahasiswa yang ingin dicari: ")
	scanner.Scan()
	NIM := scanner.Text()

	nilaiPertama := cariNilaiPertama(dataMahasiswa, jumlah, NIM)
	nilaiTerbesar := cariNilaiTerbesar(dataMahasiswa, jumlah, NIM)

	tampilkanHasil(nilaiPertama, nilaiTerbesar, NIM)
}
