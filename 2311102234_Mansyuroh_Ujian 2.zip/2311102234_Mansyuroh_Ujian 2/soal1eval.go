package main

import (
	"fmt"
)

type set [2022]int

func exist(T set, n int, val int) bool {
	for i := 0; i < n; i++ {
		if T[i] == val {
			return true
		}
	}
	return false
}

func inputSet(T *set, n *int) {
	var val int
	*n = 0
	fmt.Println("Masukkan elemen himpunan :")
	for *n < len(T) {
		fmt.Scan(&val)
		if exist(*T, *n, val) {
			break
		}
		T[*n] = val
		*n++
	}
}

func findIntersection(T1, T2 set, n, m int, T3 *set, h *int) {
	*h = 0
	for i := 0; i < n; i++ {
		if exist(T2, m, T1[i]) && !exist(*T3, *h, T1[i]) {
			T3[*h] = T1[i]
			(*h)++
		}
	}
}

func printSet(T set, n int) {
	for i := 0; i < n; i++ {
		fmt.Print(T[i])
		if i < n-1 {
			fmt.Print(" ")
		}
	}
	fmt.Println()
}

func main() {
	var S1, S2, S3 set
	var n1, n2, n3 int

	fmt.Println("Masukkan elemen untuk himpunan pertama:")
	inputSet(&S1, &n1)

	fmt.Println("Masukkan elemen untuk himpunan kedua:")
	inputSet(&S2, &n2)

	findIntersection(S1, S2, n1, n2, &S3, &n3)

	fmt.Println("Hasil irisan dari kedua himpunan adalah:")
	printSet(S3, n3)
}
