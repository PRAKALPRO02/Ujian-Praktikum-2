package main

import (
	"fmt"
	"strings"
)

// jumlah provinsi
const nProv = 10

type Provinsi struct {
	nama        string
	populasi    int
	pertumbuhan float64
}

func InputData() ([]Provinsi, string) {
	var provinsi []Provinsi
	var namaDicari string

	for i := 0; i < nProv; i++ {
		var nama string
		var populasi int
		var pertumbuhan float64
		fmt.Printf("Masukkan data provinsi %d (nama, populasi, pertumbuhan):\n", i+1)
		fmt.Scan(&nama, &populasi, &pertumbuhan)
		provinsi = append(provinsi, Provinsi{nama, populasi, pertumbuhan})
	}

	fmt.Println("Masukkan nama provinsi yang akan dicari:")
	fmt.Scan(&namaDicari)

	return provinsi, namaDicari
}

func ProvinsiTercepat(provinsi []Provinsi) int {
	tercepatIdx := 0
	for i, p := range provinsi {
		if p.pertumbuhan > provinsi[tercepatIdx].pertumbuhan {
			tercepatIdx = i
		}
	}
	return tercepatIdx
}

func IndeksProvinsi(provinsi []Provinsi, nama string) int {
	for i, p := range provinsi {
		if strings.EqualFold(p.nama, nama) {
			return i
		}
	}
	return -1
}

// Prosedur untuk menampilkan data provinsi dengan pertumbuhan di atas 2%
func TampilkanData(provinsi []Provinsi) {
	for _, p := range provinsi {
		if p.pertumbuhan > 2 {
			prediksi := float64(p.populasi) * (1 + p.pertumbuhan/100)
			fmt.Printf("%s: Populasi sekarang = %d, Prediksi tahun depan = %.2f\n", p.nama, p.populasi, prediksi)
		}
	}
}

func main() {
	// Input data
	provinsi, namaDicari := InputData()

	idxTercepat := ProvinsiTercepat(provinsi)
	fmt.Printf("Provinsi dengan pertumbuhan tercepat: %s\n", provinsi[idxTercepat].nama)

	idxDicari := IndeksProvinsi(provinsi, namaDicari)
	fmt.Printf("Indeks provinsi yang dicari: %d\n", idxDicari)

	fmt.Println("Provinsi dengan pertumbuhan di atas 2%:")
	TampilkanData(provinsi)
}
