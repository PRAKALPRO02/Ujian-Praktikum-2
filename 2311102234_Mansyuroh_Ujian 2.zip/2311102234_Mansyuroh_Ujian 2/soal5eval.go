package main

import (
	"fmt"
	"sort"
)

const MAX = 1000000

// Struct untuk menyimpan data partai
type Partai struct {
	nama  int
	suara int
}

func main() {
	var suaraMasuk int
	partaiMap := make(map[int]int)
	// Input data suara
	for {
		fmt.Scan(&suaraMasuk)
		if suaraMasuk == -1 { // Berhenti jika input adalah -1
			break
		}
		partaiMap[suaraMasuk]++
	}

	partaiArray := make([]Partai, 0, len(partaiMap))
	for nama, suara := range partaiMap {
		partaiArray = append(partaiArray, Partai{nama, suara})
	}

	// Urutkan array berdasarkan suara secara descending
	sort.Slice(partaiArray, func(i, j int) bool {
		if partaiArray[i].suara == partaiArray[j].suara {
			return partaiArray[i].nama < partaiArray[j].nama // Jika suara sama, urutkan berdasarkan nama partai
		}
		return partaiArray[i].suara > partaiArray[j].suara
	})

	// Tampilkan hasil
	for _, partai := range partaiArray {
		fmt.Printf("%d(%d) ", partai.nama, partai.suara)
	}
	fmt.Println()
}
